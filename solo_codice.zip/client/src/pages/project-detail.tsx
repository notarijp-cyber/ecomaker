import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { PageLayout } from "@/components/layout/page-layout";
import { Project, ProjectParticipant } from "@/lib/types";
import { ProjectSteps } from "@/components/project/project-steps";
import { ProjectDivision } from "@/components/project/project-division";
import { ARTransformPreview, ARButton } from "@/components/ar";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  ClipboardList, 
  Users, 
  Clock, 
  Tag, 
  BarChart3, 
  Hammer, 
  UserPlus,
  ArrowLeft,
  Calendar,
  Box,
  Eye,
  Lightbulb,
  Recycle,
  Search
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AvatarGroup } from "@/components/ui/avatar-group";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { getDifficultyColor } from "@/lib/utils";
import { AmazonProductWidget } from "@/components/shop/amazon-product-widget";
import { useAmazonProducts } from "@/hooks/use-amazon-products";

// Funzione per determinare il tipo di modello 3D in base al materiale/progetto
function getMaterialModelType(project: Project): string {
  if (!project) return "box";
  
  // Se il progetto ha una categoria specifica, usiamo quella
  if (project.category) {
    const category = project.category.toLowerCase();
    if (["lampada", "vaso", "pianta", "bottiglia", "scatola", "ciotola"].includes(category)) {
      return category;
    }
  }
  
  // Altrimenti proviamo a determinare in base ai materiali
  if (Array.isArray(project.requiredMaterials) && project.requiredMaterials.length > 0) {
    const primaryMaterial = project.requiredMaterials[0].name?.toLowerCase() || "";
    
    if (primaryMaterial.includes("bottiglia") || primaryMaterial.includes("plastic")) {
      return "bottiglia";
    } else if (primaryMaterial.includes("carta") || primaryMaterial.includes("cartone")) {
      return "scatola";
    } else if (primaryMaterial.includes("legno") || primaryMaterial.includes("bambù")) {
      return "vaso";
    } else if (primaryMaterial.includes("vetro")) {
      return "bottiglia"; 
    } else if (primaryMaterial.includes("tessuto") || primaryMaterial.includes("stoffa")) {
      return "cuscino";
    } else if (primaryMaterial.includes("metallo") || primaryMaterial.includes("alluminio")) {
      return "lampada";
    }
  }
  
  // Default generico
  return "box";
}

// Funzione per ottenere l'ID del materiale principale dal progetto
function getMaterialId(project: Project): number {
  if (!project || !Array.isArray(project.requiredMaterials) || project.requiredMaterials.length === 0) {
    return 1; // ID di default se non ci sono materiali
  }
  
  // Prendiamo il primo materiale come materiale principale
  const primaryMaterial = project.requiredMaterials[0];
  return primaryMaterial.materialId || 1;
}

// Funzione per ottenere il nome del materiale principale
function getMaterialName(project: Project): string {
  if (!project || !Array.isArray(project.requiredMaterials) || project.requiredMaterials.length === 0) {
    return "Materiale generico";
  }
  
  // Prendiamo il primo materiale come materiale principale
  const primaryMaterial = project.requiredMaterials[0];
  return primaryMaterial.name || "Materiale generico";
}

export default function ProjectDetail() {
  const { id } = useParams();
  const projectId = parseInt(id || "0");
  const userId = 1; // Placeholder for demo user
  
  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${projectId}`],
  });
  
  const { data: participants, isLoading: participantsLoading } = useQuery<ProjectParticipant[]>({
    queryKey: [`/api/projects/${projectId}/participants`],
    enabled: !!projectId,
  });
  
  // Estrazione dei materiali e strumenti dal progetto per l'integrazione Amazon
  const materialNames = useMemo(() => {
    if (!project || !project.requiredMaterials) return [];
    return project.requiredMaterials.map((m: any) => m.name || "");
  }, [project]);
  
  const toolNames = useMemo(() => {
    if (!project || !project.requiredTools) return [];
    return project.requiredTools.map((t: any) => t.name || "");
  }, [project]);
  
  const { products, isLoading: productsLoading } = useAmazonProducts({
    materials: materialNames,
    tools: toolNames,
    enabled: !projectLoading && !!project && (materialNames.length > 0 || toolNames.length > 0)
  });
  
  const [isJoined, setIsJoined] = useState(false);
  
  const handleJoinProject = () => {
    // Would call API to join project in a real implementation
    setIsJoined(true);
  };
  
  if (projectLoading) {
    return (
      <PageLayout showFab={false}>
        <div className="flex items-center mb-6">
          <Link href="/my-projects">
            <Button variant="ghost" className="p-0 mr-2">
              <ArrowLeft className="h-5 w-5 mr-1" />
            </Button>
          </Link>
          <Skeleton className="h-8 w-1/2" />
        </div>
        
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Skeleton className="h-96 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </PageLayout>
    );
  }
  
  if (!project) {
    return (
      <PageLayout>
        <div className="text-center py-16">
          <h2 className="text-2xl font-heading font-bold mb-2">Progetto non trovato</h2>
          <p className="text-neutral-medium mb-6">
            Il progetto che stai cercando non esiste o è stato rimosso.
          </p>
          <Link href="/my-projects">
            <Button className="bg-primary text-white">
              Torna ai progetti
            </Button>
          </Link>
        </div>
      </PageLayout>
    );
  }
  
  const isUserParticipant = isJoined || participants?.some(p => p.userId === userId);
  
  return (
    <PageLayout showFab={false}>
      <div className="mb-6">
        <div className="flex items-center mb-2">
          <Link href={project?.isCommunityProject ? "/community" : "/my-projects"}>
            <Button variant="ghost" className="p-0 mr-2">
              <ArrowLeft className="h-5 w-5 mr-1" />
            </Button>
          </Link>
          <h2 className="text-2xl font-heading font-bold">{project?.name || 'Progetto'}</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge className={getDifficultyColor(project?.difficulty || 'Facile')}>
            {project?.difficulty || 'Facile'}
          </Badge>
          {project?.isCommunityProject && (
            <Badge className="bg-accent bg-opacity-10 text-accent">
              Progetto comunitario
            </Badge>
          )}
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          {/* Project Image and Description */}
          <Card>
            <div className="w-full h-64 bg-neutral-light">
              {project?.imageUrl ? (
                <img
                  src={project.imageUrl}
                  alt={project.name || 'Immagine progetto'}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-primary-light bg-opacity-10">
                  <Tag className="h-16 w-16 text-primary" />
                </div>
              )}
            </div>
            <CardContent className="p-6">
              <p className="text-neutral-dark">{project?.description || 'Nessuna descrizione disponibile'}</p>
              
              {project?.isCommunityProject && typeof project?.completionPercentage === 'number' && (
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-neutral-medium">Completamento</span>
                    <span className="text-sm font-medium">{project.completionPercentage}%</span>
                  </div>
                  <Progress value={project.completionPercentage} className="h-2" />
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Project Details Tabs */}
          <Tabs defaultValue="instructions" className="space-y-4">
            <TabsList className="w-full grid grid-cols-6">
              <TabsTrigger value="instructions" className="flex items-center text-xs sm:text-sm">
                <ClipboardList className="h-4 w-4 mr-1 hidden sm:inline" />
                Istruzioni
              </TabsTrigger>
              <TabsTrigger value="overview" className="flex items-center text-xs sm:text-sm">
                <Eye className="h-4 w-4 mr-1 hidden sm:inline" />
                Panoramica
              </TabsTrigger>
              {project?.isCommunityProject && (
                <TabsTrigger value="division" className="flex items-center text-xs sm:text-sm">
                  <Users className="h-4 w-4 mr-1 hidden sm:inline" />
                  Divisione
                </TabsTrigger>
              )}
              <TabsTrigger value="materials" className="flex items-center text-xs sm:text-sm">
                <Tag className="h-4 w-4 mr-1 hidden sm:inline" />
                Materiali
              </TabsTrigger>
              <TabsTrigger value="impact" className="flex items-center text-xs sm:text-sm">
                <BarChart3 className="h-4 w-4 mr-1 hidden sm:inline" />
                Impatto
              </TabsTrigger>
              <TabsTrigger value="ar-preview" className="flex items-center text-xs sm:text-sm">
                <Box className="h-4 w-4 mr-1 hidden sm:inline" />
                Preview AR
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="instructions" className="space-y-4">
              <ProjectSteps project={project} />
              
              {/* Aggiungiamo consigli per la realizzazione */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center">
                    <Lightbulb className="h-5 w-5 mr-2 text-amber-500" />
                    Consigli per la Realizzazione
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-neutral-medium">
                      Ecco alcuni consigli utili per realizzare al meglio questo progetto:
                    </p>
                    
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="bg-primary bg-opacity-10 p-1 rounded-full mr-3 mt-0.5">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span>Prepara tutti i materiali e gli strumenti prima di iniziare per evitare interruzioni.</span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-primary bg-opacity-10 p-1 rounded-full mr-3 mt-0.5">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span>Se usi colle, vernici o altri prodotti chimici, assicurati di lavorare in un'area ben ventilata.</span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-primary bg-opacity-10 p-1 rounded-full mr-3 mt-0.5">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span>Prendi il tuo tempo, non avere fretta. La qualità del risultato finale dipende dall'attenzione ai dettagli.</span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-primary bg-opacity-10 p-1 rounded-full mr-3 mt-0.5">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span>Scatta foto durante le varie fasi di lavorazione per documentare il tuo progresso.</span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-primary bg-opacity-10 p-1 rounded-full mr-3 mt-0.5">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span>Non esitare a personalizzare il progetto secondo i tuoi gusti e creatività.</span>
                      </li>
                    </ul>
                    
                    <div className="bg-amber-50 border border-amber-100 p-4 rounded-md mt-4">
                      <div className="flex items-start">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p className="text-sm text-amber-800">
                          <span className="font-medium">Nota:</span> Alcuni passaggi potrebbero richiedere l'assistenza di un adulto. Se sei un principiante, valuta la possibilità di fare pratica su materiali di scarto prima di utilizzare tutti i tuoi materiali.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Video tutorial correlati */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    Video Tutorial Consigliati
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-neutral-medium mb-4">
                    Questi video potrebbero aiutarti con tecniche simili a quelle necessarie per questo progetto:
                  </p>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <a href="https://www.youtube.com/results?search_query=riciclo+creativo" target="_blank" rel="noopener noreferrer" className="flex items-center p-3 border rounded-lg transition-colors hover:bg-neutral-lightest hover:border-primary">
                      <div className="w-12 h-12 bg-red-500 rounded flex items-center justify-center mr-3 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium text-sm">Riciclo Creativo</p>
                        <p className="text-neutral-medium text-xs">Tecniche di base per trasformare oggetti di scarto</p>
                      </div>
                    </a>
                    
                    <a href="https://www.youtube.com/results?search_query=upcycling+tutorial" target="_blank" rel="noopener noreferrer" className="flex items-center p-3 border rounded-lg transition-colors hover:bg-neutral-lightest hover:border-primary">
                      <div className="w-12 h-12 bg-red-500 rounded flex items-center justify-center mr-3 flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium text-sm">Tecniche di Upcycling</p>
                        <p className="text-neutral-medium text-xs">Tutorial per dare nuova vita ai materiali</p>
                      </div>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Panoramica Progetto</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* Dettagli del progetto */}
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div className="bg-neutral-lightest p-4 rounded-lg space-y-2">
                        <h3 className="text-sm font-semibold text-neutral-dark">Livello di Difficoltà</h3>
                        <div className="flex items-center">
                          <div className={`px-3 py-1 rounded-full text-white font-medium text-sm ${getDifficultyColor(project?.difficulty || 'Facile')}`}>
                            {project?.difficulty || 'Facile'}
                          </div>
                          <div className="ml-2 text-sm text-neutral-medium">
                            {project?.difficulty === 'Facile' && '(Adatto a principianti)'}
                            {project?.difficulty === 'Medio' && '(Esperienza base richiesta)'}
                            {project?.difficulty === 'Difficile' && '(Per esperti)'}
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-neutral-lightest p-4 rounded-lg space-y-2">
                        <h3 className="text-sm font-semibold text-neutral-dark">Tempo di Realizzazione</h3>
                        <div className="flex items-center">
                          <Clock className="h-5 w-5 text-neutral-dark mr-2" />
                          <span className="font-medium">{project?.estimatedTime || 1} {project?.timeUnit || 'ore'}</span>
                          <span className="ml-2 text-sm text-neutral-medium">
                            ({Math.ceil((project?.estimatedTime || 1) * 60)} minuti circa)
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Consigli utili */}
                    <div className="bg-primary-light bg-opacity-10 p-4 rounded-lg">
                      <h3 className="text-md font-semibold mb-2 flex items-center">
                        <Lightbulb className="h-5 w-5 text-primary mr-2" />
                        Consigli Utili
                      </h3>
                      <ul className="space-y-2 ml-7 list-disc">
                        <li>Lavora in un'area ben ventilata, specialmente se usi colle o vernici.</li>
                        <li>Prepara tutti i materiali e strumenti prima di iniziare per evitare interruzioni.</li>
                        <li>Scatta foto durante il processo per documentare i progressi e condividerli.</li>
                        <li>Se hai dubbi, consulta il nostro assistente AI per suggerimenti personalizzati.</li>
                        <li>Alcuni passaggi potrebbero richiedere l'aiuto di un adulto (per bambini).</li>
                      </ul>
                    </div>
                    
                    {/* Benefici ambientali */}
                    <div>
                      <h3 className="text-md font-semibold mb-3">Benefici Ambientali</h3>
                      <div className="grid gap-3 sm:grid-cols-3">
                        <div className="bg-success bg-opacity-10 p-3 rounded-lg text-center">
                          <p className="text-2xl font-bold text-success">
                            {Array.isArray(project?.requiredMaterials) ? 
                              project.requiredMaterials.reduce((sum: number, m: any) => sum + (Number(m?.quantity) || 0), 0).toFixed(1) : 
                              "1"} kg
                          </p>
                          <p className="text-sm text-neutral-dark">Materiali Riciclati</p>
                        </div>
                        <div className="bg-primary bg-opacity-10 p-3 rounded-lg text-center">
                          <p className="text-2xl font-bold text-primary">15€</p>
                          <p className="text-sm text-neutral-dark">Risparmiati</p>
                        </div>
                        <div className="bg-secondary bg-opacity-10 p-3 rounded-lg text-center">
                          <p className="text-2xl font-bold text-secondary">5 kg</p>
                          <p className="text-sm text-neutral-dark">CO2 Risparmiata</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Alternative */}
                    <div>
                      <h3 className="text-md font-semibold mb-3">Varianti e Alternative</h3>
                      <div className="bg-neutral-lightest p-4 rounded-lg">
                        <p className="text-neutral-dark mb-3">
                          Se non hai tutti i materiali indicati, ecco alcune alternative che puoi considerare:
                        </p>
                        <ul className="space-y-2 ml-7 list-disc">
                          <li>Se non hai {Array.isArray(project?.requiredMaterials) && project?.requiredMaterials.length > 0 ? project?.requiredMaterials[0]?.name : 'il materiale principale'}, puoi sostituirlo con materiali simili come cartone, plastica riciclata o stoffa.</li>
                          <li>Per le colle, le alternative naturali includono la farina con acqua o la colla di riso.</li>
                          <li>Se non disponi di strumenti specifici, cerca alternative domestiche comuni o chiedi in prestito a vicini o amici.</li>
                          <li>Questo progetto può essere semplificato omettendo alcune decorazioni o dettagli non essenziali.</li>
                        </ul>
                      </div>
                    </div>
                    
                    {/* Condivisione */}
                    <div className="border-t pt-4">
                      <h3 className="text-md font-semibold mb-3">Condividi la tua creazione</h3>
                      <p className="text-neutral-medium mb-3">
                        Quando avrai completato il progetto, scatta una foto e condividila con la community! 
                        Usa l'hashtag #EcoMakerProject sui social media.
                      </p>
                      <div className="flex space-x-2">
                        <button className="bg-[#1877F2] text-white px-4 py-2 rounded-md text-sm flex items-center">
                          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                          </svg>
                          Facebook
                        </button>
                        <button className="bg-[#1DA1F2] text-white px-4 py-2 rounded-md text-sm flex items-center">
                          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                          </svg>
                          Twitter
                        </button>
                        <button className="bg-[#E4405F] text-white px-4 py-2 rounded-md text-sm flex items-center">
                          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                          </svg>
                          Instagram
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {project?.isCommunityProject && (
              <TabsContent value="division" className="space-y-4">
                <ProjectDivision project={project} participants={participants || []} />
              </TabsContent>
            )}
            
            <TabsContent value="materials" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Materiali Necessari</CardTitle>
                </CardHeader>
                <CardContent>
                  {Array.isArray(project?.requiredMaterials) && project?.requiredMaterials.length > 0 ? (
                    <>
                      <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg mb-6 border border-green-100">
                        <h3 className="text-green-800 font-medium mb-2 flex items-center">
                          <Recycle className="h-5 w-5 mr-2 text-green-600" />
                          Materiali e Sostenibilità
                        </h3>
                        <p className="text-sm text-green-700 mb-3">
                          Questo progetto riutilizza materiali che altrimenti potrebbero finire tra i rifiuti. 
                          Usando questi materiali, contribuisci a ridurre l'impatto ambientale e dai nuova vita a oggetti che hanno ancora potenziale.
                        </p>
                        <div className="flex flex-wrap items-center text-xs font-medium gap-2">
                          <span className="text-green-600 bg-white px-2 py-1 rounded-full shadow-sm">Rifiuti risparmiati: {project?.environmentalImpact?.materialsRecycled || 2.5} kg</span>
                          <span className="text-amber-600 bg-white px-2 py-1 rounded-full shadow-sm">CO2 evitata: {project?.environmentalImpact?.carbonFootprintReduction || 1.8} kg</span>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-neutral-medium mb-3 text-sm">
                          Assicurati di raccogliere tutti questi materiali prima di iniziare. Puoi anche trovare alternative simili se non hai tutti gli elementi elencati.
                        </p>
                        
                        <div className="overflow-hidden rounded-lg border">
                          <table className="min-w-full divide-y divide-neutral-light">
                            <thead className="bg-neutral-lightest">
                              <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-medium uppercase tracking-wider">Materiale</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-medium uppercase tracking-wider">Quantità</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-medium uppercase tracking-wider">Note</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-neutral-light">
                              {project.requiredMaterials.map((material: any, index: number) => (
                                <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-neutral-lightest'}>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-dark">
                                    {material?.name || 'Materiale'}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-medium">
                                    {material?.quantity || 0} {material?.unit || 'pz'}
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-medium">
                                    {material?.notes || (index === 0 ? 'Materiale principale' : 'Materiale di supporto')}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      
                      {/* Alternative suggerite */}
                      <div className="bg-blue-50 p-4 rounded-lg mt-6 mb-6">
                        <h3 className="text-blue-800 font-medium mb-2">Alternative possibili</h3>
                        <ul className="list-disc pl-5 text-sm text-blue-700 space-y-1">
                          <li>Se non hai bottiglie di plastica, puoi utilizzare barattoli di vetro puliti</li>
                          <li>La colla vinilica può essere sostituita con colla a caldo per un fissaggio più rapido</li>
                          <li>Per i materiali decorativi, usa ciò che hai a disposizione: bottoni, stoffe, carta colorata</li>
                        </ul>
                      </div>
                      
                      <div className="bg-neutral-lightest p-4 rounded-lg mt-2">
                        <h3 className="text-sm font-semibold mb-2">Dove Trovare i Materiali</h3>
                        <p className="text-sm text-neutral-medium mb-2">
                          I materiali per questo progetto possono essere trovati facilmente in:
                        </p>
                        <ul className="space-y-1 ml-5 list-disc text-sm">
                          <li>Oggetti domestici di scarto o inutilizzati</li>
                          <li>Negozi di bricolage e fai-da-te</li>
                          <li>Mercatini dell'usato o gruppi di scambio</li>
                          <li>Consulta la sezione "Impatto" per opzioni di acquisto online</li>
                        </ul>
                      </div>
                    </>
                  ) : (
                    <div className="text-neutral-medium text-center py-6">
                      <p>Nessun materiale specificato per questo progetto.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center">
                    <Hammer className="h-5 w-5 mr-2 text-secondary" />
                    Strumenti Necessari
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {Array.isArray(project?.requiredTools) && project?.requiredTools.length > 0 ? (
                    <>
                      <div className="bg-violet-50 p-4 rounded-lg mb-6 border border-violet-100">
                        <h3 className="text-violet-800 font-medium mb-2">Sicurezza prima di tutto</h3>
                        <p className="text-sm text-violet-700 mb-2">
                          Quando usi gli strumenti, assicurati di seguire sempre le istruzioni di sicurezza. Indossa occhiali protettivi 
                          quando necessario e usa i guanti per proteggere le mani durante il lavoro con materiali taglienti.
                        </p>
                        <div className="flex items-center text-xs font-medium mt-2">
                          <span className="bg-white px-2 py-1 rounded-full shadow-sm text-violet-600">Leggi sempre le istruzioni degli strumenti</span>
                        </div>
                      </div>
                      
                      <p className="text-neutral-medium mb-4 text-sm">
                        Questi strumenti ti aiuteranno a completare il progetto con efficienza e precisione. Se non hai accesso a tutti gli strumenti, considera alternative o l'utilizzo di servizi di prestito di attrezzi nella tua comunità.
                      </p>
                      
                      <div className="grid gap-3 sm:grid-cols-2 mb-4">
                        {project.requiredTools.map((tool: any, index: number) => (
                          <div key={index} className="flex items-start p-3 border border-neutral-200 rounded-lg hover:border-secondary/30 hover:bg-neutral-lightest transition-all">
                            <div className="mr-3 bg-secondary bg-opacity-10 p-2 rounded-full mt-1">
                              <Hammer className="h-5 w-5 text-secondary" />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start">
                                <p className="font-medium">{tool?.name || 'Strumento'}</p>
                                {index < 2 && (
                                  <Badge variant="outline" className="ml-2 text-xs">
                                    Essenziale
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-neutral-medium mb-1">
                                {tool?.description || 'Necessario per il progetto'}
                              </p>
                              <p className="text-xs text-neutral-medium/80 italic">
                                Utilizzato per: {tool?.usage || `Fase ${index + 1} del progetto`}
                              </p>
                              <div className="mt-2 flex gap-2">
                                {tool?.link && (
                                  <a href={tool.link} target="_blank" rel="noopener noreferrer" className="text-secondary text-xs hover:underline flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    Maggiori informazioni
                                  </a>
                                )}
                                <a href="#" className="text-primary text-xs hover:underline flex items-center">
                                  <Search className="h-3 w-3 mr-1" />
                                  Trova alternative
                                </a>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-lg">
                        <h3 className="text-sm font-semibold mb-2 flex items-center">
                          <Lightbulb className="h-4 w-4 text-indigo-500 mr-2" />
                          Consigli sull'utilizzo degli strumenti
                        </h3>
                        <ul className="text-sm space-y-2 text-indigo-700 list-disc pl-5">
                          <li>Se alcuni strumenti sono troppo costosi per un uso occasionale, considera di prenderli in prestito da amici, vicini o da servizi di prestito attrezzi della tua città.</li>
                          <li>Molte biblioteche o centri comunitari offrono servizi di prestito attrezzi gratuiti o a basso costo.</li>
                          <li>Mantieni gli strumenti puliti e in buono stato per un utilizzo ottimale e una maggiore durata.</li>
                          <li>Ricorda di conservare gli strumenti fuori dalla portata dei bambini, in un luogo sicuro e asciutto.</li>
                        </ul>
                      </div>
                    </>
                  ) : (
                    <div className="text-neutral-medium text-center py-6">
                      <p>Nessuno strumento specificato per questo progetto.</p>
                      <p className="text-sm mt-2">Probabilmente saranno sufficienti strumenti comuni domestici.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="impact" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Impatto Ambientale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-neutral-lightest rounded p-4 text-center">
                      <div className="text-2xl font-bold text-primary">
                        {Array.isArray(project?.requiredMaterials) ? 
                          project.requiredMaterials.reduce((sum: number, m: any) => sum + (Number(m?.quantity) || 0), 0).toFixed(1) : 
                          "0"} kg
                      </div>
                      <div className="text-sm text-neutral-medium mt-1">Materiali Riutilizzati</div>
                    </div>
                    
                    <div className="bg-neutral-lightest rounded p-4 text-center">
                      <div className="text-2xl font-bold text-secondary">15€</div>
                      <div className="text-sm text-neutral-medium mt-1">Risparmio Stimato</div>
                    </div>
                    
                    <div className="bg-neutral-lightest rounded p-4 text-center">
                      <div className="text-2xl font-bold text-accent">5 kg</div>
                      <div className="text-sm text-neutral-medium mt-1">CO₂ Evitata</div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <p className="text-sm text-neutral-medium mb-4">
                      Creando questo progetto, contribuisci a ridurre i rifiuti e le emissioni di CO₂. 
                      Questo progetto ha un impatto ambientale positivo equivalente a piantare circa 0.25 alberi.
                    </p>
                    
                    <div className="bg-neutral-lightest p-4 rounded-lg mt-4">
                      <h3 className="text-md font-semibold mb-3">Dettagli dell'Impatto Ambientale</h3>
                      <ul className="space-y-2 ml-5 list-disc">
                        <li>Riduzione di circa {Array.isArray(project?.requiredMaterials) ? 
                            project.requiredMaterials.reduce((sum: number, m: any) => sum + (Number(m?.quantity) || 0), 0) : 
                            "0"} kg di rifiuti che sarebbero finiti in discarica</li>
                        <li>Risparmio di circa 15€ rispetto all'acquisto di un prodotto nuovo simile</li>
                        <li>Minore impronta di carbonio rispetto alla produzione di un nuovo oggetto</li>
                        <li>Sensibilizzazione e promozione di uno stile di vita più sostenibile</li>
                        <li>Condivisione di competenze e conoscenze sulla sostenibilità</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-md font-semibold mb-3">Acquista Materiali & Strumenti</h3>
                    {productsLoading ? (
                      <div className="space-y-2">
                        <Skeleton className="h-24 w-full" />
                        <Skeleton className="h-24 w-full" />
                      </div>
                    ) : (
                      <>
                        {Array.isArray(products) && products.length > 0 ? (
                          <div className="space-y-4">
                            {products.slice(0, 2).map((product, index) => (
                              <div key={index} className="mb-3">
                                {/* Utilizziamo l'API corretta del widget passando un array */}
                                <AmazonProductWidget 
                                  products={[product]}
                                  title={`Prodotto suggerito ${index + 1}`}
                                  description="Materiale o strumento consigliato per questo progetto"
                                />
                              </div>
                            ))}
                            {products.length > 2 && (
                              <div className="text-center">
                                <button
                                  onClick={() => document.querySelector('[value="shop"]')?.dispatchEvent(new Event('click'))}
                                  className="text-primary hover:underline text-sm font-medium"
                                >
                                  Visualizza altri {products.length - 2} prodotti consigliati →
                                </button>
                              </div>
                            )}
                          </div>
                        ) : (
                          <p className="text-neutral-medium text-center py-4">
                            Nessun prodotto consigliato disponibile.
                          </p>
                        )}
                      </>
                    )}
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-md font-semibold mb-3">Lista della Spesa</h3>
                    <div className="border border-dashed border-neutral-medium p-4 rounded-lg bg-white">
                      <h4 className="text-center font-semibold mb-3">{project?.name || 'Progetto Sostenibile'}</h4>
                      <div className="mb-3">
                        <h5 className="font-medium mb-1">Materiali:</h5>
                        <ul className="list-disc ml-5">
                          {Array.isArray(project?.requiredMaterials) && project?.requiredMaterials.map((material: any, index: number) => (
                            <li key={index}>{material?.name || 'Materiale'} - {material?.quantity || 0} {material?.unit || 'pz'}</li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h5 className="font-medium mb-1">Strumenti:</h5>
                        <ul className="list-disc ml-5">
                          {Array.isArray(project?.requiredTools) && project?.requiredTools.map((tool: any, index: number) => (
                            <li key={index}>{tool?.name || 'Strumento'}</li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="mt-3 flex justify-end">
                        <button className="text-primary text-sm hover:underline flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                          Scarica come PDF
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="ar-preview" className="space-y-4">
              <Card className="mb-4">
                <CardHeader>
                  <CardTitle className="text-lg font-medium flex items-center">
                    <Box className="h-5 w-5 mr-2 text-primary" />
                    Visualizzazione in Realtà Aumentata
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-purple-50 p-4 rounded-lg mb-6 border border-purple-100">
                    <h3 className="text-purple-800 font-medium mb-2">Come funziona</h3>
                    <p className="text-sm text-purple-700 mb-3">
                      La visualizzazione in realtà aumentata ti permette di vedere come sarà trasformato il materiale di scarto in un nuovo oggetto. 
                      Usa i controlli sotto per ruotare e ingrandire il modello 3D e vedere le diverse fasi del progetto.
                    </p>
                    <div className="flex items-center text-xs font-medium gap-2 flex-wrap">
                      <span className="text-purple-600 bg-white px-2 py-1 rounded-full shadow-sm">Usa il mouse per ruotare</span>
                      <span className="text-purple-600 bg-white px-2 py-1 rounded-full shadow-sm">Scorri per ingrandire</span>
                      <span className="text-purple-600 bg-white px-2 py-1 rounded-full shadow-sm">Usa i controlli sotto per cambiare fase</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <ARTransformPreview
                projectName={project?.name || 'Progetto'}
                projectDescription={project?.description || ''}
                beforeImage={project?.beforeImageUrl || ""}
                afterImage={project?.imageUrl || ""}
                modelType={getMaterialModelType(project)}
                stages={[
                  {
                    title: "Materiale originale",
                    description: "Il materiale di partenza prima della trasformazione",
                    modelType: getMaterialModelType(project),
                    imageUrl: project?.beforeImageUrl || ""
                  },
                  {
                    title: "Progetto completato",
                    description: "Il progetto di upcycling dopo la trasformazione",
                    modelType: project?.category?.toLowerCase() || "box",
                    imageUrl: project?.imageUrl || ""
                  }
                ]}
              />
              
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-3">Prova la visione completa in AR</h3>
                <p className="text-neutral-medium mb-4 text-sm">
                  Per una esperienza AR immersiva su dispositivi mobili, prova la nostra funzionalità di Realtà Aumentata completa che ti permette di visualizzare il progetto nel tuo ambiente reale.
                </p>
                <div className="flex justify-center gap-3">
                  <Link href={`/ar-material-visualization?materialId=${getMaterialId(project)}`}>
                    <Button className="bg-primary text-white flex items-center">
                      <Box className="h-4 w-4 mr-2" />
                      Apri visualizzazione AR immersiva
                    </Button>
                  </Link>
                  <Button 
                    variant="outline"
                    className="border-primary text-primary flex items-center"
                    onClick={() => {
                      // Copia il link per la visualizzazione AR
                      const link = `${window.location.origin}/ar-material-visualization?materialId=${getMaterialId(project)}`;
                      navigator.clipboard.writeText(link);
                      alert("Link copiato negli appunti! Puoi inviarlo al tuo dispositivo mobile.");
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    Copia link per mobile
                  </Button>
                </div>
              </div>
              
              <div className="mt-6 grid sm:grid-cols-2 gap-6">
                <div className="p-4 bg-neutral-lightest rounded-lg">
                  <h3 className="text-sm font-semibold mb-2">Come funziona l'AR su questo dispositivo</h3>
                  <ol className="list-decimal ml-5 text-sm space-y-1 text-left">
                    <li>Clicca sul pulsante "Apri visualizzazione AR immersiva"</li>
                    <li>Consenti l'accesso alla fotocamera</li>
                    <li>Punta la fotocamera verso una superficie piana</li>
                    <li>Quando appare l'indicatore, tocca lo schermo per posizionare il modello</li>
                    <li>Pizzica per ridimensionare e trascina per riposizionare</li>
                  </ol>
                </div>
                
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h3 className="text-sm font-semibold text-blue-800 mb-2">Visualizza su dispositivo mobile</h3>
                  <ol className="list-decimal ml-5 text-sm space-y-1 text-left text-blue-700">
                    <li>Clicca sul pulsante "Copia link per mobile"</li>
                    <li>Invia il link al tuo telefono (via email, messaggio, ecc.)</li>
                    <li>Apri il link sul dispositivo mobile</li>
                    <li>Consenti l'accesso alla fotocamera</li>
                    <li>La visualizzazione AR funziona meglio sui dispositivi mobili recenti</li>
                  </ol>
                  <div className="mt-3 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 mr-2">
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span className="text-xs text-blue-600">L'AR su dispositivi mobili offre un'esperienza più immersiva</span>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-6">
          {/* Project Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Informazioni Progetto</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Tempo stimato</div>
                  <div className="text-sm text-neutral-medium">
                    {project?.estimatedTime || '?'} {project?.timeUnit || 'ore'}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Tag className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Difficoltà</div>
                  <div className="text-sm text-neutral-medium">
                    {project?.difficulty || 'Non specificata'}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Data creazione</div>
                  <div className="text-sm text-neutral-medium">
                    {project?.createdAt ? new Date(project.createdAt).toLocaleDateString('it-IT') : 'Non disponibile'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Amazon Products Recommendations */}
          {(materialNames.length > 0 || toolNames.length > 0) && (
          <AmazonProductWidget 
            products={products || []}
            isLoading={productsLoading}
            title="Materiali e Strumenti Consigliati"
            description="Prodotti correlati a questo progetto che potrebbero servirti"
          />
          )}
          
          {/* Participants Card (for community projects) */}
          {project?.isCommunityProject && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Partecipanti</CardTitle>
              </CardHeader>
              <CardContent>
                {participantsLoading ? (
                  <Skeleton className="h-20 w-full" />
                ) : (
                  <>
                    <div className="mb-4">
                      <AvatarGroup
                        items={[
                          { fallback: "A" },
                          { fallback: "B" },
                          { fallback: "C" },
                          { fallback: "D" },
                          { fallback: "E" },
                        ]}
                        max={5}
                      />
                    </div>
                    <div className="text-sm text-neutral-medium">
                      {participants?.length || 0} partecipanti al progetto
                    </div>
                  </>
                )}
              </CardContent>
              <CardFooter>
                {isUserParticipant ? (
                  <Button className="w-full bg-accent bg-opacity-20 text-accent" disabled>
                    Hai già aderito al progetto
                  </Button>
                ) : (
                  <Button 
                    className="w-full bg-accent text-white"
                    onClick={handleJoinProject}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Unisciti al progetto
                  </Button>
                )}
              </CardFooter>
            </Card>
          )}
          
          {/* Related Events Card (for community projects) */}
          {project?.isCommunityProject && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Eventi Correlati</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3 border-b pb-3">
                    <div className="h-12 w-12 rounded-md bg-primary flex flex-col items-center justify-center text-white">
                      <span className="text-sm font-bold">15</span>
                      <span className="text-xs">Giu</span>
                    </div>
                    <div>
                      <div className="font-medium">Workshop di riciclo creativo</div>
                      <div className="text-sm text-neutral-medium">Centro culturale, Milano</div>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="h-12 w-12 rounded-md bg-accent flex flex-col items-center justify-center text-white">
                      <span className="text-sm font-bold">22</span>
                      <span className="text-xs">Giu</span>
                    </div>
                    <div>
                      <div className="font-medium">Raccolta plastica in spiaggia</div>
                      <div className="text-sm text-neutral-medium">Spiaggia Libera, Rimini</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Vedi tutti gli eventi
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </PageLayout>
  );
}
