import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Camera, 
  Scan, 
  Eye, 
  Layers, 
  Box, 
  RotateCw,
  Zap,
  Sparkles,
  Target,
  Maximize,
  Play,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Settings,
  Info,
  CheckCircle,
  AlertCircle,
  Search,
  Filter,
  Download
} from 'lucide-react';

interface ARMaterial {
  id: string;
  name: string;
  type: string;
  confidence: number;
  position: { x: number; y: number; z: number };
  dimensions: { width: number; height: number; depth: number };
  color: string;
  texture: string;
  recyclable: boolean;
  condition: 'excellent' | 'good' | 'fair' | 'poor';
  estimatedValue: number;
  possibleUses: string[];
  arModel: string;
  scanQuality: number;
  metadata: {
    density: number;
    flexibility: string;
    transparency: number;
    surfaceRoughness: string;
  };
}

interface ScanSession {
  id: string;
  timestamp: Date;
  materials: ARMaterial[];
  totalConfidence: number;
  scanDuration: number;
  environmentLighting: string;
  deviceOrientation: string;
}

export default function ARMaterialScanPreview() {
  const [isScanning, setIsScanning] = useState(false);
  const [arMode, setArMode] = useState<'camera' | 'preview' | '3d'>('camera');
  const [detectedMaterials, setDetectedMaterials] = useState<ARMaterial[]>([]);
  const [scanProgress, setScanProgress] = useState(0);
  const [selectedMaterial, setSelectedMaterial] = useState<ARMaterial | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanSession[]>([]);
  const [arSettings, setArSettings] = useState({
    showBoundingBoxes: true,
    showConfidenceLabels: true,
    showMeasurements: true,
    enableDepthMaps: true,
    highlightRecyclables: true
  });
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Simula materiali AR rilevati
    const sampleMaterials: ARMaterial[] = [
      {
        id: 'mat_001',
        name: 'Bottiglia Plastica PET',
        type: 'plastica',
        confidence: 94.5,
        position: { x: 0.2, y: 0.1, z: 0.5 },
        dimensions: { width: 6.5, height: 24.0, depth: 6.5 },
        color: 'trasparente',
        texture: 'liscia',
        recyclable: true,
        condition: 'good',
        estimatedValue: 0.05,
        possibleUses: ['Vaso per piante', 'Contenitore organizer', 'Mangiatoia uccelli'],
        arModel: 'bottle_pet_500ml.glb',
        scanQuality: 92,
        metadata: {
          density: 1.38,
          flexibility: 'rigida',
          transparency: 85,
          surfaceRoughness: 'bassa'
        }
      },
      {
        id: 'mat_002',
        name: 'Lattina Alluminio',
        type: 'metallo',
        confidence: 98.2,
        position: { x: -0.1, y: 0.0, z: 0.3 },
        dimensions: { width: 6.6, height: 12.3, depth: 6.6 },
        color: 'argentato',
        texture: 'metallica',
        recyclable: true,
        condition: 'excellent',
        estimatedValue: 0.15,
        possibleUses: ['Portapenne', 'Amplificatore smartphone', 'Decorazione giardino'],
        arModel: 'can_aluminum_330ml.glb',
        scanQuality: 96,
        metadata: {
          density: 2.70,
          flexibility: 'rigida',
          transparency: 0,
          surfaceRoughness: 'media'
        }
      },
      {
        id: 'mat_003',
        name: 'Scatola Cartone',
        type: 'carta',
        confidence: 87.8,
        position: { x: 0.0, y: -0.05, z: 0.8 },
        dimensions: { width: 15.0, height: 10.0, depth: 20.0 },
        color: 'marrone',
        texture: 'rugosa',
        recyclable: true,
        condition: 'fair',
        estimatedValue: 0.02,
        possibleUses: ['Organizer cassetti', 'Base per progetti', 'Compostaggio'],
        arModel: 'box_cardboard_medium.glb',
        scanQuality: 85,
        metadata: {
          density: 0.85,
          flexibility: 'flessibile',
          transparency: 0,
          surfaceRoughness: 'alta'
        }
      }
    ];

    setDetectedMaterials(sampleMaterials);

    // Simula sessioni di scan precedenti
    const sessions: ScanSession[] = [
      {
        id: 'session_001',
        timestamp: new Date('2024-06-22T09:15:00'),
        materials: sampleMaterials,
        totalConfidence: 93.5,
        scanDuration: 12.5,
        environmentLighting: 'ottimale',
        deviceOrientation: 'verticale'
      }
    ];

    setScanHistory(sessions);
  }, []);

  const startARScan = async () => {
    setIsScanning(true);
    setScanProgress(0);

    // Simula processo di scan con progress
    const scanInterval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(scanInterval);
          setIsScanning(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // Simula accesso camera (se disponibile)
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          } 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }
    } catch (error) {
      console.log('Camera access not available, using simulation');
    }
  };

  const stopARScan = () => {
    setIsScanning(false);
    setScanProgress(0);
    
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-400 bg-green-500/20';
    if (confidence >= 70) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-red-400 bg-red-500/20';
  };

  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case 'excellent': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'good': return <CheckCircle className="w-4 h-4 text-blue-400" />;
      case 'fair': return <AlertCircle className="w-4 h-4 text-yellow-400" />;
      case 'poor': return <AlertCircle className="w-4 h-4 text-red-400" />;
      default: return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-8 min-h-screen futuristic-bg">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
          AR Material Scan Preview
        </h1>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
          Scansiona materiali in tempo reale con realtà aumentata e visualizza progetti di trasformazione in 3D
        </p>
      </div>

      {/* Control Panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-morph border-cyan-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-cyan-300 flex items-center">
              <Camera className="w-5 h-5 mr-2" />
              Controlli Scan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={startARScan}
                disabled={isScanning}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              >
                {isScanning ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isScanning ? 'Stop' : 'Avvia'}
              </Button>
              
              <Button
                onClick={stopARScan}
                variant="outline"
                className="border-red-500/30 text-red-400"
              >
                <Square className="w-4 h-4 mr-1" />
                Reset
              </Button>
            </div>

            {isScanning && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Scan Progress</span>
                  <span className="text-cyan-400">{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2" />
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm text-gray-400">Modalità AR</label>
              <div className="grid grid-cols-3 gap-1">
                <Button
                  size="sm"
                  variant={arMode === 'camera' ? 'default' : 'outline'}
                  onClick={() => setArMode('camera')}
                >
                  <Camera className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant={arMode === 'preview' ? 'default' : 'outline'}
                  onClick={() => setArMode('preview')}
                >
                  <Eye className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant={arMode === '3d' ? 'default' : 'outline'}
                  onClick={() => setArMode('3d')}
                >
                  <Box className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-morph border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-purple-300 flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Impostazioni AR
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(arSettings).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm text-gray-300 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                </span>
                <Button
                  size="sm"
                  variant={value ? 'default' : 'outline'}
                  onClick={() => setArSettings(prev => ({ ...prev, [key]: !value }))}
                  className="h-6 w-12"
                >
                  {value ? 'ON' : 'OFF'}
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass-morph border-green-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-green-300 flex items-center">
              <Target className="w-5 h-5 mr-2" />
              Statistiche Scan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Materiali Rilevati</span>
              <span className="text-green-400 font-semibold">{detectedMaterials.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Confidenza Media</span>
              <span className="text-blue-400 font-semibold">
                {detectedMaterials.length > 0 
                  ? Math.round(detectedMaterials.reduce((sum, m) => sum + m.confidence, 0) / detectedMaterials.length)
                  : 0}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Riciclabili</span>
              <span className="text-green-400 font-semibold">
                {detectedMaterials.filter(m => m.recyclable).length}/{detectedMaterials.length}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AR Camera/Preview Area */}
      <Card className="glass-morph border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-blue-300 flex items-center">
            <Scan className="w-5 h-5 mr-2" />
            Area di Scansione AR
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative w-full h-96 bg-gray-900 rounded-lg overflow-hidden">
            {/* Camera Feed */}
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              autoPlay
              muted
              playsInline
            />
            
            {/* AR Overlay Canvas */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none"
            />

            {/* AR Bounding Boxes Simulation */}
            {arSettings.showBoundingBoxes && detectedMaterials.map((material) => (
              <div
                key={material.id}
                className="absolute border-2 border-cyan-400 rounded"
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: `${20 + Math.random() * 60}%`,
                  width: `${10 + Math.random() * 20}%`,
                  height: `${15 + Math.random() * 25}%`,
                  animation: 'pulse 2s infinite'
                }}
              >
                {arSettings.showConfidenceLabels && (
                  <div className="absolute -top-8 left-0 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {material.name} ({material.confidence.toFixed(1)}%)
                  </div>
                )}
                
                {arSettings.showMeasurements && (
                  <div className="absolute -bottom-6 left-0 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {material.dimensions.width}×{material.dimensions.height}cm
                  </div>
                )}
              </div>
            ))}

            {/* Scan Indicator */}
            {isScanning && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  <div className="w-32 h-32 border-4 border-cyan-400 rounded-full animate-ping opacity-50"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Scan className="w-8 h-8 text-cyan-400 animate-spin" />
                  </div>
                </div>
              </div>
            )}

            {/* No Camera Fallback */}
            {!isScanning && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-800/50">
                <div className="text-center text-gray-400">
                  <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>Premi "Avvia" per iniziare la scansione AR</p>
                  <p className="text-sm">Punta la camera verso i materiali da analizzare</p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Detected Materials */}
      <Card className="glass-morph border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-yellow-300 flex items-center">
            <Layers className="w-5 h-5 mr-2" />
            Materiali Rilevati
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {detectedMaterials.map((material) => (
              <Card
                key={material.id}
                className={`glass-morph cursor-pointer transition-all duration-300 hover:scale-105 ${
                  selectedMaterial?.id === material.id ? 'border-cyan-500' : 'border-gray-600/30'
                }`}
                onClick={() => setSelectedMaterial(material)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm text-white">{material.name}</CardTitle>
                    {getConditionIcon(material.condition)}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={`text-xs ${getConfidenceColor(material.confidence)}`}>
                      {material.confidence.toFixed(1)}%
                    </Badge>
                    {material.recyclable && (
                      <Badge className="bg-green-500/20 text-green-400 text-xs">
                        Riciclabile
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-xs text-gray-400">
                    <div>Tipo: {material.type}</div>
                    <div>Dimensioni: {material.dimensions.width}×{material.dimensions.height}×{material.dimensions.depth}cm</div>
                    <div>Valore stimato: €{material.estimatedValue.toFixed(2)}</div>
                    <div>Qualità scan: {material.scanQuality}%</div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-xs text-gray-400">Possibili usi:</div>
                    <div className="flex flex-wrap gap-1">
                      {material.possibleUses.slice(0, 2).map((use, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {use}
                        </Badge>
                      ))}
                      {material.possibleUses.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{material.possibleUses.length - 2}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Material Detail Panel */}
      {selectedMaterial && (
        <Card className="glass-morph border-cyan-500/30">
          <CardHeader>
            <CardTitle className="text-xl text-cyan-300 flex items-center">
              <Info className="w-5 h-5 mr-2" />
              Dettagli Materiale: {selectedMaterial.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Proprietà Fisiche</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Densità:</span>
                      <span className="text-white">{selectedMaterial.metadata.density} g/cm³</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Flessibilità:</span>
                      <span className="text-white">{selectedMaterial.metadata.flexibility}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Trasparenza:</span>
                      <span className="text-white">{selectedMaterial.metadata.transparency}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Rugosità:</span>
                      <span className="text-white">{selectedMaterial.metadata.surfaceRoughness}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Informazioni Scan</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Posizione AR:</span>
                      <span className="text-white">
                        x:{selectedMaterial.position.x.toFixed(2)} y:{selectedMaterial.position.y.toFixed(2)} z:{selectedMaterial.position.z.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Qualità scan:</span>
                      <span className="text-white">{selectedMaterial.scanQuality}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Modello 3D:</span>
                      <span className="text-white">{selectedMaterial.arModel}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Progetti Suggeriti</h3>
                  <div className="space-y-2">
                    {selectedMaterial.possibleUses.map((use, index) => (
                      <div key={index} className="flex items-center space-x-3 p-2 rounded-lg glass-morph">
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                        <span className="text-white text-sm">{use}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                    <Box className="w-4 h-4 mr-2" />
                    Visualizza 3D
                  </Button>
                  <Button variant="outline" className="flex-1 border-green-500/30 text-green-400">
                    <Download className="w-4 h-4 mr-2" />
                    Esporta Dati
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes scanPulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.05); opacity: 0.7; }
          }
          
          .scan-pulse {
            animation: scanPulse 2s infinite;
          }
        `
      }} />
    </div>
  );
}