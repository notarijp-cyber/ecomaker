import React, { useState } from "react";
import { Link } from "wouter";
import { PageLayout } from "@/components/layout/page-layout";
import { useMaterialInventory } from "@/hooks/use-material-inventory";
import { MaterialCard } from "@/components/project/material-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search, Database, Package, Eye } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { MaterialScanner } from "@/components/scanning/material-scanner";

export default function Inventory() {
  const userId = 1; // Placeholder for now
  const { materials, materialTypes, isLoading } = useMaterialInventory(userId);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [showScanner, setShowScanner] = useState(false);
  
  // Filter materials based on search
  const filteredMaterials = materials?.filter(material => 
    material.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (material.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false)
  );
  
  // Group materials by type
  const materialsByType = materialTypes?.map(type => ({
    type,
    materials: filteredMaterials?.filter(m => m.typeId === type.id) || []
  })) || [];
  
  // Split between user materials and company materials
  const userMaterials = filteredMaterials?.filter(m => !m.companyId) || [];
  const companyMaterials = filteredMaterials?.filter(m => m.companyId) || [];
  
  return (
    <PageLayout>
      <div className="mb-8">
        <h2 className="text-2xl font-heading font-bold mb-2">Il Mio Inventario</h2>
        <p className="text-neutral-medium">
          Gestisci i materiali che hai a disposizione per i tuoi progetti.
        </p>
      </div>
      
      {/* Search bar and action buttons */}
      <div className="mb-6 flex space-x-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
          <Input
            placeholder="Cerca materiali..."
            className="pl-10 bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Link href="/ar-material-visualization">
          <Button 
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Eye className="h-4 w-4 mr-2" />
            Visualizza in AR
          </Button>
        </Link>
        <Button 
          className="bg-primary text-white"
          onClick={() => setShowScanner(true)}
        >
          <Package className="h-4 w-4 mr-2" />
          Aggiungi
        </Button>
      </div>
      
      {/* Inventory tabs */}
      <Tabs defaultValue="my-materials" className="space-y-6">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="my-materials">
            I Miei Materiali ({userMaterials.length})
          </TabsTrigger>
          <TabsTrigger value="company-materials">
            Materiali Aziende ({companyMaterials.length})
          </TabsTrigger>
          <TabsTrigger value="by-type">
            Per Tipologia
          </TabsTrigger>
        </TabsList>
        
        {/* My Materials Tab */}
        <TabsContent value="my-materials" className="space-y-6">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
          ) : userMaterials.length === 0 ? (
            <div className="text-center py-10">
              <Database className="h-16 w-16 text-neutral-medium mx-auto mb-4" />
              <h3 className="text-lg font-heading font-medium mb-2">
                Nessun materiale trovato
              </h3>
              <p className="text-neutral-medium">
                Aggiungi nuovi materiali al tuo inventario usando la fotocamera.
              </p>
              <Button 
                className="mt-4 bg-primary text-white"
                onClick={() => setShowScanner(true)}
              >
                Scansiona Materiale
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {userMaterials.map(material => (
                <MaterialCard key={material.id} material={material} />
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Company Materials Tab */}
        <TabsContent value="company-materials" className="space-y-6">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
          ) : companyMaterials.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">
                Nessun materiale aziendale disponibile
              </h3>
              <p className="text-neutral-medium">
                Al momento non ci sono materiali disponibili dalle aziende.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {companyMaterials.map(material => (
                <MaterialCard key={material.id} material={material} />
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* By Type Tab */}
        <TabsContent value="by-type" className="space-y-8">
          {isLoading ? (
            <div className="space-y-8">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="space-y-3">
                  <Skeleton className="h-8 w-32" />
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Skeleton className="h-64 w-full" />
                    <Skeleton className="h-64 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : materialsByType.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">
                Nessun tipo di materiale trovato
              </h3>
            </div>
          ) : (
            materialsByType.map(({ type, materials }) => (
              materials.length > 0 && (
                <div key={type.id} className="space-y-3">
                  <h3 className="text-lg font-heading font-medium flex items-center">
                    <span
                      className="w-4 h-4 rounded-full mr-2"
                      style={{ backgroundColor: type.color || '#ccc' }}
                    ></span>
                    {type.name} ({materials.length})
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {materials.map(material => (
                      <MaterialCard key={material.id} material={material} />
                    ))}
                  </div>
                </div>
              )
            ))
          )}
        </TabsContent>
      </Tabs>
      
      {showScanner && (
        <MaterialScanner onClose={() => setShowScanner(false)} />
      )}
    </PageLayout>
  );
}
