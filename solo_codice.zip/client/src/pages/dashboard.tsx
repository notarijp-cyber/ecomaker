import React from "react";
import { PageLayout } from "@/components/layout/page-layout";
import { WelcomeSection } from "@/components/dashboard/welcome-section";
import { ActionSection } from "@/components/dashboard/action-section";
import { SuggestedProjects } from "@/components/dashboard/suggested-projects";
import { CommunityProjects } from "@/components/dashboard/community-projects";
import { CompanyMaterials } from "@/components/dashboard/company-materials";
import { UpcomingEvents } from "@/components/dashboard/upcoming-events";
import { SmartNotifications } from "@/components/dashboard/smart-notifications";
import { AIRecommendations } from "@/components/dashboard/ai-recommendations";
import { AchievementSystem } from "@/components/dashboard/achievement-toast";
import { SocialSharing } from "@/components/dashboard/social-sharing";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  // Using a placeholder user id for now
  // In a real app, this would come from auth context or similar
  const userId = 1;
  
  return (
    <div className="min-h-screen futuristic-bg">
      <PageLayout showTabs={false}>
        {/* Welcome Section with Environmental Impact */}
        <div className="glass-morph p-6 mb-8 hologram-effect">
          <WelcomeSection userId={userId} />
        </div>
        
        {/* Main content in a grid layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Scan Materials and Create Project Cards */}
            <div className="floating-card">
              <ActionSection />
            </div>
            
            {/* Suggested Projects Section */}
            <div className="floating-card">
              <SuggestedProjects />
            </div>
          </div>
          
          <div className="space-y-8">
            {/* Advanced Features Quick Access */}
            <div className="glass-morph p-6 neon-border-cyan">
              <div className="flex items-center gap-3 mb-6">
                <Zap className="w-6 h-6 text-cyan-400" />
                <h3 className="holographic-text text-xl font-bold">
                  Funzionalità AI Quantum
                </h3>
                <Badge className="energy-field text-white px-3 py-1 text-xs font-semibold rounded-full">
                  NOVA
                </Badge>
              </div>
              
              <p className="text-cyan-100 mb-6 text-sm leading-relaxed">
                Scopri l'ecosistema AI più avanzato: raccomandazioni neurali, tracker sostenibilità quantico e monitoraggio prestazioni in tempo reale!
              </p>
              
              <div className="space-y-4">
                <Link href="/smart-recommendations">
                  <button className="cyber-button w-full text-left p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
                        <span className="text-lg">🧠</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Raccomandazioni AI</div>
                        <div className="text-xs text-cyan-200">Suggerimenti neurali personalizzati</div>
                      </div>
                    </div>
                  </button>
                </Link>
                
                <Link href="/advanced-sustainability">
                  <button className="cyber-button w-full text-left p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center">
                        <span className="text-lg">📊</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Tracker Sostenibilità</div>
                        <div className="text-xs text-cyan-200">Metriche ambientali quantiche</div>
                      </div>
                    </div>
                  </button>
                </Link>
                
                <Link href="/performance-monitor">
                  <button className="cyber-button w-full text-left p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center">
                        <span className="text-lg">⚡</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Monitor Prestazioni</div>
                        <div className="text-xs text-cyan-200">Analisi in tempo reale</div>
                      </div>
                    </div>
                  </button>
                </Link>
              </div>
            </div>
          
            {/* Right sidebar content with futuristic styling */}
            <div className="floating-card neon-border-green">
              <SmartNotifications userId={userId} />
            </div>
            
            <div className="floating-card neon-border-purple">
              <AIRecommendations userId={userId} />
            </div>
            
            <div className="glass-morph p-6">
              <SocialSharing userId={userId} />
            </div>
            
            <div className="floating-card circuit-pattern">
              <CompanyMaterials />
            </div>
            
            <div className="glass-morph p-6 pulse-glow">
              <UpcomingEvents />
            </div>
          </div>
        </div>
        
        {/* Full width community section with futuristic styling */}
        <div className="mt-12">
          <div className="floating-card hologram-effect">
            <CommunityProjects />
          </div>
        </div>
        
        {/* Achievement System */}
        <AchievementSystem userId={userId} />
      </PageLayout>
    </div>
  );
}
