import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageLayout } from "@/components/layout/page-layout";
import { Event } from "@/lib/types";
import { EventCard } from "@/components/event/event-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar as CalendarIcon, Search, Plus, Users, Map } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { it } from "date-fns/locale";

export default function Events() {
  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ['/api/events'],
  });
  
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const [searchTerm, setSearchTerm] = useState("");
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [location, setLocation] = useState<string>("");
  
  // Filter events based on search, date, and location
  const filteredEvents = events?.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           (event.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false);
    
    const matchesDate = date ? new Date(event.date).toDateString() === date.toDateString() : true;
    
    const matchesLocation = location && location !== "all" ? 
                           (event.location?.toLowerCase().includes(location.toLowerCase()) || false) : 
                           true;
    
    return matchesSearch && matchesDate && matchesLocation;
  });
  
  // Split events into upcoming and past
  const now = new Date();
  const upcomingEvents = filteredEvents
    ?.filter(event => new Date(event.date) >= now)
    ?.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
  const pastEvents = filteredEvents
    ?.filter(event => new Date(event.date) < now)
    ?.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  return (
    <PageLayout>
      <div className="mb-8">
        <h2 className="text-2xl font-heading font-bold mb-2">Eventi</h2>
        <p className="text-neutral-medium">
          Scopri e partecipa agli eventi dedicati al riciclo e alla sostenibilità.
        </p>
      </div>
      
      {/* Filters and view toggle */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
            <Input
              placeholder="Cerca eventi..."
              className="pl-10 bg-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="justify-start text-left font-normal flex-shrink-0 sm:w-[200px]"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP", { locale: it }) : "Seleziona data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Select value={location} onValueChange={setLocation}>
            <SelectTrigger className="flex-shrink-0 sm:w-[200px]">
              <div className="flex items-center">
                <Map className="mr-2 h-4 w-4" />
                {location || "Tutte le località"}
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutte le località</SelectItem>
              <SelectItem value="milano">Milano</SelectItem>
              <SelectItem value="roma">Roma</SelectItem>
              <SelectItem value="firenze">Firenze</SelectItem>
              <SelectItem value="rimini">Rimini</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex">
            <Button
              variant={view === 'list' ? "default" : "outline"}
              className={`rounded-r-none ${view === 'list' ? 'bg-primary' : ''}`}
              onClick={() => setView('list')}
            >
              Lista
            </Button>
            <Button
              variant={view === 'calendar' ? "default" : "outline"}
              className={`rounded-l-none ${view === 'calendar' ? 'bg-primary' : ''}`}
              onClick={() => setView('calendar')}
            >
              Calendario
            </Button>
          </div>
          
          <Button className="bg-primary text-white">
            <Plus className="h-4 w-4 mr-2" />
            Crea Evento
          </Button>
        </div>
      </div>
      
      {view === 'list' ? (
        <Tabs defaultValue="upcoming" className="space-y-6">
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="upcoming" className="flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Prossimi Eventi ({upcomingEvents?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="past" className="flex items-center">
              <CalendarIcon className="h-4 w-4 mr-2" />
              Eventi Passati ({pastEvents?.length || 0})
            </TabsTrigger>
          </TabsList>
          
          {/* Upcoming Events Tab */}
          <TabsContent value="upcoming" className="space-y-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Skeleton className="h-48 w-full" />
                <Skeleton className="h-48 w-full" />
              </div>
            ) : upcomingEvents?.length === 0 ? (
              <div className="text-center py-10">
                <h3 className="text-lg font-heading font-medium mb-2">
                  Nessun evento imminente
                </h3>
                <p className="text-neutral-medium">
                  Non ci sono eventi programmati per il periodo selezionato.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {upcomingEvents?.map(event => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            )}
          </TabsContent>
          
          {/* Past Events Tab */}
          <TabsContent value="past" className="space-y-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Skeleton className="h-48 w-full" />
                <Skeleton className="h-48 w-full" />
              </div>
            ) : pastEvents?.length === 0 ? (
              <div className="text-center py-10">
                <h3 className="text-lg font-heading font-medium mb-2">
                  Nessun evento passato
                </h3>
                <p className="text-neutral-medium">
                  Non ci sono eventi passati per il periodo selezionato.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pastEvents?.map(event => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      ) : (
        <div className="bg-white p-4 rounded-lg border border-neutral-light">
          <h3 className="text-lg font-heading font-medium mb-4 text-center">
            Vista Calendario
          </h3>
          <div className="space-y-6">
            {/* Simplified calendar view - in a real app this would be a more sophisticated calendar component */}
            <div className="grid grid-cols-7 gap-1">
              {['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'].map(day => (
                <div key={day} className="text-center py-2 font-medium text-sm">
                  {day}
                </div>
              ))}
              {Array.from({ length: 35 }).map((_, i) => (
                <div 
                  key={i} 
                  className="aspect-square border rounded-md flex flex-col items-center justify-start p-1"
                >
                  <div className="text-xs text-neutral-medium">{i + 1}</div>
                  {/* Just showing some sample events */}
                  {i === 10 && (
                    <div className="w-full mt-1 px-1">
                      <div className="text-xs bg-primary text-white rounded px-1 truncate">Workshop</div>
                    </div>
                  )}
                  {i === 18 && (
                    <div className="w-full mt-1 px-1">
                      <div className="text-xs bg-accent text-white rounded px-1 truncate">Raccolta</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="text-center text-neutral-medium text-sm">
              Per visualizzare un calendario interattivo completo, utilizza la vista "Lista".
            </div>
          </div>
        </div>
      )}
    </PageLayout>
  );
}
