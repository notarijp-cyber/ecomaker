import React from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Menu, 
  Home, 
  Scan, 
  FileText, 
  Users,
  Download, 
  Calendar,
  ShoppingBag,
  BarChart3,
  Lightbulb,
  Play,
  Zap,
  Brain,
  TrendingUp,
  Monitor,
  Atom,
  RotateCcw,
  Trophy,
  Sparkles,
  Activity,
  MapPin
} from "lucide-react";
import { Link, useLocation } from "wouter";

export function FuturisticHeader() {
  const [location] = useLocation();

  return (
    <header className="glass-morph-dark border-b border-cyan-500/30 sticky top-0 z-50 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="rounded-lg cyber-button p-2 pulse-glow">
              <span className="text-lg font-bold text-white">🌱</span>
            </div>
            <span className="text-xl font-bold holographic-text">EcoMaker</span>
            <div className="text-xs bg-gradient-to-r from-cyan-400 to-purple-500 text-white px-2 py-1 rounded-full font-semibold">
              QUANTUM
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className={`text-sm font-medium transition-all duration-300 ${
              location === "/" ? "text-cyan-400 holographic-text" : "text-cyan-100 hover:text-cyan-300 hover:glow-cyan"
            }`}>
              Dashboard
            </Link>
            <Link href="/inventory" className={`text-sm font-medium transition-all duration-300 ${
              location === "/inventory" ? "text-cyan-400 holographic-text" : "text-cyan-100 hover:text-cyan-300"
            }`}>
              Inventario
            </Link>
            <Link href="/my-projects" className={`text-sm font-medium transition-all duration-300 ${
              location === "/my-projects" ? "text-cyan-400 holographic-text" : "text-cyan-100 hover:text-cyan-300"
            }`}>
              I Miei Progetti
            </Link>
            <Link href="/community" className={`text-sm font-medium transition-all duration-300 ${
              location === "/community" ? "text-cyan-400 holographic-text" : "text-cyan-100 hover:text-cyan-300"
            }`}>
              Community
            </Link>
            <Link href="/events" className={`text-sm font-medium transition-all duration-300 ${
              location === "/events" ? "text-cyan-400 holographic-text" : "text-cyan-100 hover:text-cyan-300"
            }`}>
              Eventi
            </Link>
          </nav>

          {/* Right side buttons */}
          <div className="flex items-center space-x-4">
            {/* Advanced Features Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="cyber-button hidden md:flex" size="sm">
                  <Zap className="w-4 h-4 mr-2" />
                  Quantum
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 glass-morph-dark border-cyan-500/30">
                <DropdownMenuItem asChild>
                  <Link href="/advanced-features" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Lightbulb className="w-4 h-4 mr-2 text-yellow-400" />
                    Funzionalità Avanzate
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/smart-recommendations" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Brain className="w-4 h-4 mr-2 text-purple-400" />
                    Raccomandazioni AI
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/advanced-sustainability" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <TrendingUp className="w-4 h-4 mr-2 text-green-400" />
                    Tracker Sostenibilità
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/material-lifecycle" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <RotateCcw className="w-4 h-4 mr-2 text-orange-400" />
                    Lifecycle Animator
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/eco-gamification" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Trophy className="w-4 h-4 mr-2 text-yellow-400" />
                    Eco Gamification
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/personalized-recommendations" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Sparkles className="w-4 h-4 mr-2 text-purple-400" />
                    AI Raccomandazioni
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/carbon-footprint" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Activity className="w-4 h-4 mr-2 text-green-400" />
                    Carbon Footprint
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/community-storytelling" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Users className="w-4 h-4 mr-2 text-pink-400" />
                    Community Stories
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/playful-badges" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Trophy className="w-4 h-4 mr-2 text-yellow-400" />
                    Playful Eco-Badges
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/micro-rewards" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Sparkles className="w-4 h-4 mr-2 text-purple-400" />
                    Micro-Rewards
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/ar-material-scan" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Scan className="w-4 h-4 mr-2 text-blue-400" />
                    AR Material Scan
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/eco-journey" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <MapPin className="w-4 h-4 mr-2 text-green-400" />
                    Eco-Journey
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/performance-monitor" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Monitor className="w-4 h-4 mr-2 text-blue-400" />
                    Monitor Prestazioni
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/innovation-center" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Atom className="w-4 h-4 mr-2 text-pink-400" />
                    Centro Innovazione
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/environmental-analytics" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <BarChart3 className="w-4 h-4 mr-2 text-emerald-400" />
                    Analytics Ambientali
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/gamification" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Zap className="w-4 h-4 mr-2 text-orange-400" />
                    Gamification
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/kickstarter-downloads" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Download className="w-4 h-4 mr-2 text-green-400" />
                    📥 Download Kickstarter
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Demo Button */}
            <Link href="/kickstarter-demo">
              <Button className="cyber-button bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                <Play className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Demo €2</span>
              </Button>
            </Link>

            {/* Scan Button */}
            <Link href="/create-project">
              <Button className="cyber-button">
                <Scan className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Scansiona</span>
              </Button>
            </Link>

            {/* Mobile menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden text-cyan-100 hover:text-cyan-300">
                  <Menu className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 glass-morph-dark border-cyan-500/30">
                <DropdownMenuItem asChild>
                  <Link href="/" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Home className="w-4 h-4 mr-2" />
                    Dashboard
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/inventory" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    Inventario
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/my-projects" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <FileText className="w-4 h-4 mr-2" />
                    I Miei Progetti
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/community" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Users className="w-4 h-4 mr-2" />
                    Community
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/events" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Calendar className="w-4 h-4 mr-2" />
                    Eventi
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-cyan-500/30" />
                <DropdownMenuItem asChild>
                  <Link href="/create-project" className="flex items-center text-cyan-100 hover:text-cyan-300">
                    <Scan className="w-4 h-4 mr-2" />
                    Crea Progetto
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}