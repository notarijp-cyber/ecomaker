import React, { ReactNode } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { TabNavigation } from "@/components/layout/tab-navigation";
import { FloatingActionButton } from "@/components/layout/floating-action-button";
import { useLocation } from "wouter";

interface PageLayoutProps {
  children: ReactNode;
  showTabs?: boolean;
  showFab?: boolean;
  containerClassName?: string;
}

export function PageLayout({ 
  children, 
  showTabs = true, 
  showFab = true,
  containerClassName = ""
}: PageLayoutProps) {
  const [location] = useLocation();

  // Automatically hide tabs on pages that have their own navigation
  const hideTabsOnPages = ['/', '/ai-assistant'];
  const shouldShowTabs = showTabs && !hideTabsOnPages.includes(location);
  
  return (
    <div className="flex flex-col min-h-screen bg-neutral-50">
      {/* Header is included in App.tsx, so we don't need it here */}
      
      {shouldShowTabs && <TabNavigation />}
      
      <main className="flex-grow overflow-y-auto">
        <div className={`container mx-auto px-4 py-6 ${containerClassName}`}>
          {children}
        </div>
      </main>
      
      <Footer />
      
      {showFab && <FloatingActionButton />}
    </div>
  );
}
