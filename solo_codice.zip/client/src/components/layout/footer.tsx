import React from "react";
import { Home, MessageCircle, Plus, BookOpen, Recycle, Heart, Instagram, Facebook, Twitter, Leaf, Globe } from "lucide-react";
import { Link, useLocation } from "wouter";

export function Footer() {
  const [location] = useLocation();

  const mainLinks = [
    { name: "Home", href: "/", icon: <Home className="h-5 w-5" /> },
    { name: "Community", href: "/community", icon: <MessageCircle className="h-5 w-5" /> },
    { name: "Crea Progetto", href: "/create-project", icon: <Plus className="h-5 w-5" /> },
    { name: "I Miei Progetti", href: "/my-projects", icon: <BookOpen className="h-5 w-5" /> },
  ];

  const resourceLinks = [
    { name: "Guide al Riciclo", href: "/recycle-guides" },
    { name: "Blog Sostenibilità", href: "/sustainability-blog" },
    { name: "FAQ", href: "/faq" },
    { name: "Contattaci", href: "/contact" },
  ];

  const socialLinks = [
    { name: "Instagram", href: "#", icon: <Instagram className="h-5 w-5" /> },
    { name: "Facebook", href: "#", icon: <Facebook className="h-5 w-5" /> },
    { name: "Twitter", href: "#", icon: <Twitter className="h-5 w-5" /> },
  ];

  return (
    <footer className="relative bg-white border-t border-neutral-light pt-8 pb-6">
      {/* Pattern di sfondo ecologico */}
      <div className="absolute inset-0 eco-pattern-bg opacity-20 z-0"></div>
      
      {/* Onda decorativa sopra il footer */}
      <div className="absolute -top-10 left-0 right-0 overflow-hidden h-10">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="w-full">
          <path fill="#ffffff" fillOpacity="1" d="M0,224L48,192C96,160,192,96,288,90.7C384,85,480,139,576,144C672,149,768,107,864,85.3C960,64,1056,64,1152,85.3C1248,107,1344,149,1392,170.7L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Grid layout su desktop e colonna su mobile */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Colonna logo e descrizione */}
          <div className="md:col-span-4 flex flex-col items-center md:items-start">
            <div className="flex items-center space-x-3 mb-3">
              <div className="relative bg-primary/10 p-2 rounded-full">
                <Recycle className="h-8 w-8 text-primary" />
                <span className="absolute -top-1 -right-1 bg-white rounded-full p-0.5">
                  <Leaf className="h-4 w-4 text-accent" />
                </span>
              </div>
              <h2 className="text-xl font-bold text-primary">EcoMaker</h2>
            </div>
            <p className="text-sm text-neutral-medium mb-4 text-center md:text-left">
              Trasforma i tuoi rifiuti in creazioni utili e belle, riducendo l'impatto ambientale e dando nuova vita ai materiali.
            </p>
            <div className="flex space-x-3 mb-6">
              {socialLinks.map((link, i) => (
                <a 
                  key={i}
                  href={link.href}
                  className="bg-primary/10 hover:bg-primary/20 p-2 rounded-full text-primary transition-colors"
                  aria-label={link.name}
                >
                  {link.icon}
                </a>
              ))}
            </div>
          </div>
          
          {/* Colonna link principali */}
          <div className="md:col-span-3">
            <h3 className="font-semibold text-neutral-dark mb-4 text-center md:text-left">
              Navigazione
            </h3>
            <ul className="flex flex-col space-y-2">
              {mainLinks.map((link, i) => (
                <li key={i}>
                  <button 
                    onClick={() => window.location.href = link.href}
                    className={`flex items-center space-x-2 text-sm py-1 w-full text-left ${location === link.href ? "text-primary font-medium" : "text-neutral-medium hover:text-primary"}`}
                  >
                    {link.icon}
                    <span>{link.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Colonna risorse */}
          <div className="md:col-span-3">
            <h3 className="font-semibold text-neutral-dark mb-4 text-center md:text-left">
              Risorse
            </h3>
            <ul className="flex flex-col space-y-2">
              {resourceLinks.map((link, i) => (
                <li key={i}>
                  <a href={link.href} className="text-sm text-neutral-medium hover:text-primary block py-1">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Colonna newsletter */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-neutral-dark mb-4 text-center md:text-left">
              Contribuisci
            </h3>
            <div className="flex flex-col space-y-3">
              <a href="/donate" className="flex items-center space-x-1 text-sm text-green-600 hover:text-green-700">
                <Heart className="h-4 w-4" />
                <span>Dona alla causa</span>
              </a>
              <a href="/events" className="flex items-center space-x-1 text-sm text-blue-600 hover:text-blue-700">
                <Globe className="h-4 w-4" />
                <span>Partecipa agli eventi</span>
              </a>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="mt-8 pt-6 border-t border-neutral-100 flex flex-col md:flex-row justify-between items-center">
          <div className="text-cyan-300/80 text-xs mb-2 md:mb-0 font-medium">
            © Jacopo Primo Notari 2025
          </div>
          <div className="flex space-x-4 text-xs text-neutral-medium">
            <a href="/privacy-policy" className="hover:text-primary">Privacy Policy</a>
            <a href="/terms-of-service" className="hover:text-primary">Termini di Servizio</a>
            <a href="/cookie-policy" className="hover:text-primary">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
