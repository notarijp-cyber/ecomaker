import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  
  const isActive = (path: string) => location === path;
  
  const navItems = [
    { path: "/", label: "Dashboard", icon: "dashboard" },
    { path: "/materials", label: "I Miei Materiali", icon: "inventory_2" },
    { path: "/projects", label: "Progetti", icon: "build_circle" },
    { path: "/ai-assistant", label: "Assistente AI", icon: "smart_toy" },
    { path: "/material-science", label: "Scienza dei Materiali", icon: "science" },
    { path: "/ar-material-visualization", label: "Visualizza in AR", icon: "view_in_ar" },
    { path: "/thingiverse-models", label: "Modelli 3D", icon: "3d_rotation" },
    { path: "/community", label: "Community", icon: "groups" },
    { path: "/events", label: "Eventi", icon: "event" },
    { path: "/shop", label: "Acquista Strumenti", icon: "shopping_cart" },
  ];
  
  return (
    <aside className="hidden md:block w-64 bg-white h-screen shadow-md sticky top-0 overflow-y-auto">
      <div className="px-6 py-8">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white">
            <span className="material-icons">eco</span>
          </div>
          <h1 className="font-heading font-bold text-xl text-primary">EcoMaker</h1>
        </div>

        <div className="space-y-1">
          {navItems.map(item => (
            <Link 
              key={item.path} 
              href={item.path}
              className={cn(
                "flex items-center space-x-3 p-3 rounded-lg",
                isActive(item.path) 
                  ? "bg-primary text-white" 
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span className="material-icons">{item.icon}</span>
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-neutral-200">
          <div className="p-4 bg-green-100 bg-opacity-70 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <span className="material-icons text-green-700">eco</span>
              <h3 className="font-heading font-semibold text-green-700">Impatto Ambientale</h3>
            </div>
            <p className="text-sm mb-3">Hai risparmiato:</p>
            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>CO2</span>
                  <span>3.5 kg</span>
                </div>
                <div className="h-1 bg-neutral-200 rounded-sm overflow-hidden">
                  <div className="bg-primary h-full rounded-sm" style={{ width: '60%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Plastica</span>
                  <span>2.7 kg</span>
                </div>
                <div className="h-1 bg-neutral-200 rounded-sm overflow-hidden">
                  <div className="bg-primary h-full rounded-sm" style={{ width: '45%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span>Acqua</span>
                  <span>18 L</span>
                </div>
                <div className="h-1 bg-neutral-200 rounded-sm overflow-hidden">
                  <div className="bg-primary h-full rounded-sm" style={{ width: '75%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
