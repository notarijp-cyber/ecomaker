// Dichiarazioni per moduli che non hanno file di dichiarazione
declare module 'three';
declare module 'aframe';
declare module 'mind-ar';