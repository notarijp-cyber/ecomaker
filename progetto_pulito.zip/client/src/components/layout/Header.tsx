import { Link } from "wouter";

export default function Header() {
  return (
    <header className="md:hidden bg-white shadow sticky top-0 z-50">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
            <span className="material-icons">eco</span>
          </div>
          <h1 className="font-heading font-bold text-primary">EcoMaker</h1>
        </div>
        <div className="flex items-center space-x-2">
          <button className="p-2">
            <span className="material-icons text-neutral-600">notifications</span>
          </button>
          <button className="p-2">
            <span className="material-icons text-neutral-600">account_circle</span>
          </button>
        </div>
      </div>
    </header>
  );
}
