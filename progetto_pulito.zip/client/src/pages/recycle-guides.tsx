import React from "react";
import { PageLayout } from "@/components/layout/page-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Recycle, Trash2, Wind, Droplet, Leaf } from "lucide-react";

export default function RecycleGuidesPage() {
  const categoryGuides = [
    {
      id: "plastica",
      name: "Plastica",
      color: "bg-blue-100 text-blue-600",
      icon: <Recycle className="h-6 w-6" />,
      guides: [
        {
          title: "Come riciclare correttamente la plastica",
          description: "Una guida dettagliata su quali tipi di plastica possono essere riciclati e come farlo correttamente.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Tipi di plastica riciclabile</h3>
              <p className="mb-4">
                Non tutte le plastiche sono uguali! Ogni tipo ha un codice di riciclaggio (un numero da 1 a 7 all'interno del simbolo del riciclo):
              </p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li><strong>1 - PET o PETE (Polietilene Tereftalato)</strong>: Bottiglie per bevande, contenitori per alimenti</li>
                <li><strong>2 - HDPE (Polietilene ad alta densità)</strong>: Bottiglie di detergenti, flaconi di shampoo</li>
                <li><strong>3 - PVC (Polivinilcloruro)</strong>: Tubature, giocattoli, carte di credito</li>
                <li><strong>4 - LDPE (Polietilene a bassa densità)</strong>: Sacchetti della spesa, pellicole</li>
                <li><strong>5 - PP (Polipropilene)</strong>: Contenitori per alimenti, tappi di bottiglia</li>
                <li><strong>6 - PS (Polistirene)</strong>: Bicchieri usa e getta, contenitori per yogurt</li>
                <li><strong>7 - Altri</strong>: Miscele di plastica o plastiche non comuni</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Regole generali</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Sciacqua i contenitori per rimuovere residui di cibo o prodotti</li>
                <li>Rimuovi tappi e coperchi (possono essere riciclati separatamente)</li>
                <li>Schiaccia le bottiglie per risparmiare spazio</li>
                <li>Verifica le linee guida locali, poiché le regole di riciclaggio variano</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Errori comuni</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Riciclare plastica sporca (deve essere pulita)</li>
                <li>Mettere nel riciclo sacchetti di plastica sottile (spesso necessitano di un flusso separato)</li>
                <li>Includere oggetti non riciclabili come posate di plastica o cannucce</li>
              </ul>
            </>
          )
        },
        {
          title: "Progetti creativi con bottiglie di plastica",
          description: "Scopri come trasformare le bottiglie di plastica in oggetti utili e decorativi per la casa e il giardino.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Progetti semplici</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Vasi per piante: taglia la parte superiore della bottiglia e decorala</li>
                <li>Organizzatori per scrivania: usa la parte inferiore come portapenne</li>
                <li>Alimentatori per uccelli: crea fori e appendi la bottiglia in giardino</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Progetti avanzati</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Lampade decorative: usa più bottiglie tagliate in forme diverse</li>
                <li>Mini serra: taglia la bottiglia a metà e usa la parte superiore come coperchio</li>
                <li>Tenda decorativa: collega più fondi di bottiglia colorati</li>
              </ul>
              
              <p className="text-sm italic mt-4">
                Tutti questi progetti contribuiscono a ridurre i rifiuti di plastica dando nuova vita a materiali che altrimenti finirebbero nelle discariche.
              </p>
            </>
          )
        }
      ]
    },
    {
      id: "carta",
      name: "Carta",
      color: "bg-green-100 text-green-600",
      icon: <Leaf className="h-6 w-6" />,
      guides: [
        {
          title: "Riciclaggio della carta e cartone",
          description: "Come riciclare correttamente diversi tipi di carta e cartone per massimizzare l'impatto ambientale positivo.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Tipi di carta riciclabile</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Giornali e riviste (senza inserti plastificati)</li>
                <li>Carta da ufficio e buste</li>
                <li>Scatole di cartone (piegate per risparmiare spazio)</li>
                <li>Imballaggi in carta</li>
                <li>Cartoni per bevande (in alcune aree)</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Cosa non includere</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Carta oleata o sporca di cibo</li>
                <li>Carta da forno</li>
                <li>Scontrini (contengono BPA)</li>
                <li>Carta plastificata o metallizzata</li>
              </ul>
              
              <p className="mb-4">
                Ogni tonnellata di carta riciclata salva circa 17 alberi e risparmia energia sufficiente per alimentare una casa media per 6 mesi!
              </p>
            </>
          )
        }
      ]
    },
    {
      id: "vetro",
      name: "Vetro",
      color: "bg-purple-100 text-purple-600",
      icon: <Droplet className="h-6 w-6" />,
      guides: [
        {
          title: "Guida al riciclo del vetro",
          description: "Tutto quello che devi sapere sul riciclo del vetro e il suo impatto ambientale.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Vantaggi del riciclo del vetro</h3>
              <p className="mb-4">
                Il vetro è un materiale ideale per il riciclaggio perché può essere riciclato infinite volte senza perdere qualità o purezza.
              </p>
              
              <h3 className="text-lg font-semibold mb-2">Come preparare il vetro per il riciclo</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Rimuovi tappi e coperchi (metallo o plastica)</li>
                <li>Sciacqua i contenitori per rimuovere residui</li>
                <li>Non è necessario rimuovere le etichette</li>
                <li>Separa il vetro per colore se richiesto nella tua zona</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Cosa non riciclare</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Vetro ceramico (come pyrex)</li>
                <li>Lampadine (contengono metalli)</li>
                <li>Specchi e vetri di finestre (trattati con sostanze chimiche)</li>
                <li>Bicchieri e cristalleria (diversa composizione)</li>
              </ul>
            </>
          )
        }
      ]
    },
    {
      id: "metallo",
      name: "Metallo",
      color: "bg-gray-100 text-gray-600",
      icon: <Trash2 className="h-6 w-6" />,
      guides: [
        {
          title: "Riciclaggio dei metalli",
          description: "Una guida completa su come riciclare correttamente i diversi tipi di metalli.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Tipi di metalli riciclabili</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li><strong>Alluminio</strong>: lattine di bevande, fogli di alluminio, teglie</li>
                <li><strong>Acciaio</strong>: lattine di conserve, barattoli, coperchi</li>
                <li><strong>Rame</strong>: tubi, cavi elettrici</li>
                <li><strong>Ottone e bronzo</strong>: rubinetti, ornamenti</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Benefici del riciclo dei metalli</h3>
              <p className="mb-4">
                Il riciclo dell'alluminio utilizza solo il 5% dell'energia necessaria per produrre alluminio nuovo. 
                Riciclare una lattina di alluminio può risparmiare energia sufficiente per far funzionare un televisore per tre ore.
              </p>
              
              <h3 className="text-lg font-semibold mb-2">Preparazione per il riciclo</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Sciacqua i contenitori per rimuovere i residui</li>
                <li>Schiaccia le lattine per risparmiare spazio</li>
                <li>Rimuovi parti non metalliche quando possibile</li>
              </ul>
            </>
          )
        }
      ]
    },
    {
      id: "elettronica",
      name: "Elettronica",
      color: "bg-yellow-100 text-yellow-600",
      icon: <Wind className="h-6 w-6" />,
      guides: [
        {
          title: "Come smaltire i rifiuti elettronici",
          description: "Guida allo smaltimento sicuro ed ecologico di dispositivi elettronici.",
          content: (
            <>
              <h3 className="text-lg font-semibold mb-2">Perché è importante il riciclo dell'elettronica</h3>
              <p className="mb-4">
                I dispositivi elettronici contengono metalli preziosi, plastiche e componenti tossici che non dovrebbero finire nelle discariche.
                Un solo smartphone contiene oro, argento, rame e altri materiali di valore che possono essere recuperati.
              </p>
              
              <h3 className="text-lg font-semibold mb-2">Dove riciclare</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Centri di riciclo specializzati</li>
                <li>Programmi di restituzione dei produttori</li>
                <li>Negozi di elettronica (molti offrono programmi di ritiro)</li>
                <li>Eventi di raccolta nella comunità</li>
              </ul>
              
              <h3 className="text-lg font-semibold mb-2">Prima dello smaltimento</h3>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Esegui backup dei dati</li>
                <li>Ripristina le impostazioni di fabbrica</li>
                <li>Rimuovi batterie quando possibile (spesso richiedono riciclaggio separato)</li>
                <li>Rimuovi supporti di archiviazione (hard disk, schede SD)</li>
              </ul>
              
              <p className="text-sm italic mt-4">
                Per i dispositivi ancora funzionanti, considera la donazione a scuole, organizzazioni non profit o programmi di riutilizzo.
              </p>
            </>
          )
        }
      ]
    }
  ];

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-primary mb-4">Guide al Riciclo</h1>
            <p className="text-neutral-medium max-w-2xl mx-auto">
              Scopri come riciclare correttamente diversi materiali, massimizzare il loro riutilizzo 
              e trasformarli in progetti creativi per ridurre l'impatto ambientale.
            </p>
          </div>

          {/* Tabs per categorie */}
          <Tabs defaultValue={categoryGuides[0].id} className="mb-10">
            <TabsList className="w-full grid grid-cols-2 md:grid-cols-5 mb-8">
              {categoryGuides.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="flex flex-col items-center space-y-2 p-4"
                >
                  <div className={`p-2 rounded-full ${category.color}`}>
                    {category.icon}
                  </div>
                  <span>{category.name}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {categoryGuides.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="space-y-6">
                  {category.guides.map((guide, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle>{guide.title}</CardTitle>
                        <CardDescription>{guide.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        {guide.content}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>

          <div className="text-center mt-12 bg-green-50 p-6 rounded-xl">
            <Leaf className="h-8 w-8 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-green-700 mb-2">Aiutaci a migliorare queste guide</h2>
            <p className="text-neutral-dark mb-4">
              Hai suggerimenti per migliorare queste guide o vuoi condividere tecniche di riciclo innovative?
              La comunità EcoMaker è sempre alla ricerca di nuovi modi per ridurre, riutilizzare e riciclare.
            </p>
            <button 
              className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
              onClick={() => {
                alert("Grazie per voler condividere la tua esperienza! Abbiamo ricevuto la tua richiesta e ti contatteremo presto per raccogliere i tuoi consigli.");
              }}
            >
              Condividi la tua esperienza
            </button>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}