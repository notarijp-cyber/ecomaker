import React from "react";
import { PageLayout } from "@/components/layout/page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Lock, Database, Eye, Bell, FileText } from "lucide-react";

export default function PrivacyPolicyPage() {
  const lastUpdated = "12 Gennaio 2023";

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-10">
            <div className="inline-block p-2 bg-primary/10 rounded-full mb-4">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-primary mb-4">Privacy Policy</h1>
            <p className="text-neutral-medium max-w-2xl mx-auto">
              La tua privacy è importante per noi. Questa policy descrive come raccogliamo, utilizziamo e proteggiamo i tuoi dati personali.
            </p>
            <p className="text-sm text-neutral-medium mt-4">
              Ultimo aggiornamento: {lastUpdated}
            </p>
          </div>

          <div className="mb-8">
            <Tabs defaultValue="summary">
              <TabsList className="w-full grid grid-cols-3 mb-8">
                <TabsTrigger value="summary">Riepilogo</TabsTrigger>
                <TabsTrigger value="complete">Policy completa</TabsTrigger>
                <TabsTrigger value="changes">Modifiche</TabsTrigger>
              </TabsList>
              
              <TabsContent value="summary">
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-8">
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-blue-100 rounded-full">
                          <Database className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Dati che raccogliamo</h3>
                          <p className="text-neutral-medium mb-2">
                            Raccogliamo i seguenti tipi di informazioni:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                            <li>Informazioni del profilo (nome, email, preferenze)</li>
                            <li>Dati sui materiali di riciclo che registri nell'app</li>
                            <li>Foto dei progetti e dei materiali (se li carichi)</li>
                            <li>Informazioni sull'utilizzo dell'app e interazioni</li>
                            <li>Dati sulla posizione (solo se consenti l'accesso)</li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-green-100 rounded-full">
                          <Eye className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Come utilizziamo i tuoi dati</h3>
                          <p className="text-neutral-medium mb-2">
                            Utilizziamo i tuoi dati per:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                            <li>Fornirti i servizi di EcoMaker e migliorare l'esperienza utente</li>
                            <li>Personalizzare i suggerimenti di progetti in base ai materiali disponibili</li>
                            <li>Analizzare l'impatto ambientale delle tue attività di riciclo</li>
                            <li>Connettere utenti con interessi simili (solo con consenso)</li>
                            <li>Informarti su eventi, aggiornamenti e funzionalità rilevanti</li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-purple-100 rounded-full">
                          <Lock className="h-5 w-5 text-purple-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Come proteggiamo i tuoi dati</h3>
                          <p className="text-neutral-medium mb-4">
                            Adottiamo robuste misure di sicurezza per proteggere i tuoi dati, inclusi:
                            crittografia, autenticazione a più fattori, accesso limitato dei dipendenti,
                            e revisioni regolari delle nostre pratiche di sicurezza.
                          </p>
                          <p className="text-neutral-medium">
                            Non vendiamo mai i tuoi dati personali a terze parti. Condividiamo dati solo
                            con fornitori di servizi necessari al funzionamento dell'app, e sempre con
                            rigorosi accordi di protezione dei dati.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-orange-100 rounded-full">
                          <Bell className="h-5 w-5 text-orange-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold mb-2">I tuoi diritti</h3>
                          <p className="text-neutral-medium mb-2">
                            Hai il controllo sui tuoi dati e puoi in qualsiasi momento:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                            <li>Accedere e scaricare tutti i dati che abbiamo su di te</li>
                            <li>Correggere o aggiornare i tuoi dati personali</li>
                            <li>Eliminare il tuo account e tutti i dati associati</li>
                            <li>Limitare il modo in cui utilizziamo i tuoi dati</li>
                            <li>Revocare il consenso per specifici utilizzi dei dati</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="complete">
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h2 className="text-xl font-semibold mb-4">1. Introduzione</h2>
                        <p className="text-neutral-medium mb-3">
                          EcoMaker ("noi", "nostro", o "l'app") si impegna a proteggere la privacy degli utenti. 
                          Questa Privacy Policy spiega come raccogliamo, utilizziamo, divulghiamo e salvaguardiamo 
                          le tue informazioni quando utilizzi la nostra applicazione mobile e il sito web (collettivamente, il "Servizio").
                        </p>
                        <p className="text-neutral-medium">
                          Ti preghiamo di leggere attentamente questa policy. Utilizzando il Servizio, accetti le pratiche 
                          descritte in questo documento. Se non sei d'accordo con questa policy, ti preghiamo di non utilizzare il nostro Servizio.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">2. Informazioni che raccogliamo</h2>
                        <div className="mb-3">
                          <h3 className="font-semibold mb-2">2.1 Informazioni fornite dall'utente</h3>
                          <p className="text-neutral-medium mb-2">
                            Possiamo raccogliere le seguenti informazioni che fornisci volontariamente:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                            <li>Informazioni di registrazione (nome, indirizzo email, password)</li>
                            <li>Informazioni di profilo (foto, biografia, interessi)</li>
                            <li>Contenuti generati dall'utente (progetti, foto, commenti, recensioni)</li>
                            <li>Informazioni sui materiali di riciclo che registri</li>
                            <li>Comunicazioni con noi (richieste di supporto, feedback)</li>
                            <li>Informazioni di pagamento se effettui donazioni o acquisti</li>
                          </ul>
                        </div>
                        
                        <div className="mb-3">
                          <h3 className="font-semibold mb-2">2.2 Informazioni raccolte automaticamente</h3>
                          <p className="text-neutral-medium mb-2">
                            Quando utilizzi il nostro Servizio, possiamo raccogliere automaticamente:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                            <li>Informazioni sul dispositivo (modello, sistema operativo, identificatori univoci)</li>
                            <li>Dati di log (indirizzi IP, orari di accesso, attività nell'app)</li>
                            <li>Dati di utilizzo (funzionalità utilizzate, interazioni, tempo di utilizzo)</li>
                            <li>Dati sulla posizione (se concedi l'autorizzazione)</li>
                            <li>Informazioni raccolte tramite cookie e tecnologie simili</li>
                          </ul>
                        </div>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">3. Come utilizziamo le informazioni</h2>
                        <p className="text-neutral-medium mb-2">
                          Utilizziamo le informazioni raccolte per:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-neutral-medium mb-3">
                          <li>Fornire, mantenere e migliorare il nostro Servizio</li>
                          <li>Personalizzare l'esperienza utente e i suggerimenti di progetti</li>
                          <li>Facilitare la comunicazione tra utenti della community</li>
                          <li>Analizzare l'impatto ambientale delle attività di riciclo</li>
                          <li>Monitorare l'utilizzo del Servizio e risolvere problemi tecnici</li>
                          <li>Inviare notifiche, aggiornamenti e informazioni promozionali</li>
                          <li>Rispondere alle richieste e fornire assistenza clienti</li>
                          <li>Garantire la sicurezza del nostro Servizio</li>
                          <li>Adempiere a obblighi legali e normativi</li>
                        </ul>
                        <p className="text-neutral-medium">
                          Elaboriamo i tuoi dati solo con una base legale valida, che può includere il tuo consenso, 
                          l'esecuzione di un contratto, il rispetto di obblighi legali o i nostri legittimi interessi, 
                          sempre bilanciati con i tuoi diritti e interessi.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">4. Condivisione e divulgazione delle informazioni</h2>
                        <p className="text-neutral-medium mb-2">
                          Possiamo condividere le tue informazioni con:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-neutral-medium mb-3">
                          <li>Altri utenti del Servizio (per contenuti condivisi pubblicamente o community)</li>
                          <li>Fornitori di servizi (per aiutarci a fornire e migliorare il Servizio)</li>
                          <li>Partner commerciali (con il tuo consenso esplicito)</li>
                          <li>Autorità legali (quando richiesto dalla legge o necessario per proteggere i nostri diritti)</li>
                        </ul>
                        <p className="text-neutral-medium mb-3">
                          <strong>Nota importante:</strong> Non vendiamo mai i tuoi dati personali a terze parti.
                        </p>
                        <p className="text-neutral-medium">
                          Qualsiasi terza parte con cui condividiamo i tuoi dati è contrattualmente obbligata 
                          a utilizzare le tue informazioni solo per gli scopi specificati e in conformità con questa Privacy Policy.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">5. Sicurezza dei dati</h2>
                        <p className="text-neutral-medium mb-3">
                          Adottiamo misure di sicurezza tecniche, amministrative e fisiche progettate per 
                          proteggere le tue informazioni da accessi, utilizzi o divulgazioni non autorizzati. Queste misure includono:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-neutral-medium mb-3">
                          <li>Crittografia dei dati in transito e a riposo</li>
                          <li>Controlli di accesso rigorosi per i nostri sistemi</li>
                          <li>Autenticazione a più fattori</li>
                          <li>Revisioni periodiche delle nostre pratiche di sicurezza</li>
                          <li>Formazione continua del personale sulle best practice di sicurezza</li>
                        </ul>
                        <p className="text-neutral-medium">
                          Sebbene ci impegniamo per proteggere le tue informazioni, nessun metodo di trasmissione 
                          o archiviazione elettronica è completamente sicuro. Pertanto, non possiamo garantire la 
                          sicurezza assoluta dei tuoi dati.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">6. I tuoi diritti sulla privacy</h2>
                        <p className="text-neutral-medium mb-3">
                          A seconda della tua giurisdizione, potresti avere i seguenti diritti:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-neutral-medium mb-3">
                          <li>Accesso: diritto di richiedere copia dei tuoi dati personali</li>
                          <li>Rettifica: diritto di correggere dati inaccurati o incompleti</li>
                          <li>Cancellazione: diritto di richiedere la rimozione dei tuoi dati</li>
                          <li>Limitazione: diritto di richiedere la limitazione del trattamento</li>
                          <li>Portabilità: diritto di ricevere i tuoi dati in formato strutturato</li>
                          <li>Opposizione: diritto di opporti al trattamento in determinati casi</li>
                          <li>Revoca del consenso: diritto di revocare il consenso precedentemente fornito</li>
                        </ul>
                        <p className="text-neutral-medium">
                          Per esercitare questi diritti, contattaci attraverso le informazioni fornite nella sezione "Contattaci". 
                          Risponderemo a tutte le richieste entro i termini previsti dalla legge applicabile.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">7. Conservazione dei dati</h2>
                        <p className="text-neutral-medium">
                          Conserviamo i tuoi dati personali solo per il tempo necessario agli scopi indicati in questa Privacy Policy, 
                          a meno che non sia richiesto o consentito un periodo di conservazione più lungo dalla legge. I criteri 
                          utilizzati per determinare i nostri periodi di conservazione includono la natura dei dati, gli obblighi legali, 
                          i requisiti tecnici e le aspettative degli utenti.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">8. Modifiche a questa Privacy Policy</h2>
                        <p className="text-neutral-medium">
                          Possiamo aggiornare questa Privacy Policy periodicamente per riflettere cambiamenti nelle nostre pratiche 
                          o per altri motivi operativi, legali o normativi. Ti informeremo di eventuali modifiche sostanziali 
                          pubblicando la nuova Privacy Policy sul nostro sito web e all'interno dell'app, e potremmo anche 
                          fornirti una notifica attraverso l'app o via email.
                        </p>
                      </div>
                      
                      <div>
                        <h2 className="text-xl font-semibold mb-4">9. Contattaci</h2>
                        <p className="text-neutral-medium mb-3">
                          Se hai domande, preoccupazioni o richieste relative a questa Privacy Policy o alle nostre 
                          pratiche sulla privacy, ti preghiamo di contattarci:
                        </p>
                        <div className="bg-neutral-50 p-4 rounded-lg">
                          <p className="font-medium mb-1">EcoMaker s.r.l.</p>
                          <p className="text-neutral-medium mb-1">Via Sostenibilità 123, Milano, Italia</p>
                          <p className="text-neutral-medium mb-1">Email: privacy@ecomaker.it</p>
                          <p className="text-neutral-medium">Telefono: +39 123 456 7890</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="changes">
                <Card>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      <div>
                        <h2 className="text-xl font-semibold mb-4">Registro delle modifiche</h2>
                        <p className="text-neutral-medium mb-6">
                          Manteniamo un registro delle modifiche sostanziali apportate alla nostra Privacy Policy per garantire trasparenza.
                        </p>
                        
                        <div className="space-y-8">
                          <div className="relative pl-8 pb-8 border-l border-neutral-200">
                            <div className="absolute left-0 top-0 transform -translate-x-1/2 rounded-full w-6 h-6 bg-primary flex items-center justify-center">
                              <FileText className="h-3 w-3 text-white" />
                            </div>
                            <div className="mb-2">
                              <span className="bg-primary/10 text-primary text-xs font-medium px-2.5 py-0.5 rounded">Versione attuale</span>
                              <h3 className="text-lg font-semibold mt-2">12 Gennaio 2023</h3>
                            </div>
                            <p className="text-neutral-medium mb-2">Modifiche principali:</p>
                            <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                              <li>Aggiornate le sezioni sui dati raccolti per includere informazioni sui materiali di riciclo</li>
                              <li>Chiariti i dettagli sull'utilizzo dell'AI per la generazione di progetti</li>
                              <li>Aggiunte informazioni sulla condivisione dei dati nella community</li>
                              <li>Espanse le informazioni sui diritti degli utenti in conformità con il GDPR</li>
                            </ul>
                          </div>
                          
                          <div className="relative pl-8 pb-8 border-l border-neutral-200">
                            <div className="absolute left-0 top-0 transform -translate-x-1/2 rounded-full w-6 h-6 bg-neutral-300 flex items-center justify-center">
                              <FileText className="h-3 w-3 text-white" />
                            </div>
                            <div>
                              <h3 className="text-lg font-semibold">5 Giugno 2022</h3>
                            </div>
                            <p className="text-neutral-medium mb-2">Modifiche principali:</p>
                            <ul className="list-disc list-inside space-y-1 text-neutral-medium">
                              <li>Aggiornate le informazioni sui fornitori di servizi di terze parti</li>
                              <li>Migliorata la sezione sulla sicurezza dei dati</li>
                              <li>Aggiunti dettagli sui periodi di conservazione dei dati</li>
                            </ul>
                          </div>
                          
                          <div className="relative pl-8">
                            <div className="absolute left-0 top-0 transform -translate-x-1/2 rounded-full w-6 h-6 bg-neutral-300 flex items-center justify-center">
                              <FileText className="h-3 w-3 text-white" />
                            </div>
                            <div>
                              <h3 className="text-lg font-semibold">15 Gennaio 2022</h3>
                            </div>
                            <p className="text-neutral-medium mb-2">Prima versione della Privacy Policy</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-neutral-50 p-6 rounded-lg">
                        <h3 className="text-lg font-semibold mb-4">Richiesta di versioni precedenti</h3>
                        <p className="text-neutral-medium mb-4">
                          Se desideri accedere a una versione precedente della nostra Privacy Policy, puoi inviarci una richiesta 
                          e saremo felici di fornirti la versione richiesta.
                        </p>
                        <Button
                          onClick={() => alert("La tua richiesta è stata registrata. Ti contatteremo via email con le versioni precedenti della Privacy Policy.")}
                        >
                          Richiedi versione precedente <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="text-center mb-10">
            <p className="text-neutral-medium mb-4">
              Hai domande sulla nostra Privacy Policy o su come trattiamo i tuoi dati?
            </p>
            <Button
              onClick={() => window.location.href = "/contact"}
            >
              Contatta il nostro responsabile della privacy
            </Button>
          </div>

          <div className="flex justify-center space-x-8 text-neutral-medium text-sm">
            <a href="/terms-of-service" className="hover:text-primary">Termini di Servizio</a>
            <a href="/cookie-policy" className="hover:text-primary">Cookie Policy</a>
            <a href="#" onClick={(e) => {
              e.preventDefault();
              alert("Il Centro Sicurezza è in fase di sviluppo. Sarà disponibile a breve.");
            }} className="hover:text-primary">Centro Sicurezza</a>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}