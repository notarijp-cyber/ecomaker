import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { PageLayout } from "@/components/layout/page-layout";
import { Material, MaterialType } from "@/lib/types";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  Info,
  MapPin,
  Tag,
  Check,
  Building,
  ShoppingCart,
  Users,
  ChevronsUpDown,
  Leaf,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getMaterialTypeColor } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";

export default function MaterialDetail() {
  const { id } = useParams();
  const materialId = parseInt(id);
  const queryClient = useQueryClient();
  
  const { data: material, isLoading: materialLoading } = useQuery<Material>({
    queryKey: [`/api/materials/${materialId}`],
  });
  
  const { data: materialTypes, isLoading: typesLoading } = useQuery<MaterialType[]>({
    queryKey: ['/api/material-types'],
  });
  
  const [requestQuantity, setRequestQuantity] = useState<number>(1);
  const [isRequested, setIsRequested] = useState(false);
  
  // Mock mutation for requesting material
  const requestMutation = useMutation({
    mutationFn: async (data: { materialId: number; quantity: number }) => {
      // In a real app, this would make an API call
      return await new Promise(resolve => setTimeout(() => resolve(true), 1000));
    },
    onSuccess: () => {
      setIsRequested(true);
      // In a real app, we'd invalidate relevant queries
      // queryClient.invalidateQueries({ queryKey: ['/api/materials'] });
    }
  });
  
  const handleRequestMaterial = () => {
    if (materialId && requestQuantity > 0) {
      requestMutation.mutate({ materialId, quantity: requestQuantity });
    }
  };
  
  const getMaterialType = (typeId: number) => {
    return materialTypes?.find(type => type.id === typeId);
  };
  
  if (materialLoading || typesLoading) {
    return (
      <PageLayout>
        <div className="flex items-center mb-6">
          <Link href="/inventory">
            <Button variant="ghost" className="p-0 mr-2">
              <ArrowLeft className="h-5 w-5 mr-1" />
            </Button>
          </Link>
          <Skeleton className="h-8 w-1/2" />
        </div>
        
        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Skeleton className="h-96 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-36 w-full" />
          </div>
        </div>
      </PageLayout>
    );
  }
  
  if (!material) {
    return (
      <PageLayout>
        <div className="text-center py-16">
          <h2 className="text-2xl font-heading font-bold mb-2">Materiale non trovato</h2>
          <p className="text-neutral-medium mb-6">
            Il materiale che stai cercando non esiste o è stato rimosso.
          </p>
          <Link href="/inventory">
            <Button className="bg-primary text-white">
              Torna all'inventario
            </Button>
          </Link>
        </div>
      </PageLayout>
    );
  }
  
  const materialType = getMaterialType(material.typeId);
  
  return (
    <PageLayout showFab={false}>
      <div className="mb-6">
        <div className="flex items-center mb-2">
          <Link href="/inventory">
            <Button variant="ghost" className="p-0 mr-2">
              <ArrowLeft className="h-5 w-5 mr-1" />
            </Button>
          </Link>
          <h2 className="text-2xl font-heading font-bold">{material.name}</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {materialType && (
            <Badge className={getMaterialTypeColor(materialType.name)}>
              {materialType.name}
            </Badge>
          )}
          {material.companyId && (
            <Badge variant="outline" className="bg-neutral-lightest">
              <Building className="h-3 w-3 mr-1" />
              Materiale aziendale
            </Badge>
          )}
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          {/* Material Image and Description */}
          <Card>
            <div className="w-full h-64 bg-neutral-light">
              {material.imageUrl ? (
                <img
                  src={material.imageUrl}
                  alt={material.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-neutral-lightest">
                  <Tag className="h-16 w-16 text-neutral-medium" />
                </div>
              )}
            </div>
            <CardContent className="p-6">
              <p className="text-neutral-dark">
                {material.description || 
                `Questo materiale è classificato come ${materialType?.name || 'materiale riciclabile'}. 
                Può essere utilizzato in diversi progetti di upcycling e riciclaggio creativo.`}
              </p>
              
              <div className="mt-4 flex items-center text-neutral-medium">
                <MapPin className="h-4 w-4 mr-2" />
                <span>{material.location || "Località non specificata"}</span>
              </div>
            </CardContent>
          </Card>
          
          {/* Material Usage Tabs */}
          <Tabs defaultValue="possible-uses" className="space-y-4">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="possible-uses" className="flex items-center text-xs sm:text-sm">
                <Info className="h-4 w-4 mr-1 hidden sm:inline" />
                Possibili Utilizzi
              </TabsTrigger>
              <TabsTrigger value="projects" className="flex items-center text-xs sm:text-sm">
                <Tag className="h-4 w-4 mr-1 hidden sm:inline" />
                Progetti Suggeriti
              </TabsTrigger>
              <TabsTrigger value="impact" className="flex items-center text-xs sm:text-sm">
                <Leaf className="h-4 w-4 mr-1 hidden sm:inline" />
                Impatto Ambientale
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="possible-uses" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Utilizzi Creativi</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {materialType?.name === "Plastica" ? (
                      <>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Vasi per piante</div>
                            <p className="text-sm text-neutral-medium">
                              Tagliare le bottiglie di plastica e trasformarle in contenitori per piante.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Portapenne</div>
                            <p className="text-sm text-neutral-medium">
                              Decorare e riutilizzare contenitori di plastica come portapenne.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Lampade decorative</div>
                            <p className="text-sm text-neutral-medium">
                              Utilizzare bottiglie con luci LED per creare lampade d'atmosfera.
                            </p>
                          </div>
                        </li>
                      </>
                    ) : materialType?.name === "Legno" ? (
                      <>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Mobili</div>
                            <p className="text-sm text-neutral-medium">
                              Realizzare librerie, panchine e tavolini con pallet e legno recuperato.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Decorazioni da parete</div>
                            <p className="text-sm text-neutral-medium">
                              Creare quadri e decorazioni intagliando o assemblando pezzi di legno.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Orto verticale</div>
                            <p className="text-sm text-neutral-medium">
                              Costruire strutture per orti verticali da balcone o giardino.
                            </p>
                          </div>
                        </li>
                      </>
                    ) : materialType?.name === "Tessile" ? (
                      <>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Borse e accessori</div>
                            <p className="text-sm text-neutral-medium">
                              Realizzare borse, pochette e altri accessori con tessuti riciclati.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Trapunte patchwork</div>
                            <p className="text-sm text-neutral-medium">
                              Creare coperte unendo ritagli di stoffa in pattern colorati.
                            </p>
                          </div>
                        </li>
                        <li className="flex items-start">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2 mr-2"></div>
                          <div>
                            <div className="font-medium">Decorazioni casa</div>
                            <p className="text-sm text-neutral-medium">
                              Realizzare cuscini, runner e altri elementi d'arredo.
                            </p>
                          </div>
                        </li>
                      </>
                    ) : (
                      <li className="text-neutral-medium">
                        Nessun suggerimento disponibile per questo tipo di materiale.
                      </li>
                    )}
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Consigli per il Riciclo</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {materialType?.name === "Plastica" ? (
                      <>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Lava sempre bene i contenitori prima di riutilizzarli</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Taglia con cura utilizzando forbici specifiche per la plastica</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Evita di riscaldare la plastica a temperature elevate</span>
                        </li>
                      </>
                    ) : materialType?.name === "Legno" ? (
                      <>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Carteggia bene per rimuovere schegge e irregolarità</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Utilizza vernici ecologiche per la finitura</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Controlla che i pallet non siano stati trattati con sostanze tossiche</span>
                        </li>
                      </>
                    ) : materialType?.name === "Tessile" ? (
                      <>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Lava i tessuti prima di riutilizzarli</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Considera la resistenza e l'elasticità per scegliere l'uso più adatto</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>Conserva anche piccoli ritagli per progetti di patchwork</span>
                        </li>
                      </>
                    ) : (
                      <li className="text-neutral-medium">
                        Nessun consiglio disponibile per questo tipo di materiale.
                      </li>
                    )}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="projects" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Progetti Consigliati</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {materialType?.name === "Plastica" ? (
                      <>
                        <div className="flex justify-between items-center border-b pb-3">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-neutral-lightest rounded-md flex items-center justify-center mr-3">
                              <Tag className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">Lampada da bottiglia</div>
                              <div className="text-sm text-neutral-medium">Livello: Facile</div>
                            </div>
                          </div>
                          <Link href="/create-project">
                            <Button variant="ghost" className="text-primary">
                              Vedi
                            </Button>
                          </Link>
                        </div>
                        
                        <div className="flex justify-between items-center border-b pb-3">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-neutral-lightest rounded-md flex items-center justify-center mr-3">
                              <Tag className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">Vasi sospesi</div>
                              <div className="text-sm text-neutral-medium">Livello: Medio</div>
                            </div>
                          </div>
                          <Link href="/create-project">
                            <Button variant="ghost" className="text-primary">
                              Vedi
                            </Button>
                          </Link>
                        </div>
                      </>
                    ) : materialType?.name === "Legno" ? (
                      <>
                        <div className="flex justify-between items-center border-b pb-3">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-neutral-lightest rounded-md flex items-center justify-center mr-3">
                              <Tag className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">Libreria da cassette</div>
                              <div className="text-sm text-neutral-medium">Livello: Avanzato</div>
                            </div>
                          </div>
                          <Link href="/create-project">
                            <Button variant="ghost" className="text-primary">
                              Vedi
                            </Button>
                          </Link>
                        </div>
                        
                        <div className="flex justify-between items-center border-b pb-3">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-neutral-lightest rounded-md flex items-center justify-center mr-3">
                              <Tag className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">Panchina da pallet</div>
                              <div className="text-sm text-neutral-medium">Livello: Medio</div>
                            </div>
                          </div>
                          <Link href="/create-project">
                            <Button variant="ghost" className="text-primary">
                              Vedi
                            </Button>
                          </Link>
                        </div>
                      </>
                    ) : (
                      <div className="text-neutral-medium py-8 text-center">
                        Nessun progetto suggerito disponibile per questo materiale.
                      </div>
                    )}
                    
                    <div className="text-center mt-4">
                      <Link href="/create-project">
                        <Button className="bg-primary text-white">
                          Crea un nuovo progetto
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="impact" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-medium">Impatto Ambientale</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-neutral-lightest rounded p-4 text-center">
                      <div className="text-2xl font-bold text-primary">
                        {material.quantity} {material.unit}
                      </div>
                      <div className="text-sm text-neutral-medium mt-1">Materiale Risparmiato</div>
                    </div>
                    
                    <div className="bg-neutral-lightest rounded p-4 text-center">
                      <div className="text-2xl font-bold text-accent">
                        {materialType?.name === "Plastica" ? "0.5 kg" : 
                         materialType?.name === "Legno" ? "3.2 kg" : 
                         materialType?.name === "Vetro" ? "0.3 kg" : "0.2 kg"}
                      </div>
                      <div className="text-sm text-neutral-medium mt-1">CO₂ Risparmiata</div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm">Benefici del riciclo di questo materiale:</h4>
                    <ul className="space-y-2">
                      {materialType?.name === "Plastica" ? (
                        <>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Riduzione dell'inquinamento degli oceani</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Risparmio di petrolio necessario per nuova plastica</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Diminuzione dei rifiuti in discarica</span>
                          </li>
                        </>
                      ) : materialType?.name === "Legno" ? (
                        <>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Salvaguardia delle foreste</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Riduzione dell'impatto della produzione di nuovo legname</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Conservazione della biodiversità</span>
                          </li>
                        </>
                      ) : materialType?.name === "Vetro" ? (
                        <>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Risparmio energetico nella produzione di nuovo vetro</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Riduzione dell'estrazione di materie prime</span>
                          </li>
                          <li className="flex items-start">
                            <Leaf className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-sm">Il vetro è riciclabile al 100% infinite volte</span>
                          </li>
                        </>
                      ) : (
                        <li className="text-neutral-medium">
                          Dati non disponibili per questo tipo di materiale.
                        </li>
                      )}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="space-y-6">
          {/* Material Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Dettagli Materiale</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center">
                <Tag className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Tipo</div>
                  <div className="text-sm text-neutral-medium">
                    {materialType?.name || "Non specificato"}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center">
                <ChevronsUpDown className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Quantità disponibile</div>
                  <div className="text-sm text-neutral-medium">
                    {material.quantity} {material.unit}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-neutral-medium mr-3" />
                <div>
                  <div className="text-sm font-medium">Località</div>
                  <div className="text-sm text-neutral-medium">
                    {material.location || "Non specificata"}
                  </div>
                </div>
              </div>
              
              {material.companyId && (
                <div className="flex items-center">
                  <Building className="h-5 w-5 text-neutral-medium mr-3" />
                  <div>
                    <div className="text-sm font-medium">Fornito da</div>
                    <div className="text-sm text-neutral-medium">
                      {/* In a real app, we'd fetch the company name */}
                      {material.companyId === 1 ? "EcoLegno srl" : 
                       material.companyId === 2 ? "ModaTex SpA" : "Azienda"}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Request Material Card */}
          {material.companyId && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Richiedi Materiale</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantità desiderata</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      max={material.quantity}
                      value={requestQuantity}
                      onChange={(e) => setRequestQuantity(parseInt(e.target.value) || 1)}
                    />
                  </div>
                  
                  <p className="text-sm text-neutral-medium">
                    Richiedendo questo materiale, ti impegni a ritirarlo e utilizzarlo in progetti di upcycling.
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                {isRequested ? (
                  <Button className="w-full bg-primary-light text-primary" disabled>
                    <Check className="h-4 w-4 mr-2" />
                    Richiesta inviata
                  </Button>
                ) : (
                  <Button 
                    className="w-full bg-primary text-white"
                    onClick={handleRequestMaterial}
                    disabled={requestMutation.isPending}
                  >
                    {requestMutation.isPending ? (
                      "Invio in corso..."
                    ) : (
                      <>
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Richiedi materiale
                      </>
                    )}
                  </Button>
                )}
              </CardFooter>
            </Card>
          )}
          
          {/* Similar Materials Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Materiali Simili</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 border-b pb-3">
                  <div className="h-12 w-12 bg-neutral-lightest rounded-md flex items-center justify-center">
                    <Tag className="h-6 w-6 text-neutral-medium" />
                  </div>
                  <div className="flex-grow">
                    <div className="font-medium">{materialType?.name === "Plastica" ? "Bottiglie PET" : materialType?.name === "Legno" ? "Cassette frutta" : "Altro materiale"}</div>
                    <div className="text-sm text-neutral-medium">Quantità: 10 pezzi</div>
                  </div>
                  <Link href="/material-detail/1">
                    <Button variant="ghost" className="text-primary text-sm">
                      Vedi
                    </Button>
                  </Link>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="h-12 w-12 bg-neutral-lightest rounded-md flex items-center justify-center">
                    <Tag className="h-6 w-6 text-neutral-medium" />
                  </div>
                  <div className="flex-grow">
                    <div className="font-medium">{materialType?.name === "Plastica" ? "Contenitori plastica" : materialType?.name === "Legno" ? "Pallet" : "Altro materiale"}</div>
                    <div className="text-sm text-neutral-medium">Quantità: 5 pezzi</div>
                  </div>
                  <Link href="/material-detail/2">
                    <Button variant="ghost" className="text-primary text-sm">
                      Vedi
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/inventory">
                <Button variant="outline" className="w-full">
                  Vedi tutti i materiali
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </PageLayout>
  );
}
