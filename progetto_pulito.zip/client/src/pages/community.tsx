import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageLayout } from "@/components/layout/page-layout";
import { Project, ProjectStatus } from "@/lib/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AvatarGroup } from "@/components/ui/avatar-group";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Users, MessageSquare, Plus } from "lucide-react";
import { Link } from "wouter";

export default function Community() {
  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects', { communityOnly: true }],
  });
  
  const [searchTerm, setSearchTerm] = useState("");
  
  // Filter projects based on search
  const filteredProjects = projects?.filter(project => 
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (project.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false)
  );
  
  // Group projects by completion status
  const activeProjects = filteredProjects?.filter(p => p.completionPercentage < 100) || [];
  const completedProjects = filteredProjects?.filter(p => p.completionPercentage === 100) || [];
  
  return (
    <PageLayout>
      <div className="mb-8">
        <h2 className="text-2xl font-heading font-bold mb-2">Community</h2>
        <p className="text-neutral-medium">
          Partecipa a progetti comunitari e collabora con altri membri della community.
        </p>
      </div>
      
      {/* Forum and projects tabs */}
      <Tabs defaultValue="projects" className="space-y-6">
        <TabsList className="w-full grid grid-cols-2">
          <TabsTrigger value="projects" className="flex items-center">
            <Users className="h-4 w-4 mr-2" />
            Progetti Comunitari
          </TabsTrigger>
          <TabsTrigger value="forum" className="flex items-center">
            <MessageSquare className="h-4 w-4 mr-2" />
            Forum
          </TabsTrigger>
        </TabsList>
        
        {/* Projects Tab */}
        <TabsContent value="projects" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            <div className="relative w-full sm:w-auto sm:flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
              <Input
                placeholder="Cerca progetti comunitari..."
                className="pl-10 bg-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Link href="/create-project">
              <Button className="bg-accent text-white w-full sm:w-auto">
                <Plus className="h-4 w-4 mr-2" />
                Nuovo Progetto Comunitario
              </Button>
            </Link>
          </div>
          
          <Tabs defaultValue="active" className="space-y-6">
            <TabsList className="w-full grid grid-cols-2">
              <TabsTrigger value="active">
                Progetti Attivi ({activeProjects.length})
              </TabsTrigger>
              <TabsTrigger value="completed">
                Progetti Completati ({completedProjects.length})
              </TabsTrigger>
            </TabsList>
            
            {/* Active Projects Tab */}
            <TabsContent value="active" className="space-y-6">
              {isLoading ? (
                <>
                  <Skeleton className="w-full h-72" />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Skeleton className="h-64 w-full" />
                    <Skeleton className="h-64 w-full" />
                  </div>
                </>
              ) : activeProjects.length === 0 ? (
                <div className="text-center py-10">
                  <h3 className="text-lg font-heading font-medium mb-2">
                    Nessun progetto comunitario attivo
                  </h3>
                  <p className="text-neutral-medium">
                    Crea un nuovo progetto comunitario o partecipa a uno esistente.
                  </p>
                </div>
              ) : (
                <>
                  {/* Featured project */}
                  <Card className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3">
                        <div className="h-48 md:h-full bg-neutral-light">
                          {activeProjects[0].imageUrl ? (
                            <img
                              src={activeProjects[0].imageUrl}
                              alt={activeProjects[0].name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img
                              src="https://images.unsplash.com/photo-1569144157591-c60f3f82f137?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
                              alt="Installazione artistica comunitaria"
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                      </div>
                      <CardContent className="p-4 md:w-2/3">
                        <div className="flex justify-between items-start">
                          <h3 className="font-heading font-semibold text-lg">
                            {activeProjects[0].name}
                          </h3>
                          <Badge className="bg-accent bg-opacity-10 text-accent">
                            Progetto comunitario
                          </Badge>
                        </div>
                        <p className="text-neutral-medium mt-2">
                          {activeProjects[0].description}
                        </p>

                        <div className="mt-4 flex items-center">
                          <div className="mr-6">
                            <div className="text-sm text-neutral-medium">Completamento</div>
                            <div className="mt-1 flex items-center">
                              <span className="text-primary font-medium">
                                {activeProjects[0].completionPercentage}%
                              </span>
                              <div className="ml-2 w-24 bg-neutral-light rounded-full h-2">
                                <div
                                  className="bg-primary rounded-full h-2"
                                  style={{ width: `${activeProjects[0].completionPercentage}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                          <div className="mr-6">
                            <div className="text-sm text-neutral-medium">Partecipanti</div>
                            <div className="mt-1 font-medium">24 persone</div>
                          </div>
                          <div>
                            <div className="text-sm text-neutral-medium">Deadline</div>
                            <div className="mt-1 font-medium">15 Giugno</div>
                          </div>
                        </div>

                        <div className="mt-4 flex justify-between items-center">
                          <AvatarGroup
                            items={[
                              { fallback: "A" },
                              { fallback: "B" },
                              { fallback: "C" },
                              { fallback: "D" },
                              { fallback: "E" },
                            ]}
                            max={3}
                          />
                          <Link href={`/project-detail/${activeProjects[0].id}`}>
                            <Button className="bg-accent text-white text-sm flex items-center">
                              <Users className="h-4 w-4 mr-1" />
                              Unisciti al progetto
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                  
                  {/* Other active projects */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {activeProjects.slice(1).map(project => (
                      <Card key={project.id} className="overflow-hidden">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <h3 className="font-heading font-medium">{project.name}</h3>
                            <Badge className="bg-accent bg-opacity-10 text-accent">In corso</Badge>
                          </div>
                          <p className="text-neutral-medium text-sm mt-2">
                            {project.description}
                          </p>

                          <div className="mt-3 flex items-center text-sm">
                            <div className="mr-4">
                              <span className="text-neutral-medium">Completamento:</span>
                              <span className="font-medium ml-1">{project.completionPercentage}%</span>
                            </div>
                            <div>
                              <span className="text-neutral-medium">Persone:</span>
                              <span className="font-medium ml-1">12</span>
                            </div>
                          </div>

                          <div className="mt-4 flex justify-between items-center">
                            <AvatarGroup
                              items={[
                                { fallback: "A" },
                                { fallback: "B" },
                                { fallback: "C" },
                              ]}
                              size="sm"
                            />
                            <Link href={`/project-detail/${project.id}`}>
                              <Button variant="ghost" className="text-accent font-medium text-sm">
                                Visualizza
                              </Button>
                            </Link>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </>
              )}
            </TabsContent>
            
            {/* Completed Projects Tab */}
            <TabsContent value="completed" className="space-y-6">
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Skeleton className="h-64 w-full" />
                  <Skeleton className="h-64 w-full" />
                </div>
              ) : completedProjects.length === 0 ? (
                <div className="text-center py-10">
                  <h3 className="text-lg font-heading font-medium mb-2">
                    Nessun progetto comunitario completato
                  </h3>
                  <p className="text-neutral-medium">
                    Non ci sono ancora progetti comunitari completati.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {completedProjects.map(project => (
                    <Card key={project.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <h3 className="font-heading font-medium">{project.name}</h3>
                          <Badge className="bg-success bg-opacity-10 text-success">Completato</Badge>
                        </div>
                        <p className="text-neutral-medium text-sm mt-2">
                          {project.description}
                        </p>

                        <div className="mt-3 flex items-center text-sm">
                          <div className="mr-4">
                            <span className="text-neutral-medium">Completamento:</span>
                            <span className="font-medium ml-1">100%</span>
                          </div>
                          <div>
                            <span className="text-neutral-medium">Persone:</span>
                            <span className="font-medium ml-1">15</span>
                          </div>
                        </div>

                        <div className="mt-4 flex justify-between items-center">
                          <AvatarGroup
                            items={[
                              { fallback: "A" },
                              { fallback: "B" },
                              { fallback: "C" },
                            ]}
                            size="sm"
                          />
                          <Link href={`/project-detail/${project.id}`}>
                            <Button variant="ghost" className="text-accent font-medium text-sm">
                              Visualizza
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </TabsContent>
        
        {/* Forum Tab */}
        <TabsContent value="forum" className="space-y-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
            <Input
              placeholder="Cerca nel forum..."
              className="pl-10 bg-white"
            />
          </div>
          
          <Tabs defaultValue="discussions" className="space-y-6">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="discussions">Discussioni</TabsTrigger>
              <TabsTrigger value="materials">Materiali Cercati</TabsTrigger>
              <TabsTrigger value="ideas">Idee Progetti</TabsTrigger>
            </TabsList>
            
            {/* Discussions Tab */}
            <TabsContent value="discussions" className="space-y-6">
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Come riciclare la plastica dura?</h3>
                      <div className="text-sm text-neutral-medium mt-1">Iniziato da Mario • 2 giorni fa</div>
                    </div>
                    <Badge className="bg-primary-light bg-opacity-10 text-primary">12 risposte</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Ciao a tutti, ho diversi contenitori di plastica dura che vorrei riutilizzare. Avete suggerimenti su come trasformarli in qualcosa di utile?
                  </p>
                  <div className="mt-4 flex justify-between items-center">
                    <AvatarGroup
                      items={[
                        { fallback: "M" },
                        { fallback: "L" },
                        { fallback: "G" },
                      ]}
                      size="sm"
                    />
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Partecipa
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Tecnica pittura su vetro</h3>
                      <div className="text-sm text-neutral-medium mt-1">Iniziato da Laura • 5 giorni fa</div>
                    </div>
                    <Badge className="bg-primary-light bg-opacity-10 text-primary">8 risposte</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Vorrei decorare alcune bottiglie di vetro con la pittura. Quali colori e tecniche mi consigliate per un risultato duraturo?
                  </p>
                  <div className="mt-4 flex justify-between items-center">
                    <AvatarGroup
                      items={[
                        { fallback: "L" },
                        { fallback: "F" },
                        { fallback: "R" },
                      ]}
                      size="sm"
                    />
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Partecipa
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Materials Tab */}
            <TabsContent value="materials" className="space-y-6">
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Cerco legno di pallet</h3>
                      <div className="text-sm text-neutral-medium mt-1">Richiesto da Marco • Milano</div>
                    </div>
                    <Badge className="bg-warning bg-opacity-10 text-warning">Richiesta</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Sto cercando pallet di legno in buono stato per costruire una libreria. Ne servirebbero almeno 5, preferibilmente della stessa dimensione.
                  </p>
                  <div className="mt-4 flex justify-end">
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Offri materiale
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Cerco stoffe colorate</h3>
                      <div className="text-sm text-neutral-medium mt-1">Richiesto da Giulia • Roma</div>
                    </div>
                    <Badge className="bg-warning bg-opacity-10 text-warning">Richiesta</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Per un progetto comunitario cerco ritagli di stoffa colorati. Qualsiasi dimensione va bene, importante che siano puliti e in buono stato.
                  </p>
                  <div className="mt-4 flex justify-end">
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Offri materiale
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Ideas Tab */}
            <TabsContent value="ideas" className="space-y-6">
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Parco giochi con pneumatici</h3>
                      <div className="text-sm text-neutral-medium mt-1">Idea di Paolo • 1 settimana fa</div>
                    </div>
                    <Badge className="bg-accent bg-opacity-10 text-accent">Idea</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Propongo di creare un'area giochi per bambini usando pneumatici riciclati. Potremmo colorarli e creare strutture sicure per i bambini del quartiere.
                  </p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-xs text-neutral-medium">
                      15 persone interessate
                    </span>
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Mi interessa
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-heading font-medium">Giardino verticale da bottiglie</h3>
                      <div className="text-sm text-neutral-medium mt-1">Idea di Sofia • 3 giorni fa</div>
                    </div>
                    <Badge className="bg-accent bg-opacity-10 text-accent">Idea</Badge>
                  </div>
                  <p className="text-neutral-medium text-sm mt-2">
                    Potremmo creare un giardino verticale usando bottiglie di plastica. Sarebbe perfetto per il muro esterno della biblioteca comunale.
                  </p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-xs text-neutral-medium">
                      8 persone interessate
                    </span>
                    <Button variant="ghost" className="text-primary font-medium text-sm">
                      Mi interessa
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
    </PageLayout>
  );
}
