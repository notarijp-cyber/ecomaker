import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageLayout } from "@/components/layout/page-layout";
import { Project, DifficultyLevel, ProjectStatus } from "@/lib/types";
import { ProjectCard } from "@/components/project/project-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyProjects() {
  const userId = 1; // Placeholder for now
  
  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ['/api/projects', { userId }],
  });
  
  const [searchTerm, setSearchTerm] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  
  // Filter projects based on search and filters
  const filteredProjects = projects?.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (project.description?.toLowerCase().includes(searchTerm.toLowerCase()) || false);
    
    const matchesDifficulty = difficultyFilter && difficultyFilter !== "all" ? project.difficulty === difficultyFilter : true;
    
    // Determine status based on completion percentage
    let status = ProjectStatus.NOT_STARTED;
    if (project.completionPercentage > 0 && project.completionPercentage < 100) {
      status = ProjectStatus.IN_PROGRESS;
    } else if (project.completionPercentage === 100) {
      status = ProjectStatus.COMPLETED;
    }
    
    const matchesStatus = statusFilter && statusFilter !== "all" ? status === statusFilter : true;
    
    return matchesSearch && matchesDifficulty && matchesStatus;
  });
  
  // Group projects by status
  const notStarted = filteredProjects?.filter(p => p.completionPercentage === 0) || [];
  const inProgress = filteredProjects?.filter(p => p.completionPercentage > 0 && p.completionPercentage < 100) || [];
  const completed = filteredProjects?.filter(p => p.completionPercentage === 100) || [];
  
  return (
    <PageLayout>
      <div className="mb-8">
        <h2 className="text-2xl font-heading font-bold mb-2">I Miei Progetti</h2>
        <p className="text-neutral-medium">
          Gestisci i tuoi progetti personali e monitora il loro progresso.
        </p>
      </div>
      
      {/* Search and filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-medium" />
          <Input
            placeholder="Cerca progetti..."
            className="pl-10 bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 space-y-1">
            <Label htmlFor="difficulty-filter">Difficoltà</Label>
            <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
              <SelectTrigger id="difficulty-filter">
                <SelectValue placeholder="Tutte le difficoltà" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutte le difficoltà</SelectItem>
                <SelectItem value={DifficultyLevel.EASY}>{DifficultyLevel.EASY}</SelectItem>
                <SelectItem value={DifficultyLevel.MEDIUM}>{DifficultyLevel.MEDIUM}</SelectItem>
                <SelectItem value={DifficultyLevel.ADVANCED}>{DifficultyLevel.ADVANCED}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex-1 space-y-1">
            <Label htmlFor="status-filter">Stato</Label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger id="status-filter">
                <SelectValue placeholder="Tutti gli stati" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti gli stati</SelectItem>
                <SelectItem value={ProjectStatus.NOT_STARTED}>{ProjectStatus.NOT_STARTED}</SelectItem>
                <SelectItem value={ProjectStatus.IN_PROGRESS}>{ProjectStatus.IN_PROGRESS}</SelectItem>
                <SelectItem value={ProjectStatus.COMPLETED}>{ProjectStatus.COMPLETED}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      
      {/* Project tabs */}
      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="w-full grid grid-cols-4">
          <TabsTrigger value="all">Tutti ({filteredProjects?.length || 0})</TabsTrigger>
          <TabsTrigger value="not-started">Da iniziare ({notStarted.length})</TabsTrigger>
          <TabsTrigger value="in-progress">In corso ({inProgress.length})</TabsTrigger>
          <TabsTrigger value="completed">Completati ({completed.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-6">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Skeleton className="h-96 w-full" />
              <Skeleton className="h-96 w-full" />
              <Skeleton className="h-96 w-full" />
            </div>
          ) : filteredProjects?.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">Nessun progetto trovato</h3>
              <p className="text-neutral-medium">
                Prova a modificare i filtri o crea un nuovo progetto.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProjects?.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="not-started" className="space-y-6">
          {notStarted.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">Nessun progetto da iniziare</h3>
              <p className="text-neutral-medium">
                Tutti i tuoi progetti sono già stati avviati o non hai ancora creato progetti.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {notStarted.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="in-progress" className="space-y-6">
          {inProgress.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">Nessun progetto in corso</h3>
              <p className="text-neutral-medium">
                Non hai progetti attualmente in lavorazione.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {inProgress.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed" className="space-y-6">
          {completed.length === 0 ? (
            <div className="text-center py-10">
              <h3 className="text-lg font-heading font-medium mb-2">Nessun progetto completato</h3>
              <p className="text-neutral-medium">
                Non hai ancora completato nessun progetto.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {completed.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </PageLayout>
  );
}
