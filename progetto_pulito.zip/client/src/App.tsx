import { Switch, Route } from "wouter";
import Dashboard from "@/pages/dashboard";
import MyProjects from "@/pages/my-projects";
import Inventory from "@/pages/inventory";
import Community from "@/pages/community";
import Events from "@/pages/events";
import EnvironmentalImpact from "@/pages/environmental-impact";
import EnvironmentalAnalytics from "@/pages/environmental-analytics";
import Gamification from "@/pages/gamification";
import ProjectDetail from "@/pages/project-detail";
import MaterialDetail from "@/pages/material-detail";
import CreateProject from "@/pages/create-project";
import ProjectCrowdfunding from "@/pages/project-crowdfunding";
import AIAssistant from "@/pages/ai-assistant";
import MaterialScience from "@/pages/material-science";
import ThingiverseModels from "@/pages/thingiverse-models";
import ARMaterialVisualization from "@/pages/ar-material-visualization";
import AdvancedFeatures from "@/pages/advanced-features";
import NotFound from "@/pages/not-found";
// Footer pages
import RecycleGuides from "@/pages/recycle-guides";
import SustainabilityBlog from "@/pages/sustainability-blog";
import FAQ from "@/pages/faq";
import Contact from "@/pages/contact";
import Donate from "@/pages/donate";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import CookiePolicy from "@/pages/cookie-policy";
import InnovationCenterPage from "@/pages/innovation-center";
import PerformanceMonitorPage from "@/pages/performance-monitor";
import SmartRecommendationsPage from "@/pages/smart-recommendations";
import AdvancedSustainabilityPage from "@/pages/advanced-sustainability";
import InternalDatabase from "@/pages/internal-database";
import MaterialLifecycleAnimator from "@/pages/material-lifecycle-animator";
import EcoGamificationSystem from "@/pages/eco-gamification-system";
import PersonalizedRecommendations from "@/pages/personalized-recommendations";
import CarbonFootprintVisualizer from "@/pages/carbon-footprint-visualizer";
import CommunityStorytellingPlatform from "@/pages/community-storytelling-platform";
import PlayfulEcoBadgeSystem from "@/pages/playful-eco-badge-system";
import MicroInteractionRewards from "@/pages/micro-interaction-rewards";
import ARMaterialScanPreview from "@/pages/ar-material-scan-preview";
import EcoJourneyVisualization from "@/pages/eco-journey-visualization";
import System150424Admin from "@/pages/system-150424-admin";
import KickstarterDownloads from "@/pages/kickstarter-downloads";
import KickstarterDemo from "@/pages/kickstarter-demo";
import GmailSetup from "@/pages/gmail-setup";
import EmailSetup from "@/pages/email-setup";
import KickstarterDownloadFAB from "@/components/ui/kickstarter-download-fab";
import MobileNav from "@/components/layout/MobileNav";
import { FuturisticHeader } from "@/components/layout/FuturisticHeader";
import Footer from "@/components/layout/footer";
import { useIsMobile } from "@/hooks/use-mobile";
import { Toaster } from "@/components/ui/toaster";

function App() {
  const isMobile = useIsMobile();

  return (
    <div className="flex flex-col min-h-screen futuristic-bg">
      {/* Global Header */}
      <FuturisticHeader />
      
      {/* Main Application Content */}
      <div className="flex flex-1">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/my-projects" component={MyProjects} />
          <Route path="/inventory" component={Inventory} />
          <Route path="/community" component={Community} />
          <Route path="/events" component={Events} />
          <Route path="/environmental-impact" component={EnvironmentalImpact} />
          <Route path="/environmental-analytics" component={EnvironmentalAnalytics} />
          <Route path="/gamification" component={Gamification} />
          <Route path="/innovation-center" component={InnovationCenterPage} />
          <Route path="/performance-monitor" component={PerformanceMonitorPage} />
          <Route path="/smart-recommendations" component={SmartRecommendationsPage} />
          <Route path="/advanced-sustainability" component={AdvancedSustainabilityPage} />
          <Route path="/internal-database" component={InternalDatabase} />
          <Route path="/material-lifecycle" component={MaterialLifecycleAnimator} />
          <Route path="/eco-gamification" component={EcoGamificationSystem} />
          <Route path="/personalized-recommendations" component={PersonalizedRecommendations} />
          <Route path="/carbon-footprint" component={CarbonFootprintVisualizer} />
          <Route path="/community-storytelling" component={CommunityStorytellingPlatform} />
          <Route path="/playful-badges" component={PlayfulEcoBadgeSystem} />
          <Route path="/micro-rewards" component={MicroInteractionRewards} />
          <Route path="/ar-material-scan" component={ARMaterialScanPreview} />
          <Route path="/eco-journey" component={EcoJourneyVisualization} />
          <Route path="/project-detail/:id" component={ProjectDetail} />
          <Route path="/material-detail/:id" component={MaterialDetail} />
          <Route path="/create-project" component={CreateProject} />
          <Route path="/project-crowdfunding/:id" component={ProjectCrowdfunding} />
          <Route path="/ai-assistant" component={AIAssistant} />
          <Route path="/material-science" component={MaterialScience} />
          <Route path="/thingiverse-models" component={ThingiverseModels} />
          <Route path="/ar-material-visualization" component={ARMaterialVisualization} />
          <Route path="/system-150424" component={System150424Admin} />
          <Route path="/kickstarter-downloads" component={KickstarterDownloads} />
          <Route path="/kickstarter-demo" component={KickstarterDemo} />
          <Route path="/gmail-setup" component={GmailSetup} />
          <Route path="/email-setup" component={EmailSetup} />
          <Route path="/advanced-features" component={AdvancedFeatures} />
          {/* Footer Pages */}
          <Route path="/recycle-guides" component={RecycleGuides} />
          <Route path="/sustainability-blog" component={SustainabilityBlog} />
          <Route path="/faq" component={FAQ} />
          <Route path="/contact" component={Contact} />
          <Route path="/donate" component={Donate} />
          <Route path="/privacy-policy" component={PrivacyPolicy} />
          <Route path="/terms-of-service" component={TermsOfService} />
          <Route path="/cookie-policy" component={CookiePolicy} />
          <Route component={NotFound} />
        </Switch>
      </div>
      
      {/* Footer */}
      <Footer />
      
      {/* Mobile Navigation */}
      {isMobile && <MobileNav />}
      
      {/* Kickstarter Download FAB */}
      <KickstarterDownloadFAB />
      
      {/* Toast notifications */}
      <Toaster />
    </div>
  );
}

export default App;
