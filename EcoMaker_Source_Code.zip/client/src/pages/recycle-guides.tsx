import React from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { ArrowLeft, Recycle, Leaf, Trash2, Box, Droplet, Zap, Shirt } from "lucide-react";
import { RECYCLE_STANDARDS } from "@/lib/recycling-standards";

export default function RecycleGuidesPage() {
  const [, setLocation] = useLocation();

  // Mappa le icone agli standard
  const getIcon = (id: string) => {
      switch(id) {
          case 'paper': return <Box className="w-5 h-5"/>;
          case 'plastic_metal': return <Recycle className="w-5 h-5"/>;
          case 'glass': return <Droplet className="w-5 h-5"/>;
          case 'organic': return <Leaf className="w-5 h-5"/>;
          case 'weee': return <Zap className="w-5 h-5"/>;
          case 'textile': return <Shirt className="w-5 h-5"/>;
          default: return <Trash2 className="w-5 h-5"/>;
      }
  };

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen text-white pb-20">
      
      {/* HEADER */}
      <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={() => setLocation('/dashboard')} className="text-slate-400 hover:text-white pl-0">
            <ArrowLeft className="w-5 h-5 mr-2"/> Dashboard
          </Button>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Recycle className="text-green-500 animate-spin-slow"/> 
            Guida Galattica al Riciclo
          </h1>
      </div>

      <div className="max-w-5xl mx-auto">
          <p className="text-slate-400 mb-8 text-center max-w-2xl mx-auto">
              Non sai dove buttare quel rifiuto? Consulta il database ufficiale Quantum Eco-Standard.
              Segui i colori per non sbagliare mai.
          </p>

          <Tabs defaultValue="plastic_metal" className="w-full">
            
            {/* LISTA CATEGORIE COLORATE */}
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-7 h-auto bg-slate-900 border border-slate-800 p-2 gap-2">
                {Object.values(RECYCLE_STANDARDS).map((std) => (
                    <TabsTrigger 
                        key={std.id} 
                        value={std.id}
                        className="flex flex-col items-center gap-2 py-3 data-[state=active]:bg-slate-800 transition-all"
                        style={{ borderBottom: `4px solid ${std.color}` }}
                    >
                        <div style={{ color: std.color }}>{getIcon(std.id)}</div>
                        <span className="text-[10px] uppercase font-bold text-slate-300">{std.label.split(' ')[0]}</span>
                    </TabsTrigger>
                ))}
            </TabsList>

            {/* CONTENUTO GUIDE */}
            <div className="mt-8">
                {Object.values(RECYCLE_STANDARDS).map((std) => (
                    <TabsContent key={std.id} value={std.id} className="animate-in fade-in slide-in-from-bottom-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            
                            {/* COLONNA VISUALE (BIDONE) */}
                            <Card className="border-0 overflow-hidden flex flex-col items-center justify-center h-80 relative shadow-2xl" 
                                  style={{ backgroundColor: std.color }}>
                                <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                                {getIcon(std.id)} {/* Icona Grande al centro */}
                                <h2 className="text-4xl font-black text-black/80 mt-4 text-center px-4">{std.label}</h2>
                                <div className="mt-4 bg-black/20 px-6 py-2 rounded-full text-white font-mono font-bold border border-white/20">
                                    {std.container}
                                </div>
                            </Card>

                            {/* COLONNA REGOLE */}
                            <div className="space-y-4">
                                <Card className="bg-[#1a1d2d] border-slate-700">
                                    <CardHeader><CardTitle className="text-green-400 flex items-center"><Leaf className="mr-2 w-4 h-4"/> COSA INSERIRE</CardTitle></CardHeader>
                                    <CardContent>
                                        <p className="text-slate-300 leading-relaxed text-lg">{std.rules}</p>
                                    </CardContent>
                                </Card>

                                <Card className="bg-[#1a1d2d] border-slate-700">
                                    <CardHeader><CardTitle className="text-cyan-400 flex items-center"><Recycle className="mr-2 w-4 h-4"/> DESTINAZIONE FINALE</CardTitle></CardHeader>
                                    <CardContent>
                                        <p className="text-slate-300">{std.destination}</p>
                                    </CardContent>
                                </Card>

                                <div className="bg-yellow-900/20 border border-yellow-700/50 p-4 rounded-lg flex gap-3">
                                    <Trash2 className="text-yellow-500 shrink-0" />
                                    <p className="text-sm text-yellow-200">
                                        <strong>Attenzione:</strong> Se il materiale è sporco o unto, va quasi sempre nel secco indifferenziato (tranne i piatti di plastica che vanno sciacquati).
                                    </p>
                                </div>
                            </div>
                        </div>
                    </TabsContent>
                ))}
            </div>

          </Tabs>
      </div>
    </div>
  );
}