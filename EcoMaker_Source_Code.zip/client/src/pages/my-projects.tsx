import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FolderGit2, Lock, Database, ArrowRight, Eye } from 'lucide-react';
import { useLocation } from "wouter";
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";

export default function MyProjects() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState<any>(null);
  const [isBot, setIsBot] = useState(false);
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
        setUser(u);
        setIsBot(u?.email === "ecomakerteamtest@gmail.com");
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    let q;

    if (isBot) {
        // Il Bot vede il DB Segreto
        q = query(collection(db, "secret_projects_db"), orderBy("createdAt", "desc"));
    } else {
        // L'utente vede i suoi progetti
        q = query(collection(db, "projects"), where("authorId", "==", user.uid), orderBy("createdAt", "desc"));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setProjects(data);
        setLoading(false);
    });
    return () => unsubscribe();
  }, [user, isBot]);

  if (loading) return <div className="p-20 text-center text-cyan-500 animate-pulse">Caricamento Database...</div>;

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen space-y-8 text-white">
      
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
            <h1 className="text-3xl font-bold mb-2">
                {isBot ? "Archivio Progetti Master (Admin)" : "I Miei Progetti"}
            </h1>
            <p className="text-slate-400">
                {isBot ? "Blueprint segreti generati dall'IA." : "I tuoi lavori in corso."}
            </p>
        </div>
    </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((proj) => (
              <Card key={proj.id} className={`bg-[#1a1d2d] border-slate-700 overflow-hidden flex flex-col ${isBot ? 'border-purple-900/50' : ''}`}>
                  <CardHeader className="pb-3">
                      <div className="flex justify-between items-start mb-2">
                          <Badge className={isBot ? "bg-purple-900 text-purple-200" : "bg-cyan-900 text-cyan-200"}>
                              {isBot ? "MASTER" : proj.status || "In Corso"}
                          </Badge>
                          {isBot && <Lock className="w-4 h-4 text-slate-500" />}
                      </div>
                      <CardTitle className="text-lg text-white leading-tight">{proj.title}</CardTitle>
                  </CardHeader>
                  
                  <CardContent className="flex-1">
                      <p className="text-sm text-slate-400 line-clamp-3 mb-4">{proj.description}</p>
                      <div className="flex gap-2 text-xs text-slate-500 font-mono">
                          <span className="bg-black/30 px-2 py-1 rounded">Diff: {proj.difficulty}</span>
                          <span className="bg-black/30 px-2 py-1 rounded">Tempo: {proj.timeEstimate || proj.time}</span>
                      </div>
                  </CardContent>

                  <CardFooter className="pt-4 border-t border-slate-800 bg-black/20">
                      {isBot ? (
                          // BOTTONE SBLOCCATO PER IL BOT
                          <Button variant="ghost" className="w-full text-purple-400 hover:text-white hover:bg-purple-900/20" 
                                  onClick={() => setLocation(`/project-detail/${proj.id}?secret=true`)}>
                              <Eye className="w-4 h-4 mr-2" /> Ispeziona Blueprint
                          </Button>
                      ) : (
                          <Button variant="ghost" className="w-full text-cyan-400 hover:text-white hover:bg-cyan-900/20" 
                                  onClick={() => setLocation(`/project-detail/${proj.id}`)}>
                              Apri Progetto <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                      )}
                  </CardFooter>
              </Card>
          ))}
      </div>
    </div>
  );
}