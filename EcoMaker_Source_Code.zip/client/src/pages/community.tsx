import React, { useState, useEffect } from 'react';
import { useLocation } from "wouter";
import { 
  Search, Filter, Heart, Zap, User, Clock, 
  BarChart3, Leaf, ArrowRight, Bot, Database 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { db, auth } from "@/lib/firebase";
import { collection, query, orderBy, limit, onSnapshot, doc, updateDoc, increment, arrayUnion, arrayRemove } from "firebase/firestore";

export default function Community() {
  const [, setLocation] = useLocation();
  const [projects, setProjects] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Tutti");
  const [isLoading, setIsLoading] = useState(true);

  // Categorie per i filtri
  const categories = ["Tutti", "Plastica", "Legno", "Metallo", "Vetro", "Elettronica", "Cartone"];

  // --- ASCOLTO TEMPO REALE DAL DB ---
  useEffect(() => {
    // Ordina per più recenti, limite 50 per fluidità
    const q = query(collection(db, "projects"), orderBy("createdAt", "desc"), limit(50));
    
    // onSnapshot = CONNESSIONE VIVA (Appena il bot scrive, qui appare)
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setProjects(projs);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLike = async (projectId: string, currentLikes: number, likedBy: string[] = []) => {
    if (!auth.currentUser) return;
    const uid = auth.currentUser.uid;
    const isLiked = likedBy.includes(uid);

    const projectRef = doc(db, "projects", projectId);
    
    if (isLiked) {
        await updateDoc(projectRef, {
            likes: increment(-1),
            likedBy: arrayRemove(uid)
        });
    } else {
        await updateDoc(projectRef, {
            likes: increment(1),
            likedBy: arrayUnion(uid)
        });
    }
  };

  // Filtro locale veloce
  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.title?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === "Tutti" || 
                       p.materialTag?.toLowerCase().includes(selectedCategory.toLowerCase());
    return matchesSearch && matchesCat;
  });

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen space-y-8 pb-20">
      
      {/* HEADER & STATS */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-cyan-500 bg-clip-text text-transparent">
            Global Quantum Feed
          </h1>
          <p className="text-slate-400 mt-2 flex items-center">
            <Zap className="w-4 h-4 text-yellow-400 mr-2" />
            {projects.length} Progetti attivi nel network
          </p>
        </div>
        
        {/* Barra di Ricerca */}
        <div className="flex gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 w-4 h-4" />
            <Input 
              placeholder="Cerca progetti..." 
              className="pl-10 bg-black/50 border-slate-700 text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* FILTRI CATEGORIE */}
      <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {categories.map(cat => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "default" : "outline"}
            onClick={() => setSelectedCategory(cat)}
            className={`whitespace-nowrap ${selectedCategory === cat ? 'bg-cyan-600' : 'border-slate-700 text-slate-400'}`}
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* GRID PROGETTI */}
      {isLoading ? (
         <div className="text-center py-20 animate-pulse text-cyan-500">Sincronizzazione Feed Quantico...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <Card key={project.id} className="glass-morph border-slate-700 bg-[#1a1d2d]/80 hover:border-cyan-500/50 transition-all duration-300 group overflow-hidden flex flex-col">
              
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className={`${project.authorName === 'EcoTester_Bot' ? 'border-purple-500 text-purple-400 bg-purple-900/20' : 'border-blue-500 text-blue-400'}`}>
                    {project.authorName === 'EcoTester_Bot' ? <Bot className="w-3 h-3 mr-1"/> : <User className="w-3 h-3 mr-1"/>}
                    {project.authorName === 'EcoTester_Bot' ? 'AI GENERATED' : project.authorName}
                  </Badge>
                  <div className="text-xs text-slate-500 flex items-center bg-black/30 px-2 py-1 rounded">
                    <Clock className="w-3 h-3 mr-1" /> {project.time || "N/A"}
                  </div>
                </div>
                <CardTitle className="text-xl text-white group-hover:text-cyan-400 transition-colors line-clamp-1">
                  {project.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4 flex-1">
                <p className="text-slate-400 text-sm line-clamp-3">
                  {project.description}
                </p>
                
                <div className="flex justify-between items-center text-xs font-mono">
                  <div className="flex items-center text-green-400">
                    <Leaf className="w-3 h-3 mr-1" /> -{project.co2 || 0}kg CO2
                  </div>
                  <div className="flex items-center text-yellow-400">
                    <Zap className="w-3 h-3 mr-1" /> {project.difficulty}
                  </div>
                </div>
              </CardContent>

              <CardFooter className="pt-4 border-t border-slate-800 bg-black/20 flex justify-between items-center">
                <Button 
                    variant="ghost" 
                    size="sm" 
                    className={`text-slate-400 hover:text-red-400 ${project.likedBy?.includes(auth.currentUser?.uid) ? 'text-red-500' : ''}`}
                    onClick={() => handleLike(project.id, project.likes || 0, project.likedBy || [])}
                >
                  <Heart className={`w-4 h-4 mr-1 ${project.likedBy?.includes(auth.currentUser?.uid) ? 'fill-current' : ''}`} /> 
                  {project.likes || 0}
                </Button>
                
                <Button 
                    size="sm" 
                    className="bg-cyan-900/50 hover:bg-cyan-800 text-cyan-200 border border-cyan-700"
                    onClick={() => setLocation(`/project-detail/${project.id}`)}
                >
                  Blueprint <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </CardFooter>

              {/* Effetto visuale se è un backup */}
              {project.source === "BACKUP" && (
                  <div className="absolute top-0 right-0 w-2 h-2 bg-yellow-500 rounded-full m-2 animate-pulse" title="Sistema di Backup" />
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}