import React, { useState, useEffect } from 'react';
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Box, Plus, Minus, Info, Database, Search, Camera, ArrowRight, Recycle, Trash2 
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { collection, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";

export default function Inventory() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const [user, setUser] = useState<any>(null);
  const [isBot, setIsBot] = useState(false);
  const [inventoryItems, setInventoryItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
        setUser(u);
        setIsBot(u?.email === "ecomakerteamtest@gmail.com");
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    let q;

    if (isBot) {
        // BOT: Legge Repository, ordina per 'scannedAt' (nuovo standard)
        q = query(collection(db, "repository"), orderBy("scannedAt", "desc"));
    } else {
        // UMANO: Legge Inventario
        q = query(collection(db, "users", user.uid, "inventory"), orderBy("scannedAt", "desc"));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
        const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setInventoryItems(items);
        setLoading(false);
    });
    return () => unsubscribe();
  }, [user, isBot]);

  // Gestione Quantità (Solo Umani)
  const updateQuantity = async (itemId: string, currentQty: number, change: number, e: React.MouseEvent) => {
      e.preventDefault(); e.stopPropagation();
      if (!user || isBot) return;
      const newQty = (currentQty || 1) + change;
      if (newQty < 1) {
          if (window.confirm("Rimuovere dall'inventario?")) {
              await deleteDoc(doc(db, "users", user.uid, "inventory", itemId));
              toast({ title: "Materiale rimosso" });
          }
          return;
      }
      await updateDoc(doc(db, "users", user.uid, "inventory", itemId), { quantity: newQty });
  };

  const filteredItems = inventoryItems.filter(item => 
      (item.name || item.commonName || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.category || "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="flex justify-center h-screen items-center text-cyan-500 animate-pulse"><Database className="w-12 h-12 mb-4"/></div>;

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen space-y-8 pb-20 text-white">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
                {isBot ? "Repository Materiali (AI)" : "Il Tuo Inventario"}
            </h1>
            <p className="text-slate-400 mt-2 flex items-center">
                <Box className="w-4 h-4 mr-2 text-yellow-500" /> 
                {inventoryItems.length} {isBot ? "Materiali Classificati" : "Oggetti Disponibili"}
            </p>
        </div>
        <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 w-4 h-4" />
            <Input placeholder="Cerca..." className="pl-10 bg-slate-900/50 border-slate-700 text-white" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
      </div>

      {/* GRIGLIA MATERIALI */}
      {filteredItems.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-slate-800 rounded-xl bg-slate-900/20">
              <p className="text-slate-500 mb-6">Nessun materiale trovato.</p>
              {!isBot && <Button onClick={() => setLocation('/ar-material-scan')} className="bg-cyan-600"><Camera className="w-4 h-4 mr-2" /> Scanner AR</Button>}
          </div>
      ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredItems.map((item) => {
                // Usa il colore del riciclo se presente, altrimenti un default scuro
                const cardColor = item.recycleColor || "#1e293b"; 
                
                return (
                <Link key={item.id} href={`/material-detail/${item.id}`}>
                    <Card className="border-0 bg-slate-900 overflow-hidden flex flex-col group transition-all duration-300 hover:scale-105 cursor-pointer shadow-lg">
                        
                        {/* PARTE SUPERIORE COLORATA (VISUAL) */}
                        <div className="relative h-32 flex items-center justify-center overflow-hidden" style={{ backgroundColor: cardColor }}>
                            <Recycle className="w-16 h-16 text-black/20 group-hover:rotate-180 transition-transform duration-700" />
                            <div className="absolute bottom-2 right-2">
                                <Badge className="bg-black/40 text-white border-none backdrop-blur-sm">
                                    {item.category || "Materiale"}
                                </Badge>
                            </div>
                        </div>

                        <CardHeader className="pb-2">
                            <CardTitle className="text-lg text-white truncate">{item.name || item.commonName}</CardTitle>
                            <p className="text-xs text-slate-400 font-mono">
                                {item.disposalRule ? item.disposalRule.substring(0, 25) + "..." : "Indifferenziato"}
                            </p>
                        </CardHeader>
                        
                        <CardFooter className="mt-auto pt-4 border-t border-slate-800 bg-black/20 flex justify-between items-center">
                            {!isBot ? (
                                <div className="flex items-center gap-1 bg-slate-900 rounded-lg p-1 border border-slate-700" onClick={(e) => e.stopPropagation()}>
                                    <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-red-400" onClick={(e) => updateQuantity(item.id, item.quantity, -1, e)}><Minus className="w-3 h-3" /></Button>
                                    <span className="font-bold text-white w-8 text-center tabular-nums">{item.quantity || 1}</span>
                                    <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-green-400" onClick={(e) => updateQuantity(item.id, item.quantity, 1, e)}><Plus className="w-3 h-3" /></Button>
                                </div>
                            ) : (
                                <span className="text-xs text-cyan-500 flex items-center">Scheda Tecnica <ArrowRight className="w-3 h-3 ml-1" /></span>
                            )}
                        </CardFooter>
                    </Card>
                </Link>
              )
            })}
          </div>
      )}
    </div>
  );
}