import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Mail, Lock, ArrowRight, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { auth } from "@/lib/firebase";
import { signInWithEmailAndPassword, signOut } from "firebase/auth";

// ACCOUNT CHE NON RICHIEDONO VERIFICA EMAIL
const DEV_WHITELIST = ["newbie@test.com", "ecomakerteam@gmail.com"];

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  // Form State
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // 1. TENTA IL LOGIN
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // 2. CONTROLLO SPECIALE (BYPASS PER DEV)
      const isDevAccount = user.email && DEV_WHITELIST.includes(user.email);

      // 3. SE NON È VERIFICATO E NON È DEV -> BLOCCA
      if (!user.emailVerified && !isDevAccount) {
        await signOut(auth); // Disconnetti subito
        toast({
          title: "Email Non Verificata",
          description: "Controlla la tua casella di posta per attivare l'account.",
          variant: "destructive",
        });
        setLoading(false);
        return; // Ferma tutto qui
      }

      // 4. SUCCESSO -> VAI ALLA DASHBOARD
      toast({
        title: "Bentornato Maker!",
        description: "Accesso effettuato con successo.",
        className: "bg-emerald-500/20 text-white border-emerald-500/50"
      });
      
      setLocation("/dashboard");

    } catch (error: any) {
      console.error(error);
      let errorMsg = "Credenziali non valide.";
      if (error.code === 'auth/user-not-found') errorMsg = "Utente non trovato.";
      if (error.code === 'auth/wrong-password') errorMsg = "Password errata.";
      if (error.code === 'auth/too-many-requests') errorMsg = "Troppi tentativi. Riprova più tardi.";
      
      toast({
        title: "Errore Accesso",
        description: errorMsg,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f111a] flex items-center justify-center p-4 relative overflow-hidden">
      
      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-600/20 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-600/20 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-md bg-[#1a1d2d]/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 shadow-2xl relative z-10 animate-in fade-in zoom-in duration-500">
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 mb-4 shadow-lg shadow-purple-500/20">
            <span className="text-3xl">🌱</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">EcoMaker Hub</h1>
          <p className="text-slate-400">Accedi al tuo terminale di riciclo.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input 
                type="email" 
                placeholder="Email" 
                className="pl-10 bg-black/40 border-slate-700 text-white h-12 focus:border-cyan-500 transition-colors"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input 
                type="password" 
                placeholder="Password" 
                className="pl-10 bg-black/40 border-slate-700 text-white h-12 focus:border-cyan-500 transition-colors"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="text-right">
              <Link href="/reset-password">
                <span className="text-xs text-cyan-400 hover:text-cyan-300 cursor-pointer">Password dimenticata?</span>
              </Link>
            </div>
          </div>

          <Button 
            type="submit" 
            disabled={loading}
            className="w-full h-12 bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 text-white font-bold text-lg shadow-lg shadow-cyan-500/20 transition-all duration-300 transform hover:scale-[1.02]"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Accedi al Sistema"}
          </Button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-700/50 text-center">
          <p className="text-slate-400 mb-4">Non hai ancora un account?</p>
          <Link href="/auth">
            <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:text-white hover:border-white hover:bg-white/5 group">
              Crea ID Maker <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        {/* HELP BOX PER TESTER */}
        {email === "newbie@test.com" && (
           <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded text-xs text-yellow-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>Modalità Test Rilevata: Il controllo email verrà saltato.</span>
           </div>
        )}

      </div>
    </div>
  );
}