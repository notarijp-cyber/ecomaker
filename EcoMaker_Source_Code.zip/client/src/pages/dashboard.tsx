// Copyright (c) 2026 Jacopo Primo Notari. All rights reserved.
// This code is proprietary and confidential. Unauthorized copying is prohibited.
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Leaf, Award, TrendingUp, Zap, Box, Scan, Gavel, Store, Activity, User, Shield, Loader } from 'lucide-react'; 
import { useLocation, Link } from "wouter";
import { useBotContext } from "@/context/bot-context"; 
import { auth, db } from "@/lib/firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { OnboardingWizard } from "@/components/dashboard/OnboardingWizard"; 
import { DashboardTour } from "@/components/dashboard/DashboardTour"; 

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { isBotActive } = useBotContext(); 
  
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showWizard, setShowWizard] = useState(false);
  const [showTour, setShowTour] = useState(false);

  // --- CONFIGURAZIONE LIVELLI (GOD MODE) ---
  const levelConfigs: any = {
    1: { xp: 0, credits: 30, items: 0, co2: 0, label: "Novizio", color: "bg-slate-600" },
    2: { xp: 500, credits: 150, items: 15, co2: 5, label: "Apprendista", color: "bg-emerald-600" },
    3: { xp: 1500, credits: 450, items: 40, co2: 20, label: "Esperto", color: "bg-cyan-600" },
    4: { xp: 4000, credits: 1200, items: 100, co2: 80, label: "Veterano", color: "bg-violet-600" },
    5: { xp: 10000, credits: 5000, items: 300, co2: 250, label: "Master", color: "bg-amber-500" }
  };

  const setLevel = async (lvl: number) => {
    if (!auth.currentUser) return;
    const config = levelConfigs[lvl];
    try {
        await setDoc(doc(db, "users", auth.currentUser.uid), {
            level: lvl, experience: config.xp, credits: config.credits, 
            scannedItems: config.items, co2Saved: config.co2
        }, { merge: true });
        
        setUserData((prev: any) => ({ ...prev, level: lvl, experience: config.xp, credits: config.credits }));
        toast({ title: `LIVELLO ${lvl} ATTIVATO`, className: `${config.color} text-white border-none` });
    } catch (e: any) { console.error(e); }
  };

  useEffect(() => {
      if (auth.currentUser) {
          const loadStats = async () => {
              const snap = await getDoc(doc(db, "users", auth.currentUser.uid));
              if (snap.exists()) {
                  const data = snap.data();
                  setUserData(data);
                  if (!data.tutorialCompleted) setShowWizard(true);
              }
              setLoading(false);
          };
          loadStats();
      }
  }, []);

  const handleWizardComplete = () => {
    setShowWizard(false);
    setTimeout(() => setShowTour(true), 500); 
  };

  if (loading) return <div className="h-screen flex items-center justify-center bg-[#0f111a] text-white"><Loader className="animate-spin mr-2"/> Caricamento...</div>;

  const isBot = auth.currentUser?.email === "ecomakerteamtest@gmail.com";

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen space-y-8 text-white pb-20">
      
      {showWizard && <OnboardingWizard onComplete={handleWizardComplete} />}
      {showTour && <DashboardTour onClose={() => setShowTour(false)} />}

      {/* GOD MODE PANEL */}
      {isBot && (
          <div className="w-full bg-slate-900/50 border border-slate-700 p-4 rounded-xl flex items-center justify-between gap-4 mb-6">
              <div className="text-slate-400 text-xs font-mono flex items-center"><Activity className="w-4 h-4 mr-2 text-cyan-400" /> GOD MODE</div>
              <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((lvl) => (
                      <Button key={lvl} onClick={() => setLevel(lvl)} className={`h-8 w-12 font-bold text-white shadow-lg ${levelConfigs[lvl].color} border-none`}>L{lvl}</Button>
                  ))}
              </div>
          </div>
      )}

      {/* HEADER */}
      <div className="bg-gradient-to-r from-[#0f111a] to-[#1a1d2d] p-8 rounded-2xl border border-slate-800 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 flex gap-2">
              {[1, 2, 3, 4, 5].map(lvl => (
                  <div key={lvl} className={`w-10 h-8 rounded flex items-center justify-center text-xs font-bold ${userData?.level >= lvl ? 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-[0_0_10px_rgba(6,182,212,0.5)]' : 'bg-slate-800 text-slate-600'}`}>
                      L{lvl}
                  </div>
              ))}
          </div>
          
          <h1 className="text-4xl md:text-6xl font-black bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 mb-2">
              EcoCreator Quantum Hub
          </h1>
          <p className="text-slate-400 text-lg flex items-center gap-2">
              Bentornato, <span className="text-white font-bold">{userData?.username || "Maker"}</span>. 
              {isBotActive && <Badge className="bg-green-500/20 text-green-400 border-green-500 animate-pulse">SYSTEM ONLINE</Badge>}
          </p>
      </div>

      {/* STATISTICHE */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-[#1a1d2d] border-slate-800">
              <CardHeader className="pb-2"><CardTitle className="text-sm text-slate-400">Livello Attuale</CardTitle></CardHeader>
              <CardContent><div className="text-4xl font-black text-purple-400 flex items-center gap-2"><Award /> {userData?.level || 1}</div></CardContent>
          </Card>
          <Card className="bg-[#1a1d2d] border-slate-800">
              <CardHeader className="pb-2"><CardTitle className="text-sm text-slate-400">Crediti Quantum</CardTitle></CardHeader>
              <CardContent><div className="text-4xl font-black text-yellow-400 flex items-center gap-2"><Zap /> {userData?.credits || 0}</div></CardContent>
          </Card>
          <Card className="bg-[#1a1d2d] border-slate-800">
              <CardHeader className="pb-2"><CardTitle className="text-sm text-slate-400">Materiali</CardTitle></CardHeader>
              <CardContent><div className="text-4xl font-black text-blue-400 flex items-center gap-2"><Box /> {userData?.scannedItems || 0}</div></CardContent>
          </Card>
          <Card className="bg-[#1a1d2d] border-slate-800">
              <CardHeader className="pb-2"><CardTitle className="text-sm text-slate-400">Impatto CO2</CardTitle></CardHeader>
              <CardContent><div className="text-4xl font-black text-green-400 flex items-center gap-2"><TrendingUp /> -{userData?.co2Saved || 0}kg</div></CardContent>
          </Card>
      </div>

      {/* NAVIGAZIONE RAPIDA */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-purple-900/40 to-slate-900 p-6 rounded-xl border border-purple-500/30 flex items-center justify-between hover:scale-[1.02] transition-transform cursor-pointer" onClick={() => setLocation('/profile')}>
              <div>
                  <h3 className="text-xl font-bold text-white">Profilo Completo</h3>
                  <p className="text-sm text-slate-400">Visualizza il profilo e i badge.</p>
              </div>
              <Button size="icon" className="bg-purple-600 rounded-full h-12 w-12"><Award className="w-6 h-6"/></Button>
          </div>
          
          <div className="bg-gradient-to-br from-cyan-900/40 to-slate-900 p-6 rounded-xl border border-cyan-500/30 flex items-center justify-between hover:scale-[1.02] transition-transform cursor-pointer" onClick={() => setLocation(isBot ? '/bot-command-center' : '/ar-material-scan')}>
              <div>
                  <h3 className="text-xl font-bold text-white">{isBot ? "Bot Command Center" : "Scansione AI"}</h3>
                  <p className="text-sm text-slate-400">{isBot ? "Gestisci il sistema autonomo." : "Avvia lo scanner e genera progetti."}</p>
              </div>
              <Button size="icon" className="bg-cyan-600 rounded-full h-12 w-12"><Scan className="w-6 h-6"/></Button>
          </div>
      </div>

      {/* NUOVI TASTI MARKET & ASTA */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Button className="h-24 bg-[#1a1d2d] border-2 border-yellow-600/50 hover:border-yellow-500 hover:bg-yellow-900/20 text-yellow-500 flex flex-col items-center justify-center gap-2 transition-all shadow-lg hover:shadow-yellow-500/20" onClick={() => setLocation('/auction-house')}>
              <Gavel className="w-8 h-8" />
              <span className="text-lg font-bold">CASA D'ASTE QUANTUM</span>
          </Button>
          
          <Button className="h-24 bg-[#1a1d2d] border-2 border-cyan-600/50 hover:border-cyan-500 hover:bg-cyan-900/20 text-cyan-400 flex flex-col items-center justify-center gap-2 transition-all shadow-lg hover:shadow-cyan-500/20" onClick={() => setLocation('/marketplace')}>
              <Store className="w-8 h-8" />
              <span className="text-lg font-bold">MERCATINO COMMUNITY</span>
          </Button>
      </div>

    </div>
  );
}