import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Gavel, Clock, TrendingUp, User, Coins, ArrowRight, ArrowLeft, Check, AlertCircle, PlusCircle, Euro, Truck, Settings, Trash2, MapPin, Navigation } from 'lucide-react'; // <--- AGGIUNTO ArrowLeft QUI
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch"; 

// DATI INIZIALI
const INITIAL_AUCTIONS = [
    { id: 1, title: "Lampada Steampunk in Rame", author: "Maker_Pro_99", currentBid: 450, currency: "QC", timeLeft: "04:22:10", bids: 12, shippingMode: "ship" },
    { id: 2, title: "Fioriera Verticale PET", author: "GreenSoul", currentBid: 15, currency: "EUR", timeLeft: "01:05:30", bids: 5, shippingMode: "pickup" },
    { id: 3, title: "Organizer Tech", author: "CyberPunk", currentBid: 890, currency: "QC", timeLeft: "12:00:00", bids: 24, shippingMode: "ship" },
];

export default function AuctionHouse() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const searchParams = new URLSearchParams(window.location.search);
  const mode = searchParams.get('mode');
  const newProjectTitle = searchParams.get('title');
  const defaultReserve = searchParams.get('reserve');

  // CARICAMENTO SICURO
  const [auctions, setAuctions] = useState<any[]>(() => {
      try {
          const saved = localStorage.getItem('eco_auctions_v3');
          return saved ? JSON.parse(saved) : INITIAL_AUCTIONS;
      } catch (e) { return INITIAL_AUCTIONS; }
  });
  
  const [activeTab, setActiveTab] = useState("public-auctions");

  // STATI CREAZIONE
  const [reservePrice, setReservePrice] = useState(defaultReserve || "500");
  const [currency, setCurrency] = useState<"QC" | "EUR">("QC"); 
  const [shippingMode, setShippingMode] = useState<"ship" | "pickup">("ship"); 
  const [isCreating, setIsCreating] = useState(false);
  const [userLocation, setUserLocation] = useState("");

  // SALVATAGGIO
  useEffect(() => {
      try { localStorage.setItem('eco_auctions_v3', JSON.stringify(auctions)); } catch (e) {}
  }, [auctions]);

  const toggleShipping = (checked: boolean) => {
      const mode = checked ? "pickup" : "ship";
      setShippingMode(mode);
      if (mode === "pickup") {
          setTimeout(() => {
              setUserLocation("Milano, Lombardia");
              toast({ title: "Posizione Rilevata", description: "Impostato ritiro in zona: Milano", className: "bg-blue-600 text-white" });
          }, 500);
      }
  };

  const handleCreateAuction = () => {
      setIsCreating(true);
      const newAuction = {
          id: Date.now(),
          title: newProjectTitle || "Progetto Senza Nome",
          author: "Tu (EcoTester)",
          currentBid: parseInt(reservePrice) || 0,
          currency: currency,
          timeLeft: "23:59:59",
          bids: 0,
          shippingMode: shippingMode,
          location: userLocation,
          isMine: true
      };
      
      const updatedAuctions = [newAuction, ...auctions];
      setAuctions(updatedAuctions);
      
      setTimeout(() => {
          toast({ title: "Asta Pubblicata!", className: "bg-green-600 text-white" });
          window.location.href = '/auction-house'; // REFRESH PAGINA
      }, 1000);
  };

  const handleBid = (auctionId: number, currentAmount: number) => {
      toast({ title: "Puntata Piazzata!", className: "bg-yellow-600 text-black border-yellow-500" });
      setAuctions(prev => prev.map(a => 
          a.id === auctionId ? { ...a, currentBid: currentAmount + (a.currency === 'QC' ? 50 : 5), bids: (a.bids || 0) + 1 } : a
      ));
  };

  const handleDelete = (id: number) => {
      setAuctions(prev => prev.filter(a => a.id !== id));
      toast({ title: "Asta Ritirata", variant: "destructive" });
  };

  // VISTA CREAZIONE
  if (mode === 'create' && newProjectTitle) {
      return (
        <div className="container mx-auto p-4 min-h-screen text-white flex items-center justify-center">
            <Card className="w-full max-w-lg bg-[#1a1d2d] border-slate-700 shadow-2xl">
                <CardHeader className="text-center border-b border-slate-700 pb-6">
                    <Gavel className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                    <CardTitle className="text-2xl font-bold text-white">Configura Vendita</CardTitle>
                    <p className="text-slate-400 mt-2">Oggetto: <span className="text-white font-bold">{newProjectTitle}</span></p>
                </CardHeader>
                <CardContent className="space-y-8 pt-8">
                    <div className="flex items-center justify-center gap-4 bg-black/30 p-4 rounded-xl border border-slate-700">
                        <span className={`font-bold ${currency === 'QC' ? 'text-yellow-400' : 'text-slate-600'}`}>QC</span>
                        <Switch checked={currency === 'EUR'} onCheckedChange={(c) => setCurrency(c ? 'EUR' : 'QC')} />
                        <span className={`font-bold ${currency === 'EUR' ? 'text-green-400' : 'text-slate-600'}`}>EUR</span>
                    </div>
                    <div className="space-y-2">
                        <Label className="text-slate-300">Prezzo di Riserva</Label>
                        <div className="relative">
                            <Input type="number" className={`bg-black/50 border-slate-600 text-2xl font-bold h-14 pl-12 ${currency === 'QC' ? 'text-yellow-400' : 'text-green-400'}`} value={reservePrice} onChange={(e) => setReservePrice(e.target.value)} />
                            <div className="absolute left-4 top-1/2 -translate-y-1/2">{currency === 'QC' ? <Coins className="w-6 h-6 text-yellow-500"/> : <Euro className="w-6 h-6 text-green-500"/>}</div>
                        </div>
                    </div>
                    <div className="flex flex-col gap-4 bg-black/30 p-4 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between">
                            <span className="text-slate-300 flex items-center">
                                {shippingMode === 'ship' ? <Truck className="w-4 h-4 mr-2 text-cyan-400"/> : <MapPin className="w-4 h-4 mr-2 text-orange-400"/>}
                                {shippingMode === 'ship' ? "Spedizione" : "Ritiro in Zona"}
                            </span>
                            <Switch checked={shippingMode === 'pickup'} onCheckedChange={toggleShipping} />
                        </div>
                        {shippingMode === 'pickup' && <div className="text-xs text-orange-300"><Navigation className="inline w-3 h-3"/> Posizione: {userLocation || "Rilevamento..."}</div>}
                    </div>
                </CardContent>
                <CardFooter className="flex gap-4 bg-slate-900/50 p-6 rounded-b-xl">
                    <Button variant="ghost" onClick={() => setLocation('/dashboard')} className="flex-1 text-slate-400">Annulla</Button>
                    <Button disabled={isCreating} className={`flex-1 font-bold text-black ${currency === 'QC' ? 'bg-yellow-500' : 'bg-green-500'}`} onClick={handleCreateAuction}>
                        {isCreating ? "Pubblicazione..." : `Vendi in ${currency}`}
                    </Button>
                </CardFooter>
            </Card>
        </div>
      );
  }

  // VISTA LISTA
  const mySales = auctions ? auctions.filter(a => a.isMine) : [];
  const publicSales = auctions || [];

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen text-white pb-20">
      <div className="flex justify-between mb-8 items-center">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => setLocation('/dashboard')} className="border-slate-600"><ArrowLeft className="mr-2 h-4 w-4"/> Dashboard</Button>
            <h1 className="text-3xl font-black text-yellow-500 flex items-center gap-2"><Gavel className="w-8 h-8"/> ASTE</h1>
          </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-900 border border-slate-800 h-14 p-1">
              <TabsTrigger value="public-auctions">COMPRA</TabsTrigger>
              <TabsTrigger value="my-auctions">LE TUE VENDITE {mySales.length > 0 && <Badge className="ml-2 bg-red-600">{mySales.length}</Badge>}</TabsTrigger>
          </TabsList>

          <TabsContent value="public-auctions" className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {publicSales.map((auction) => (
                  <Card key={auction.id} className="bg-[#1a1d2d] border-slate-700 hover:border-yellow-500/50 transition-all">
                      <CardHeader className="pb-2">
                          <div className="flex justify-between"><Badge variant="outline" className="text-yellow-400 border-yellow-600 bg-yellow-900/20"><Clock className="w-3 h-3 mr-1"/> {auction.timeLeft}</Badge>{auction.isMine && <Badge className="bg-cyan-600">TUO</Badge>}</div>
                          <CardTitle className="text-lg mt-2 truncate">{auction.title}</CardTitle>
                          <p className="text-xs text-slate-400">di {auction.author}</p>
                      </CardHeader>
                      <CardContent>
                          <div className="bg-black/40 p-3 rounded flex justify-between items-end">
                              <div><p className="text-[10px] text-slate-500 uppercase font-bold">Offerta</p><p className={`text-2xl font-black ${auction.currency === 'QC' ? 'text-yellow-400' : 'text-green-400'}`}>{auction.currentBid} {auction.currency}</p></div>
                              <div className="text-right">{auction.shippingMode === 'pickup' ? <Badge variant="secondary" className="text-[10px]"><MapPin className="w-3 h-3"/> RITIRO</Badge> : <Badge variant="secondary" className="text-[10px]"><Truck className="w-3 h-3"/> SPEDIZ.</Badge>}</div>
                          </div>
                      </CardContent>
                      <CardFooter>
                          {auction.isMine ? <Button className="w-full bg-slate-700" onClick={() => setActiveTab("my-auctions")}><Settings className="w-4 h-4 mr-2"/> Gestisci</Button> : <Button className={`w-full font-bold text-black ${auction.currency === 'QC' ? 'bg-yellow-500' : 'bg-green-500'}`} onClick={() => handleBid(auction.id, auction.currentBid)}>Punta</Button>}
                      </CardFooter>
                  </Card>
              ))}
          </TabsContent>

          <TabsContent value="my-auctions" className="mt-8 space-y-4">
              {mySales.length === 0 ? <div className="text-center py-20 text-slate-500">Nessuna vendita attiva.</div> : mySales.map((auction) => (
                  <Card key={auction.id} className="bg-gradient-to-r from-slate-900 to-[#1a1d2d] border-cyan-500/30 flex flex-col md:flex-row items-center justify-between p-6 gap-6">
                      <div className="flex-1">
                          <h2 className="text-2xl font-bold text-white mb-1">{auction.title}</h2>
                          <div className="flex gap-4 text-sm text-slate-400"><span>Prezzo: {auction.currentBid} {auction.currency}</span><span>Offerte: {auction.bids || 0}</span></div>
                      </div>
                      <Button variant="destructive" onClick={() => handleDelete(auction.id)}><Trash2 className="w-4 h-4 mr-2"/> Ritira</Button>
                  </Card>
              ))}
          </TabsContent>
      </Tabs>
    </div>
  );
}