import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageCircle, Search, Hammer, Layers, PenTool, ArrowLeft, Store, Send, User, MapPin, ShoppingCart, ExternalLink } from 'lucide-react';
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

// DATI SIMULATI: RICHIESTE DI ALTRI UTENTI
const MARKET_REQUESTS = [
    { id: 1, item: "Trapano a percussione", type: "tools", user: "MarioRossi", price_offer: "45 QC", distance: "2km", amazonFallback: "https://amazon.it/s?k=trapano" },
    { id: 2, item: "Viti M4 (20pz)", type: "consumables", user: "EcoGiulia", price_offer: "5 QC", distance: "500m", amazonFallback: "https://amazon.it/s?k=viti+m4" },
    { id: 3, item: "Pallet integri", type: "materials", user: "WoodMaster", price_offer: "Scambio", distance: "10km", amazonFallback: null },
    { id: 4, item: "Colla epossidica", type: "consumables", user: "FixItAll", price_offer: "15 QC", distance: "1.5km", amazonFallback: "https://amazon.it/s?k=colla+epossidica" },
    { id: 5, name: "Seghetto Alternativo", type: "tools", user: "BuilderBob", price_offer: "30 EUR", distance: "5km", amazonFallback: "https://amazon.it/s?k=seghetto" }
];

export default function Marketplace() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("tools");
  
  // CHAT STATE
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatPartner, setChatPartner] = useState("");
  const [chatItem, setChatItem] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll automatico chat
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const openChat = (user: string, item: string) => {
      setChatPartner(user);
      setChatItem(item);
      setMessages([
          { sender: "me", text: `Ciao! Ho visto che cerchi "${item}". Ce l'ho disponibile nel mio laboratorio!` }
      ]);
      setIsChatOpen(true);
  };

  const sendMessage = () => {
      if (!newMessage.trim()) return;
      setMessages(prev => [...prev, { sender: "me", text: newMessage }]);
      setNewMessage("");
      
      // Risposta simulata
      setTimeout(() => {
          setMessages(prev => [...prev, { sender: "partner", text: "Davvero? Grande! Accetti crediti o preferisci contanti allo scambio?" }]);
      }, 1500);
  };

  const filteredItems = MARKET_REQUESTS.filter(item => 
      item.type === activeTab && 
      (item.item || item.name).toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto p-4 md:p-8 min-h-screen text-white pb-20">
      
      <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={() => setLocation('/dashboard')} className="text-slate-400 hover:text-white"><ArrowLeft className="mr-2"/> Dashboard</Button>
          <h1 className="text-3xl font-black text-cyan-400 flex items-center gap-2">
              <Store className="w-8 h-8" /> COMMUNITY MARKET
          </h1>
      </div>

      <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500"/>
          <Input 
            placeholder="Cerca richieste nella tua zona..." 
            className="pl-10 bg-slate-900 border-slate-700 h-12 text-lg text-white placeholder:text-slate-600"
            onChange={(e) => setSearchTerm(e.target.value)}
          />
      </div>

      <Tabs defaultValue="tools" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-900 border border-slate-800 h-14 p-1 rounded-xl">
              <TabsTrigger value="tools" className="data-[state=active]:bg-cyan-700 data-[state=active]:text-white text-md font-bold rounded-lg"><Hammer className="w-4 h-4 mr-2"/> STRUMENTI</TabsTrigger>
              <TabsTrigger value="materials" className="data-[state=active]:bg-green-700 data-[state=active]:text-white text-md font-bold rounded-lg"><Layers className="w-4 h-4 mr-2"/> MATERIALI</TabsTrigger>
              <TabsTrigger value="consumables" className="data-[state=active]:bg-purple-700 data-[state=active]:text-white text-md font-bold rounded-lg"><PenTool className="w-4 h-4 mr-2"/> CONSUMABILI</TabsTrigger>
          </TabsList>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((req) => (
                  <Card key={req.id} className="bg-[#1a1d2d] border-slate-700 hover:border-cyan-500/50 transition-all group relative overflow-hidden shadow-lg">
                      {/* Badge "CERCO" */}
                      <div className="absolute top-0 right-0 bg-yellow-500 text-black text-[10px] font-black px-3 py-1 rounded-bl-xl shadow-lg">CERCO</div>
                      
                      <CardHeader className="pb-2">
                          <div className="flex justify-between items-start mb-2">
                              <Badge variant="outline" className="text-slate-400 border-slate-600 flex items-center gap-1 pl-1 pr-2">
                                  <div className="w-5 h-5 rounded-full bg-slate-700 flex items-center justify-center text-[10px]">{req.user.substring(0,2)}</div> {req.user}
                              </Badge>
                              <span className="text-xs text-slate-500 flex items-center"><MapPin className="w-3 h-3 mr-1"/> {req.distance}</span>
                          </div>
                          <CardTitle className="text-xl mt-1 text-white truncate">{req.item || req.name}</CardTitle>
                          <p className="text-sm text-cyan-400 font-bold">Offre: {req.price_offer}</p>
                      </CardHeader>
                      
                      <CardFooter className="pt-4 border-t border-slate-800 bg-black/20 flex flex-col gap-2">
                          <Button className="w-full bg-green-600 hover:bg-green-500 text-white font-bold h-10" onClick={() => openChat(req.user, req.item || req.name)}>
                              <MessageCircle className="w-4 h-4 mr-2"/> CE L'HO! PARLIAMONE
                          </Button>
                          
                          {req.amazonFallback && (
                              <Button variant="ghost" className="w-full text-xs text-slate-500 hover:text-yellow-500 h-8" onClick={() => window.open(req.amazonFallback, '_blank')}>
                                  Non ce l'hai? <span className="underline ml-1">Compralo su Amazon</span> <ExternalLink className="w-3 h-3 ml-1"/>
                              </Button>
                          )}
                      </CardFooter>
                  </Card>
              ))}
          </div>
      </Tabs>

      {/* CHAT OVERLAY REALISTICA */}
      <Dialog open={isChatOpen} onOpenChange={setIsChatOpen}>
          <DialogContent className="bg-[#0f111a] border-slate-700 text-white sm:max-w-md h-[80vh] flex flex-col p-0 overflow-hidden shadow-2xl">
              <DialogHeader className="p-4 border-b border-slate-800 bg-[#1a1d2d]">
                  <DialogTitle className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-sm font-bold shadow-lg">{chatPartner.substring(0,2)}</div>
                      <div className="flex flex-col">
                          <span className="text-white font-bold">{chatPartner}</span>
                          <span className="text-xs text-green-400 flex items-center"><span className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></span> Online</span>
                      </div>
                  </DialogTitle>
              </DialogHeader>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
                  {messages.map((msg, i) => (
                      <div key={i} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[80%] p-3 rounded-2xl text-sm shadow-md ${msg.sender === 'me' ? 'bg-cyan-600 text-white rounded-tr-none' : 'bg-[#1a1d2d] text-slate-200 rounded-tl-none border border-slate-700'}`}>
                              {msg.text}
                          </div>
                      </div>
                  ))}
                  <div ref={messagesEndRef} />
              </div>

              <div className="p-4 border-t border-slate-800 bg-[#1a1d2d] flex gap-2 items-center">
                  <Input 
                      className="bg-slate-900 border-slate-700 text-white h-12 rounded-full px-6 focus-visible:ring-cyan-500" 
                      placeholder="Scrivi un messaggio..." 
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <Button size="icon" className="bg-cyan-600 hover:bg-cyan-500 rounded-full h-12 w-12 shrink-0 shadow-lg" onClick={sendMessage}>
                      <Send className="w-5 h-5"/>
                  </Button>
              </div>
          </DialogContent>
      </Dialog>
    </div>
  );
}