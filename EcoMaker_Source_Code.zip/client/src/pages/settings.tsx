import React, { useState, useEffect } from "react";
import { Link } from "wouter";
import { 
  Shield, Smartphone, Facebook, Check, 
  ExternalLink, Lock, AlertCircle, Settings as SettingsIcon,
  Gift, ArrowRight, Mail, Chrome, Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

// FIREBASE
import { auth } from "@/lib/firebase";
import { 
  GoogleAuthProvider, 
  FacebookAuthProvider, 
  signInWithPopup, 
  RecaptchaVerifier, 
  signInWithPhoneNumber,
  sendSignInLinkToEmail,
  isSignInWithEmailLink,
  signInWithEmailLink
} from "firebase/auth";

declare global {
  interface Window {
    recaptchaVerifier: any;
  }
}

export default function SettingsPage() {
  const { toast } = useToast();
  
  // STATO EMAIL
  const [email, setEmail] = useState("");
  const [emailLoading, setEmailLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);
  const [isEmailVerified, setIsEmailVerified] = useState(false);

  // STATO CELLULARE
  const [phone, setPhone] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [phoneLoading, setPhoneLoading] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);

  useEffect(() => {
    if (isSignInWithEmailLink(auth, window.location.href)) {
      let emailForSignIn = window.localStorage.getItem('emailForSignIn');
      if (!emailForSignIn) {
        emailForSignIn = window.prompt('Conferma la tua email per accedere:');
      }
      if (emailForSignIn) {
        signInWithEmailLink(auth, emailForSignIn, window.location.href)
          .then((result) => {
            window.localStorage.removeItem('emailForSignIn');
            setIsEmailVerified(true);
            setEmail(emailForSignIn);
            toast({ title: "Email Verificata!", description: "Accesso riuscito.", variant: "default" });
          })
          .catch((error) => {
            toast({ title: "Errore Link", description: "Link scaduto o non valido.", variant: "destructive" });
          });
      }
    }
  }, []);

  const setupRecaptcha = () => {
    if (!window.recaptchaVerifier) {
      window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        'size': 'invisible',
        'callback': () => {
          console.log("Recaptcha risolto");
        }
      });
    }
  };

  const handleSocialLogin = async (providerName: "google" | "facebook") => {
    const provider = providerName === "google" 
      ? new GoogleAuthProvider() 
      : new FacebookAuthProvider();

    try {
      await signInWithPopup(auth, provider);
      toast({ title: "Connesso!", description: `Login con ${providerName} riuscito.` });
    } catch (error: any) {
      if (error.code === 'auth/unauthorized-domain') {
        toast({ title: "Dominio Non Autorizzato", description: "Verifica la console Firebase.", variant: "destructive" });
      } else {
        toast({ title: "Errore Login", description: error.message, variant: "destructive" });
      }
    }
  };

  const handleSendEmailLink = async () => {
    if (!email.includes("@")) {
      toast({ title: "Errore", description: "Email non valida", variant: "destructive" });
      return;
    }
    setEmailLoading(true);
    try {
      const actionCodeSettings = {
        url: window.location.href,
        handleCodeInApp: true,
      };
      await sendSignInLinkToEmail(auth, email, actionCodeSettings);
      window.localStorage.setItem('emailForSignIn', email);
      setIsEmailSent(true);
      toast({ title: "Link Inviato", description: "Controlla la posta (anche spam)." });
    } catch (error: any) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
    } finally {
      setEmailLoading(false);
    }
  };

  const handleSendPhoneOtp = async () => {
    if (!phone) {
      toast({ title: "Manca il numero", variant: "destructive" });
      return;
    }
    
    setPhoneLoading(true);
    
    try {
      setupRecaptcha();
      const appVerifier = window.recaptchaVerifier;
      const confirmation = await signInWithPhoneNumber(auth, phone, appVerifier);
      setConfirmationResult(confirmation);
      setIsOtpSent(true);
      toast({ title: "SMS Inviato", description: "Inserisci il codice ricevuto." });

    } catch (error: any) {
      console.error("Errore SMS:", error);
      if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear();
        window.recaptchaVerifier = null;
      }
      let msg = error.message;
      if(error.code === 'auth/argument-error') msg = "Errore ReCAPTCHA. Ricarica la pagina.";
      if(error.code === 'auth/invalid-phone-number') msg = "Numero non valido. Usa +39...";
      
      toast({ title: "Errore Invio", description: msg, variant: "destructive" });
    } finally {
      setPhoneLoading(false);
    }
  };

  const handleVerifyPhoneOtp = async () => {
    if (!otpCode) return;
    setPhoneLoading(true);
    try {
      await confirmationResult.confirm(otpCode);
      setIsPhoneVerified(true);
      toast({ title: "Verificato!", description: "Numero collegato correttamente." });
    } catch (error: any) {
      toast({ title: "Codice Errato", description: "Riprova.", variant: "destructive" });
    } finally {
      setPhoneLoading(false);
    }
  };

  return (
    <div className="min-h-full bg-[#0f111a] text-white p-4 md:p-8 overflow-x-hidden">
      
      <div id="recaptcha-container"></div>

      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* HEADER - CORRETTO IL LINK QUI SOTTO */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard"> {/* <--- ERA "/", ORA È "/dashboard" */}
             <Button className="bg-slate-800 text-white border border-slate-700 hover:bg-slate-700 transition-colors">
               ← Dashboard
             </Button>
          </Link>
          <div className="flex items-center gap-3">
             <div className="bg-slate-800 p-2 rounded-lg"><SettingsIcon className="w-6 h-6 text-purple-400"/></div>
             <h1 className="text-3xl font-bold text-white">Impostazioni & Sicurezza</h1>
          </div>
        </div>

        {/* ... IL RESTO DEL CODICE RIMANE UGUALE ... */}
        {/* (Per brevità non ricopio tutto il body che è identico a prima, assicurati di avere tutto il contenuto sotto) */}
        
        <section className="bg-[#1a1d2d] rounded-2xl p-6 border border-slate-700/50">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-semibold">Sicurezza Account</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
               <div className="space-y-3">
                 <label className="text-sm text-slate-400 flex items-center gap-2">
                    <Mail className="w-4 h-4" /> Email Collegata
                 </label>
                 {!isEmailVerified ? (
                    !isEmailSent ? (
                       <div className="flex gap-2">
                         <Input placeholder="nome@esempio.com" className="bg-black/20 border-slate-600 text-white" value={email} onChange={(e) => setEmail(e.target.value)} />
                         <Button onClick={handleSendEmailLink} disabled={emailLoading} className="bg-purple-600 hover:bg-purple-700 text-white min-w-[80px]">
                           {emailLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : "Invia Link"}
                         </Button>
                       </div>
                    ) : (
                      <div className="bg-purple-500/10 border border-purple-500/30 p-3 rounded-lg">
                        <p className="text-sm text-purple-200 mb-2">Link inviato a <strong>{email}</strong></p>
                        <Button variant="link" size="sm" onClick={() => setIsEmailSent(false)} className="text-purple-400 p-0 h-auto">Riprova</Button>
                      </div>
                    )
                 ) : (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-lg flex items-center gap-2 text-emerald-400">
                       <Check className="w-4 h-4" /> Email Verificata
                    </div>
                 )}
               </div>
               <div className="h-px bg-slate-700/50"></div>
               <div className="space-y-3">
                 <p className="text-sm text-slate-400">Social Login</p>
                 <Button onClick={() => handleSocialLogin("google")} className="w-full justify-start bg-slate-800 text-white border border-slate-600 hover:bg-slate-700">
                   <Chrome className="w-4 h-4 mr-3 text-white" /> Accedi con Google
                 </Button>
                 <Button onClick={() => handleSocialLogin("facebook")} className="w-full justify-start bg-[#1877F2] text-white hover:bg-[#1877F2]/80">
                   <Facebook className="w-4 h-4 mr-3" /> Connetti Facebook
                 </Button>
               </div>
            </div>

            <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-700/30">
               <h3 className="text-white font-medium mb-4 flex items-center gap-2">
                 <Smartphone className="w-4 h-4 text-purple-400" /> Verifica Cellulare
               </h3>
               {!isPhoneVerified ? (
                 <div className="space-y-4">
                   {!isOtpSent ? (
                     <>
                       <p className="text-xs text-slate-400">Inserisci il numero (+39...) per ricevere il codice.</p>
                       <div className="flex gap-2">
                         <Input placeholder="+39 333..." className="bg-black/20 border-slate-600 text-white" value={phone} onChange={(e) => setPhone(e.target.value)} />
                         <Button onClick={handleSendPhoneOtp} disabled={phoneLoading} className="bg-purple-600 hover:bg-purple-700 text-white min-w-[80px]">
                           {phoneLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : "Invia SMS"}
                         </Button>
                       </div>
                     </>
                   ) : (
                     <>
                       <p className="text-xs text-slate-400">Codice inviato a {phone}</p>
                       <div className="flex gap-2">
                         <Input placeholder="123456" className="bg-black/20 border-slate-600 text-white text-center tracking-widest text-lg" value={otpCode} onChange={(e) => setOtpCode(e.target.value)} />
                         <Button onClick={handleVerifyPhoneOtp} disabled={phoneLoading} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                           {phoneLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : "Verifica"}
                         </Button>
                       </div>
                       <button onClick={() => setIsOtpSent(false)} className="text-xs text-purple-400 underline mt-2 hover:text-purple-300">Cambia numero</button>
                     </>
                   )}
                 </div>
               ) : (
                 <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-4 flex items-center gap-3 text-emerald-400 mt-4">
                    <Check className="w-5 h-5" />
                    <div><div className="font-bold">Numero Verificato</div><div className="text-xs opacity-70">{phone}</div></div>
                 </div>
               )}
            </div>
          </div>
        </section>

        <section className="bg-gradient-to-r from-indigo-900/40 to-purple-900/40 rounded-2xl p-6 border border-indigo-500/30 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
             <Gift className="w-24 h-24 text-yellow-400" />
          </div>
          <div className="flex items-center gap-3 mb-2">
            <Gift className="w-6 h-6 text-yellow-400" />
            <h2 className="text-xl font-semibold text-white">Programma Referral</h2>
          </div>
          <p className="text-indigo-200 mb-6 max-w-xl">
            Invita i tuoi amici a unirsi alla rivoluzione Quantum. Guadagna <span className="text-yellow-400 font-bold">50 Crediti</span> per ogni nuovo membro attivo.
          </p>
          <Link href="/referral">
             <Button className="bg-indigo-600 hover:bg-indigo-500 w-full sm:w-auto text-white">
               Vai alla Dashboard Referral <ArrowRight className="w-4 h-4 ml-2" />
             </Button>
          </Link>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                 <Lock className="w-5 h-5 text-slate-400" />
                 <h3 className="font-semibold text-white">Privacy Policy</h3>
              </div>
              <Link href="/privacy-policy">
                 <Button variant="secondary" className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200">
                   Leggi Documento <ExternalLink className="w-3 h-3 ml-2" />
                 </Button>
              </Link>
           </div>
           <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                 <AlertCircle className="w-5 h-5 text-slate-400" />
                 <h3 className="font-semibold text-white">Termini di Servizio</h3>
              </div>
              <Link href="/terms-of-service">
                 <Button variant="secondary" className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200">
                   Leggi Termini <ExternalLink className="w-3 h-3 ml-2" />
                 </Button>
              </Link>
           </div>
        </section>

      </div>
    </div>
  );
}