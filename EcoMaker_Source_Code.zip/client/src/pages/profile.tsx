import React, { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { 
  User, MapPin, Calendar, Edit3, Shield, Zap, 
  Trophy, Share2, Settings, Camera, Sprout, Flower
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { auth, db } from "@/lib/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { FuturisticHeader } from "@/components/layout/FuturisticHeader"; // Importiamo l'header se vuoi vederlo anche qui

export default function ProfilePage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Stati per il form di modifica
  const [bio, setBio] = useState("");
  const [hobbies, setHobbies] = useState("");

  // Carica dati utente
  useEffect(() => {
    const fetchUserData = async () => {
      if (auth.currentUser) {
        const docRef = doc(db, "users", auth.currentUser.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserData(data);
          setBio(data.bio || "");
          setHobbies(data.hobbies || "");
        }
      }
      setLoading(false);
    };
    fetchUserData();
  }, []);

  const handleSave = async () => {
    if (!auth.currentUser) return;
    try {
      await updateDoc(doc(db, "users", auth.currentUser.uid), {
        bio: bio,
        hobbies: hobbies
      });
      setIsEditing(false);
      setUserData({ ...userData, bio, hobbies });
      toast({ title: "Profilo Aggiornato", description: "Le tue modifiche sono state salvate." });
    } catch (error) {
      toast({ title: "Errore", description: "Impossibile salvare le modifiche.", variant: "destructive" });
    }
  };

  if (loading) return <div className="h-screen bg-[#0f111a] text-white flex items-center justify-center">Caricamento Profilo...</div>;

  return (
    <div className="min-h-screen bg-[#0f111a] text-white pb-20">
      
      {/* BANNER COPERTINA */}
      <div className="h-48 bg-gradient-to-r from-cyan-900 via-purple-900 to-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/grid-pattern.svg')] opacity-20"></div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10">
        
        {/* HEADER PROFILO */}
        <div className="flex flex-col md:flex-row items-start md:items-end gap-6 mb-8">
          
          {/* AVATAR (Pianta Evolutiva) */}
          <div className="relative group">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-2xl bg-[#1a1d2d] border-4 border-[#0f111a] flex items-center justify-center shadow-2xl overflow-hidden relative">
               {/* Qui in futuro metteremo l'SVG della pianta scelta. Per ora un placeholder */}
               {userData?.avatarType === 'cactus' ? <Zap className="w-20 h-20 text-green-500" /> : 
                userData?.avatarType === 'flower' ? <Flower className="w-20 h-20 text-pink-500" /> :
                <Sprout className="w-20 h-20 text-emerald-400" />
               }
            </div>
            <div className="absolute bottom-2 right-2 bg-black/60 p-1.5 rounded-lg cursor-pointer hover:bg-cyan-600 transition-colors">
              <Camera className="w-4 h-4 text-white" />
            </div>
          </div>

          {/* INFO UTENTE */}
          <div className="flex-1 space-y-2">
             <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold text-white">{userData?.username || "Maker Sconosciuto"}</h1>
                <span className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs rounded-full font-bold">
                  LVL {userData?.level || 1}
                </span>
             </div>
             <div className="flex flex-wrap gap-4 text-slate-400 text-sm">
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> Earth Base</span>
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Iscritto nel 2026</span>
             </div>
          </div>

          {/* PULSANTI AZIONE */}
          <div className="flex gap-3 mt-4 md:mt-0">
             <Button variant="outline" className="border-slate-600 text-slate-300 hover:text-white" onClick={() => setIsEditing(!isEditing)}>
               <Edit3 className="w-4 h-4 mr-2" /> {isEditing ? "Annulla" : "Modifica"}
             </Button>
             <Link href="/settings">
                <Button variant="ghost" size="icon" className="text-slate-400"><Settings className="w-5 h-5" /></Button>
             </Link>
          </div>
        </div>

        {/* CONTENUTO GRIGLIA */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* COLONNA SINISTRA: STATS & BIO */}
          <div className="space-y-6">
             {/* STATS CARD */}
             <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-slate-700/50">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-purple-400" /> Stato Maker
                </h3>
                <div className="space-y-4">
                   <div className="flex justify-between items-center">
                      <span className="text-slate-400">Crediti</span>
                      <span className="text-yellow-400 font-mono font-bold">{userData?.credits || 0} QC</span>
                   </div>
                   <div className="flex justify-between items-center">
                      <span className="text-slate-400">Progetti Finiti</span>
                      <span className="text-white font-bold">0</span>
                   </div>
                   <div className="flex justify-between items-center">
                      <span className="text-slate-400">CO2 Risparmiata</span>
                      <span className="text-emerald-400 font-bold">{userData?.co2Saved || 0} kg</span>
                   </div>
                   
                   {/* BARRA ESPERIENZA */}
                   <div className="pt-2">
                     <div className="flex justify-between text-xs mb-1">
                       <span className="text-slate-500">XP Livello {userData?.level || 1}</span>
                       <span className="text-cyan-400">{userData?.experience || 0} / 1000</span>
                     </div>
                     <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 w-[10%]"></div>
                     </div>
                   </div>
                </div>
             </div>

             {/* BIO & HOBBY */}
             <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-slate-700/50">
                <h3 className="text-lg font-bold text-white mb-4">Bio & Dati</h3>
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-slate-500 mb-1 block">Bio / Chi sono</label>
                      <Textarea 
                        className="bg-black/30 border-slate-600 text-white" 
                        value={bio} 
                        onChange={(e) => setBio(e.target.value)}
                        placeholder="Racconta qualcosa di te..."
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 mb-1 block">Hobby & Interessi</label>
                      <Input 
                        className="bg-black/30 border-slate-600 text-white" 
                        value={hobbies} 
                        onChange={(e) => setHobbies(e.target.value)}
                        placeholder="Musica, Sport, Natura..."
                      />
                    </div>
                    <Button onClick={handleSave} className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">Salva Modifiche</Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-slate-400 text-sm italic">
                      "{userData?.bio || "Nessuna biografia inserita."}"
                    </p>
                    {userData?.hobbies && (
                      <div className="flex flex-wrap gap-2 pt-2">
                        {userData.hobbies.split(',').map((tag: string, i: number) => (
                          <span key={i} className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-300 border border-slate-700">
                            {tag.trim()}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}
             </div>
          </div>

          {/* COLONNA DESTRA: GALLERIA PROGETTI (Vuota per ora) */}
          <div className="lg:col-span-2 space-y-6">
             <div className="bg-[#1a1d2d] rounded-2xl p-8 border border-slate-700/50 text-center min-h-[300px] flex flex-col items-center justify-center">
                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4">
                   <Trophy className="w-8 h-8 text-slate-600" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Galleria Progetti Vuota</h3>
                <p className="text-slate-400 max-w-md mx-auto mb-6">
                   Completa il tuo primo progetto di riciclo per iniziare a popolare la tua vetrina pubblica.
                </p>
                <Link href="/inventory">
                   <Button variant="outline" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10">
                     Inizia un Progetto
                   </Button>
                </Link>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
}