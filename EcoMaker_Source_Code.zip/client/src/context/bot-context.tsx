import React, { createContext, useContext, useState, ReactNode } from 'react';

// TYPES
interface BotStats {
  mined: number;
  target: string;
  complexity: number;
  lastAction: string;
}

interface BotContextType {
  status: string;
  setStatus: (s: string) => void;
  logs: string[];
  addLog: (l: string) => void;
  stats: BotStats;
  setStats: React.Dispatch<React.SetStateAction<BotStats>>;
  isBotActive: boolean;
  setIsBotActive: (b: boolean) => void;
}

const defaultStats: BotStats = {
  mined: 0,
  target: "In attesa...",
  complexity: 0,
  lastAction: "Avvio sistema"
};

// EXPORT THIS SO OTHER FILES CAN USE IT DIRECTLY
export const BotContext = createContext<BotContextType | undefined>(undefined);

export function BotProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState("Inizializzazione...");
  const [logs, setLogs] = useState<string[]>([]);
  const [isBotActive, setIsBotActive] = useState(false);
  const [stats, setStats] = useState<BotStats>(defaultStats);

  const addLog = (log: string) => {
    const time = new Date().toLocaleTimeString();
    setLogs(prev => [`[${time}] ${log}`, ...prev].slice(0, 50));
  };

  return (
    <BotContext.Provider value={{ status, setStatus, logs, addLog, stats, setStats, isBotActive, setIsBotActive }}>
      {children}
    </BotContext.Provider>
  );
}

// Custom hook remains the same
export function useBotContext() {
  const context = useContext(BotContext);
  if (!context) {
    console.warn("⚠️ BotContext non trovato! Uso fallback sicuro.");
    return {
        status: "Errore Context",
        setStatus: () => {},
        logs: ["Errore critico: BotProvider non trovato"],
        addLog: () => {},
        stats: defaultStats,
        setStats: () => {},
        isBotActive: false,
        setIsBotActive: () => {}
    };
  }
  return context;
}