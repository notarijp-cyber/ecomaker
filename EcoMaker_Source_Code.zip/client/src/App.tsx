// Copyright (c) 2026 Jacopo Primo Notari. All rights reserved.
// This code is proprietary and confidential. Unauthorized copying is prohibited.
import { useState, useEffect } from "react";
import { Switch, Route, useLocation, Redirect } from "wouter";
import { onAuthStateChanged } from "firebase/auth"; 
import { auth } from "@/lib/firebase"; 
import { Loader2, Atom } from "lucide-react"; 
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

// CONTEXT & BOT
import { BotProvider } from "@/context/bot-context";
import { EcoBotManager } from "@/components/EcoBotManager"; 

// LAYOUT
import MobileNav from "@/components/layout/MobileNav";
import { FuturisticHeader } from "@/components/layout/FuturisticHeader";
import Footer from "@/components/layout/footer";
import Sidebar from "@/components/layout/Sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { Toaster } from "@/components/ui/toaster";
import KickstarterDownloadFAB from "@/components/ui/kickstarter-download-fab";

// PAGINE PUBBLICHE
import LandingPage from "@/pages/landing";
import LoginPage from "@/pages/login";
import AuthPage from "./pages/AuthPage"; 
import VerifyEmailPage from "@/pages/verify-email";
import NotFound from "@/pages/not-found";

// PAGINE PRIVATE (AREA UTENTE/BOT)
import Dashboard from "@/pages/dashboard";
import ProfilePage from "@/pages/profile";
import ProjectGeneratorPage from "@/pages/project-generator";
import Inventory from "@/pages/inventory";
import Community from "@/pages/community";
import SettingsPage from "@/pages/settings"; 
import ARMaterialScanPreview from "@/pages/ar-material-scan-preview";
import MyProjects from "@/pages/my-projects";
import BotCommandCenter from "@/pages/bot-command-center";
import ProjectDetail from "@/pages/project-detail";
import MaterialDetail from "@/pages/material-detail";
import AuctionHouse from "@/pages/auction-house"; // NUOVO
import RecycleGuides from "@/pages/recycle-guides"; // NUOVO
import Marketplace from "@/pages/marketplace";

// ==============================================================================
// COMPONENTE WRAPPER PER IL LAYOUT PRIVATO (Header + Sidebar + Footer)
// ==============================================================================
function PrivateLayout({ children }: { children: React.ReactNode }) {
  const isMobile = useIsMobile();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex flex-col min-h-screen futuristic-bg bg-background text-foreground">
      <FuturisticHeader onProfileClick={() => setIsSidebarOpen(true)} />
      <div className="flex flex-1 overflow-hidden h-[calc(100vh-64px)]">
        <Sidebar mobileOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
        <main className="flex-1 overflow-y-auto custom-scrollbar relative flex flex-col bg-[#0f111a]">
          <div className="flex-1">
            {children}
          </div>
          <Footer />
        </main>
      </div>
      {isMobile && <MobileNav />}
      <KickstarterDownloadFAB />
    </div>
  );
}

// ==============================================================================
// GESTORE DELLE ROTTE E DELL'AUTENTICAZIONE
// ==============================================================================
function AppRoutes() {
  const [location, setLocation] = useLocation();
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (authLoading) {
    return (
      <div className="h-screen w-screen bg-[#0f111a] flex flex-col items-center justify-center text-white">
        <Atom className="w-16 h-16 text-cyan-400 animate-spin-slow mb-4" />
        <p className="text-cyan-500/80 animate-mono">Caricamento Sistema...</p>
      </div>
    );
  }

  // ROTTE PUBBLICHE (Non richiedono login, non hanno sidebar)
  const publicRoutes = ["/", "/login", "/auth", "/verify-email"];
  if (publicRoutes.includes(location)) {
      if (user && location !== "/verify-email") return <Redirect to="/dashboard" />;
      return (
        <Switch>
          <Route path="/" component={LandingPage} />
          <Route path="/login" component={LoginPage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/verify-email" component={VerifyEmailPage} />
    
        </Switch>
      );
  }

  // ROTTE PRIVATE (Richiedono login, HANNO sidebar)
  if (!user) return <Redirect to="/" />;

  return (
    <PrivateLayout>
      <Switch>
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/inventory" component={Inventory} />
        <Route path="/community" component={Community} />
        <Route path="/my-projects" component={MyProjects} />
        <Route path="/profile" component={ProfilePage} />
        <Route path="/settings" component={SettingsPage} />
        <Route path="/marketplace" component={Marketplace} />
        {/* Features */}
        <Route path="/ar-material-scan" component={ARMaterialScanPreview} />
        <Route path="/project-generator" component={ProjectGeneratorPage} />
        <Route path="/bot-command-center" component={BotCommandCenter} />
        
        {/* Dettagli & Extra */}
        <Route path="/project-detail/:id" component={ProjectDetail} />
        <Route path="/material-detail/:id" component={MaterialDetail} />
        <Route path="/auction-house" component={AuctionHouse} />
        <Route path="/recycle-guides" component={RecycleGuides} />

        <Route component={NotFound} />
      </Switch>
    </PrivateLayout>
  );
}

// ==============================================================================
// APP PRINCIPALE
// ==============================================================================
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BotProvider>
        <EcoBotManager /> {/* Il lavoratore invisibile */}
        <AppRoutes />
        <Toaster />
      </BotProvider>
    </QueryClientProvider>
  );
}

export default App;