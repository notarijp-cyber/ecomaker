import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, Bell, Menu, ChevronDown, Recycle, Leaf, Plus } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useIsMobile } from "@/hooks/use-mobile";

export function Header() {
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <header className="relative z-10 eco-gradient-bg shadow-lg">
      <div className="absolute inset-0 opacity-10 bg-white pattern-grid-md"></div>
      <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center relative">
        <div className="flex items-center space-x-3">
          <div onClick={() => window.location.href = '/'} className="relative bg-white p-2 rounded-full shadow-md cursor-pointer">
            <Recycle className="h-7 w-7 text-primary" />
            <span className="absolute -top-1 -right-1 bg-white rounded-full p-0.5">
              <Leaf className="h-4 w-4 text-green-600" />
            </span>
          </div>
          <div onClick={() => window.location.href = '/'} className="cursor-pointer">
            <h1 className="text-2xl font-heading font-extrabold text-white drop-shadow-sm tracking-tight">
              EcoMaker
            </h1>
            <div className="text-xs text-white text-opacity-90 font-medium tracking-wide -mt-1">
              Trasforma. Ricicla. Crea.
            </div>
          </div>
        </div>

        {!isMobile && (
          <nav className="hidden md:flex items-center space-x-1">
            <Button 
              variant="ghost" 
              onClick={() => window.location.href = '/'}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location === "/" 
                  ? "text-white bg-primary-foreground/10" 
                  : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
            >
              Dashboard
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => window.location.href = '/my-projects'}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location === "/my-projects" 
                  ? "text-white bg-primary-foreground/10" 
                  : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
            >
              I Miei Progetti
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => window.location.href = '/inventory'}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location === "/inventory" 
                  ? "text-white bg-primary-foreground/10" 
                  : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
            >
              Materiali
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => window.location.href = '/community'}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location === "/community" 
                  ? "text-white bg-primary-foreground/10" 
                  : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
            >
              Community
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10 gap-1">
                  Altro <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onSelect={() => window.location.href = '/events'}>
                  Eventi
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => window.location.href = '/environmental-impact'}>
                  Impatto Ambientale
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => window.location.href = '/ai-assistant'}>
                  Assistente AI
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => window.location.href = '/innovation-center'}>
                  Centro Innovazione
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => window.location.href = '/smart-recommendations'}>
                  Raccomandazioni AI
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => window.location.href = '/advanced-sustainability'}>
                  Tracker Sostenibilità
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        )}

        <div className="flex items-center space-x-3">
          {!isMobile && (
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-4 w-4 text-white/70" />
              </span>
              <Input
                type="text"
                placeholder="Cerca progetti o materiali"
                className="py-1.5 pl-10 pr-4 rounded-full w-48 bg-white/10 text-white placeholder:text-white/60 border-none focus:outline-none focus:ring-2 focus:ring-white/30 text-sm shadow-inner backdrop-blur-sm"
              />
            </div>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="rounded-full w-9 h-9 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors"
          >
            <Bell className="h-5 w-5" />
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.location.href = '/create-project'}
            className="hidden md:flex items-center space-x-1 rounded-full bg-white text-primary hover:bg-white/90 transition-colors px-3 py-1 text-sm font-medium"
          >
            <Plus className="h-4 w-4 mr-1" />
            Nuovo Progetto
          </Button>

          {isMobile && (
            <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full w-9 h-9 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="border-l-primary/20">
                <div className="flex items-center space-x-2 mb-6 mt-6">
                  <Recycle className="h-6 w-6 text-primary" />
                  <h2 className="text-xl font-semibold text-primary">EcoMaker</h2>
                </div>
                
                <div className="relative mb-6">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                    <Search className="h-4 w-4 text-muted-foreground" />
                  </span>
                  <Input
                    type="text"
                    placeholder="Cerca progetti o materiali"
                    className="py-2 pl-10 pr-4 w-full"
                  />
                </div>
                
                <nav className="flex flex-col space-y-1">
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Dashboard
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/my-projects';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/my-projects" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    I Miei Progetti
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/inventory';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/inventory" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Inventario
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/community';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/community" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Community
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/events';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/events" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Eventi
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/environmental-impact';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/environmental-impact" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Impatto Ambientale
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      window.location.href = '/ai-assistant';
                      setSidebarOpen(false);
                    }}
                    className={`justify-start px-2 ${location === "/ai-assistant" ? "bg-primary/10 text-primary font-medium" : "text-neutral-dark hover:bg-neutral-100"}`}
                  >
                    Assistente AI
                  </Button>
                  
                  <div className="border-t my-4"></div>
                  
                  <Button 
                    className="w-full gap-2 mt-2"
                    onClick={() => {
                      window.location.href = '/create-project';
                      setSidebarOpen(false);
                    }}
                  >
                    <Plus className="h-4 w-4" />
                    Crea Nuovo Progetto
                  </Button>
                </nav>
              </SheetContent>
            </Sheet>
          )}

          {!isMobile && (
            <Avatar className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white font-medium text-sm border-2 border-white/30 shadow-sm hover:border-white/50 transition-colors cursor-pointer">
              <AvatarFallback>TU</AvatarFallback>
            </Avatar>
          )}
        </div>
      </div>
    </header>
  );
}
