import React from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  ShoppingBag, 
  FolderOpen, 
  Users, 
  Calendar, 
  BarChart3, 
  Lightbulb, 
  Trophy, 
  LogOut, 
  X,
  Settings,
  Leaf,
  GraduationCap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { auth } from "@/lib/firebase";
import { signOut } from "firebase/auth";

interface SidebarProps {
  mobileOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ mobileOpen, onClose }: SidebarProps) {
  const [location, setLocation] = useLocation();

  const handleLogout = async () => {
    await signOut(auth);
    setLocation("/"); // Torna alla Landing Page
  };

  const navItems = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard }, // <--- CORRETTO: ORA PUNTA A /dashboard
    { label: "Inventario", href: "/inventory", icon: ShoppingBag },
    { label: "I Miei Progetti", href: "/my-projects", icon: FolderOpen },
    { label: "Community", href: "/community", icon: Users },
    { label: "Eventi", href: "/events", icon: Calendar },
    { label: "Analytics", href: "/environmental-analytics", icon: BarChart3 },
    { label: "Innovazione", href: "/innovation-center", icon: Lightbulb },
    { label: "Gamification", href: "/gamification", icon: Trophy },
    { label: "Guide Riciclo", href: "/recycle-guides", icon: Leaf },
    { label: "Impostazioni", href: "/settings", icon: Settings },
  ];

  // Classi per gestire apertura/chiusura su mobile
  const sidebarClasses = `
    fixed inset-y-0 left-0 z-40 w-64 transform transition-transform duration-300 ease-in-out
    bg-[#0f111a]/95 backdrop-blur-xl border-r border-cyan-500/20
    ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
    md:translate-x-0 md:static md:block
  `;

  return (
    <>
      {/* Overlay scuro per mobile */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm md:hidden"
          onClick={onClose}
        />
      )}

      <aside className={sidebarClasses}>
        <div className="flex h-16 items-center justify-between px-6 border-b border-cyan-500/20">
          <span className="text-xl font-bold holographic-text">Menu</span>
          <Button variant="ghost" size="icon" className="md:hidden text-slate-400" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <ScrollArea className="h-[calc(100vh-64px)] px-4 py-6">
          <nav className="space-y-2">
            
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div 
                    onClick={() => mobileOpen && onClose()} // Chiude sidebar su mobile dopo click
                    className={`
                      flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group
                      ${isActive 
                        ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-[0_0_10px_rgba(6,182,212,0.15)]" 
                        : "text-slate-400 hover:text-cyan-200 hover:bg-white/5 border border-transparent"
                      }
                    `}
                  >
                    <item.icon className={`w-5 h-5 ${isActive ? "animate-pulse" : "group-hover:scale-110 transition-transform"}`} />
                    <span className="font-medium">{item.label}</span>
                    
                    {isActive && (
                      <div className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_5px_#22d3ee]" />
                    )}
                  </div>
                </Link>
              );
            })}

            <div className="my-4 border-t border-slate-800" />

            {/* Tasto Logout in basso */}
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors border border-transparent hover:border-red-500/20"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Disconnetti</span>
            </button>

          </nav>

          {/* Bannerino promozionale in fondo alla sidebar */}
          <div className="mt-8 p-4 rounded-xl bg-gradient-to-br from-purple-900/50 to-slate-900 border border-purple-500/30 text-center">
             <div className="w-10 h-10 mx-auto bg-purple-500/20 rounded-full flex items-center justify-center mb-3 border border-purple-500/50">
               <Trophy className="w-5 h-5 text-purple-400" />
             </div>
             <h4 className="text-white font-bold text-sm">Diventa Pro</h4>
             <p className="text-xs text-slate-400 mt-1 mb-3">Sblocca analytics avanzate e badge esclusivi.</p>
             <Button size="sm" variant="secondary" className="w-full text-xs h-8 bg-purple-600 hover:bg-purple-700 text-white border-0">
               Upgrade
             </Button>
          </div>

        </ScrollArea>
      </aside>
    </>
  );
}